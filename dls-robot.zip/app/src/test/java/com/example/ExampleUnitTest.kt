package com.example

import com.example.analysis.ImageAnalysisManager
import com.example.decision.DlsDecisionEngine
import com.example.gamestate.DlsGameStateAnalyzer
import com.example.vision.DlsVisionAnalyzer
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun imageAnalysisManager_lifecycleAndIntervalConfig() {
        val manager = ImageAnalysisManager.instance
        manager.setIntervalMs(200L)
        assertEquals(200L, manager.analysisState.value.intervalMs)

        manager.onCaptureStarted(1920, 1080)
        assertTrue(manager.analysisState.value.isCaptureActive)
        assertTrue(manager.analysisState.value.isAnalyzing)
        assertEquals(1920, manager.analysisState.value.frameWidth)
        assertEquals(1080, manager.analysisState.value.frameHeight)

        manager.onCaptureStopped()
        assertFalse(manager.analysisState.value.isCaptureActive)
        assertFalse(manager.analysisState.value.isAnalyzing)
    }

    @Test
    fun dlsVisionAnalyzer_configAndDataModels() {
        val analyzer = DlsVisionAnalyzer.instance
        assertNotNull(analyzer.detectionResult.value)

        analyzer.updateConfig {
            it.copy(ballBrightnessMin = 0.85f, grassHueMin = 65f)
        }
        assertEquals(0.85f, analyzer.config.value.ballBrightnessMin, 0.001f)
        assertEquals(65f, analyzer.config.value.grassHueMin, 0.001f)

        val ball = DlsVisionAnalyzer.DetectedBall(
            x = 100f,
            y = 200f,
            normX = 0.5f,
            normY = 0.5f,
            radius = 10f,
            confidence = 0.95f
        )
        assertEquals(100f, ball.x, 0.001f)
        assertEquals(200f, ball.y, 0.001f)
        assertTrue(ball.confidence > 0.9f)

        val player = DlsVisionAnalyzer.DetectedPlayer(
            id = 1,
            x = 150f,
            y = 250f,
            normX = 0.4f,
            normY = 0.6f,
            width = 30f,
            height = 50f,
            teamId = 1,
            hue = 210f,
            confidence = 0.88f
        )
        assertEquals(1, player.id)
        assertEquals(1, player.teamId)
        assertTrue(player.confidence > 0.8f)
    }

    @Test
    fun dlsGameStateAnalyzer_modelsAndStateEvaluation() {
        val analyzer = DlsGameStateAnalyzer.instance
        assertNotNull(analyzer.gameState.value)

        val ballState = DlsGameStateAnalyzer.BallState(
            x = 500f,
            y = 600f,
            normX = 0.5f,
            normY = 0.55f,
            velocityX = 150f,
            velocityY = -50f,
            speedPxPerSec = 158.1f,
            directionAngleDeg = 341.5f,
            directionName = "Up-Right (↗)",
            predictedX = 545f,
            predictedY = 585f,
            confidence = 0.92f,
            isTracked = true
        )
        assertEquals(500f, ballState.x, 0.01f)
        assertEquals(150f, ballState.velocityX, 0.01f)
        assertTrue(ballState.speedPxPerSec > 150f)
        assertTrue(ballState.isTracked)

        val trackedPlayer = DlsGameStateAnalyzer.TrackedPlayer(
            id = 7,
            x = 520f,
            y = 610f,
            normX = 0.52f,
            normY = 0.56f,
            width = 40f,
            height = 65f,
            teamId = 1,
            confidence = 0.89f,
            distanceToBall = 22.36f
        )
        val closestInfo = DlsGameStateAnalyzer.ClosestPlayerInfo(
            player = trackedPlayer,
            distancePx = 22.36f,
            teamName = "Team 1 (Blue/Cyan)",
            hasPossession = true
        )
        assertTrue(closestInfo.hasPossession)
        assertEquals(7, closestInfo.player.id)

        val teamGrouping = DlsGameStateAnalyzer.TeamGrouping(team1Count = 5, team2Count = 4, neutralCount = 1)
        assertEquals(5, teamGrouping.team1Count)
        assertEquals(4, teamGrouping.team2Count)
        assertEquals(1, teamGrouping.neutralCount)

        val gameState = DlsGameStateAnalyzer.GameState(
            phase = DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY,
            phaseDescription = "Match Active",
            ball = ballState,
            players = listOf(trackedPlayer),
            closestPlayer = closestInfo,
            teamGrouping = teamGrouping,
            overallConfidence = 0.88f
        )
        assertEquals(DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY, gameState.phase)
        assertEquals(1, gameState.players.size)
        assertTrue(gameState.overallConfidence > 0.8f)
    }

    @Test
    fun dlsDecisionEngine_modelsAndConfiguration() {
        val engine = DlsDecisionEngine.instance
        assertNotNull(engine.decision.value)
        assertNotNull(engine.config.value)

        engine.setActionCooldownMs(500L)
        assertEquals(500L, engine.config.value.actionCooldownMs)

        engine.setMinConfidenceThreshold(0.50f)
        assertEquals(0.50f, engine.config.value.minConfidenceThreshold, 0.01f)

        engine.toggleDebugOverlay()
        assertFalse(engine.config.value.isDebugOverlayEnabled)
        engine.toggleDebugOverlay()
        assertTrue(engine.config.value.isDebugOverlayEnabled)

        val decision = DlsDecisionEngine.Decision(
            actionType = DlsDecisionEngine.ActionType.CHASE_BALL,
            targetX = 640f,
            targetY = 360f,
            targetNormX = 0.5f,
            targetNormY = 0.5f,
            direction = "Right (→)",
            directionAngleDeg = 0f,
            durationMs = 300L,
            confidence = 0.90f,
            reason = "Loose ball nearby",
            timestampMs = 1000L,
            decisionLatencyMs = 2L
        )

        assertEquals(DlsDecisionEngine.ActionType.CHASE_BALL, decision.actionType)
        assertEquals(640f, decision.targetX!!, 0.01f)
        assertEquals(360f, decision.targetY!!, 0.01f)
        assertEquals("Right (→)", decision.direction)
        assertEquals(300L, decision.durationMs)
        assertEquals(0.90f, decision.confidence, 0.01f)
        assertEquals("Loose ball nearby", decision.reason)
    }

    @Test
    fun dlsDecisionEngine_actionTypesEnumIntegrity() {
        val types = DlsDecisionEngine.ActionType.values()
        assertTrue(types.contains(DlsDecisionEngine.ActionType.WAIT))
        assertTrue(types.contains(DlsDecisionEngine.ActionType.CHASE_BALL))
        assertTrue(types.contains(DlsDecisionEngine.ActionType.MOVE))
        assertTrue(types.contains(DlsDecisionEngine.ActionType.PASS))
        assertTrue(types.contains(DlsDecisionEngine.ActionType.SHOOT))
        assertTrue(types.contains(DlsDecisionEngine.ActionType.DEFEND))
    }

    @Test
    fun connectivityModeManager_modelsAndStateTransitions() {
        val manager = com.example.connectivity.ConnectivityModeManager.instance
        assertNotNull(manager.connectivityState.value)

        // Verify Enum integrity
        assertEquals("Online", com.example.connectivity.ConnectivityModeManager.ConnectionStatus.ONLINE.label)
        assertEquals("Offline", com.example.connectivity.ConnectivityModeManager.ConnectionStatus.OFFLINE.label)
        assertEquals("Checking...", com.example.connectivity.ConnectivityModeManager.ConnectionStatus.CHECKING.label)

        assertEquals("CAREER", com.example.connectivity.ConnectivityModeManager.GameMode.CAREER.label)
        assertEquals("EXHIBITION", com.example.connectivity.ConnectivityModeManager.GameMode.EXHIBITION.label)

        // Verify online state implies CAREER
        val onlineState = com.example.connectivity.ConnectivityModeManager.ConnectivityState(
            status = com.example.connectivity.ConnectivityModeManager.ConnectionStatus.ONLINE,
            isInternetAvailable = true,
            selectedMode = com.example.connectivity.ConnectivityModeManager.GameMode.CAREER,
            networkType = "Wi-Fi",
            latencyMs = 42L,
            lastCheckTime = "12:00:00 PM"
        )
        assertEquals(com.example.connectivity.ConnectivityModeManager.ConnectionStatus.ONLINE, onlineState.status)
        assertTrue(onlineState.isInternetAvailable)
        assertEquals(com.example.connectivity.ConnectivityModeManager.GameMode.CAREER, onlineState.selectedMode)

        // Verify offline state implies EXHIBITION
        val offlineState = com.example.connectivity.ConnectivityModeManager.ConnectivityState(
            status = com.example.connectivity.ConnectivityModeManager.ConnectionStatus.OFFLINE,
            isInternetAvailable = false,
            selectedMode = com.example.connectivity.ConnectivityModeManager.GameMode.EXHIBITION,
            networkType = "None",
            latencyMs = -1L,
            lastCheckTime = "12:01:00 PM"
        )
        assertEquals(com.example.connectivity.ConnectivityModeManager.ConnectionStatus.OFFLINE, offlineState.status)
        assertFalse(offlineState.isInternetAvailable)
        assertEquals(com.example.connectivity.ConnectivityModeManager.GameMode.EXHIBITION, offlineState.selectedMode)
    }
}


