package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.bot.BotController
import com.example.decision.DlsDecisionEngine
import com.example.execution.ActionExecutor
import com.example.gamestate.DlsGameStateAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("DLS Robot", appName)
  }

  @Test
  fun `verify Stage 7 ControlLoopConfig and State defaults`() {
    val config = BotController.ControlLoopConfig()
    assertEquals(100L, config.loopIntervalMs)
    assertTrue(config.autoPauseOnMenu)
    assertTrue(config.isConflictPreventionEnabled)

    val state = BotController.ControlLoopState()
    assertEquals(BotController.LoopStatus.STOPPED, state.status)
    assertEquals(0L, state.framesProcessed)
    assertEquals(0L, state.decisionsGenerated)
    assertEquals(0L, state.actionsExecuted)
    assertEquals(DlsGameStateAnalyzer.MatchPhase.UNKNOWN, state.currentPhase)
    assertEquals(ActionExecutor.ExecutionType.WAIT, state.lastActionType)
  }

  @Test
  fun `verify Stage 7 BotController emergency stop and pause`() {
    val controller = BotController.instance
    assertNotNull(controller)

    // Verify interval change
    controller.setLoopIntervalMs(200L)
    assertEquals(200L, controller.config.value.loopIntervalMs)

    // Emergency stop test
    controller.emergencyStop()
    assertEquals(BotController.LoopStatus.STOPPED, controller.loopState.value.status)
    assertEquals(BotController.BotState.Stopped, controller.botState.value)

    // Pause test
    controller.pauseBot("User paused")
    assertEquals(BotController.LoopStatus.PAUSED, controller.loopState.value.status)

    // Stop test
    controller.stopBot("User stopped")
    assertEquals(BotController.LoopStatus.STOPPED, controller.loopState.value.status)
  }

  @Test
  fun `verify Stage 7 pipeline integration components exist and are initialized`() {
    val gameStateAnalyzer = DlsGameStateAnalyzer.instance
    assertNotNull(gameStateAnalyzer)
    assertNotNull(gameStateAnalyzer.gameState.value)

    val decisionEngine = DlsDecisionEngine.instance
    assertNotNull(decisionEngine)
    assertNotNull(decisionEngine.decision.value)

    val actionExecutor = ActionExecutor.instance
    assertNotNull(actionExecutor)
    assertNotNull(actionExecutor.executionState.value)

    val botController = BotController.instance
    assertNotNull(botController)
    assertNotNull(botController.loopState.value)

    val connectivityManager = com.example.connectivity.ConnectivityModeManager.instance
    assertNotNull(connectivityManager)
    assertNotNull(connectivityManager.connectivityState.value)

    val orchestrator = com.example.orchestrator.AutonomousGameplayOrchestrator.instance
    assertNotNull(orchestrator)
    assertNotNull(orchestrator.orchestratorState.value)

    val lifecycleManager = com.example.lifecycle.MatchLifecycleManager.instance
    assertNotNull(lifecycleManager)
    assertNotNull(lifecycleManager.lifecycleTelemetry.value)
  }

  @Test
  fun `verify Stage 10 MatchLifecycleManager states and transitions`() {
    val lifecycleManager = com.example.lifecycle.MatchLifecycleManager.instance

    // Reset to start
    lifecycleManager.resetLifecycle("Test reset")
    val initialTelemetry = lifecycleManager.lifecycleTelemetry.value
    assertEquals(com.example.lifecycle.MatchLifecycleManager.LifecycleState.WAITING, initialTelemetry.lifecycleState)
    assertFalse(initialTelemetry.lifecycleState.isGameplayActive)
    assertFalse(initialTelemetry.isMatchStarted)
    assertFalse(initialTelemetry.isReadyForNextMatch)

    // Advance to MATCH_STARTING
    lifecycleManager.advanceToState(com.example.lifecycle.MatchLifecycleManager.LifecycleState.MATCH_STARTING)
    assertTrue(lifecycleManager.lifecycleTelemetry.value.isMatchDetected)
    assertFalse(lifecycleManager.lifecycleTelemetry.value.lifecycleState.isGameplayActive)

    // Advance to PLAYING
    lifecycleManager.advanceToState(com.example.lifecycle.MatchLifecycleManager.LifecycleState.PLAYING)
    assertTrue(lifecycleManager.lifecycleTelemetry.value.isMatchStarted)
    assertTrue(lifecycleManager.lifecycleTelemetry.value.lifecycleState.isGameplayActive)

    // Advance to MATCH_PAUSED
    lifecycleManager.advanceToState(com.example.lifecycle.MatchLifecycleManager.LifecycleState.MATCH_PAUSED)
    assertFalse(lifecycleManager.lifecycleTelemetry.value.lifecycleState.isGameplayActive)

    // Advance to MATCH_FINISHED
    lifecycleManager.advanceToState(com.example.lifecycle.MatchLifecycleManager.LifecycleState.MATCH_FINISHED)
    assertTrue(lifecycleManager.lifecycleTelemetry.value.isMatchFinished)
    assertFalse(lifecycleManager.lifecycleTelemetry.value.lifecycleState.isGameplayActive)

    // Advance to MATCH_RESULT
    lifecycleManager.advanceToState(com.example.lifecycle.MatchLifecycleManager.LifecycleState.MATCH_RESULT)
    assertTrue(lifecycleManager.lifecycleTelemetry.value.isResultScreenDetected)

    // Advance to RETURNING_TO_MENU
    lifecycleManager.advanceToState(com.example.lifecycle.MatchLifecycleManager.LifecycleState.RETURNING_TO_MENU)
    assertEquals(com.example.lifecycle.MatchLifecycleManager.LifecycleState.RETURNING_TO_MENU, lifecycleManager.lifecycleTelemetry.value.lifecycleState)

    // Advance to READY_FOR_NEXT_MATCH
    lifecycleManager.advanceToState(com.example.lifecycle.MatchLifecycleManager.LifecycleState.READY_FOR_NEXT_MATCH)
    assertTrue(lifecycleManager.lifecycleTelemetry.value.isReadyForNextMatch)

    // Emergency Stop
    lifecycleManager.emergencyStop()
    assertEquals(com.example.lifecycle.MatchLifecycleManager.LifecycleState.EMERGENCY_STOPPED, lifecycleManager.lifecycleTelemetry.value.lifecycleState)
    assertFalse(lifecycleManager.lifecycleTelemetry.value.lifecycleState.isGameplayActive)
  }
}

