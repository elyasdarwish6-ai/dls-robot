package com.example.connectivity

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Stage 8: Connectivity & Mode Manager
 *
 * Responsibilities:
 * 1. Accurately detect real internet availability (not just Wi-Fi or cellular link presence).
 * 2. Automatic mode selection: CAREER mode for reliable internet, EXHIBITION mode for offline.
 * 3. Reactive connectivity listener using ConnectivityManager.NetworkCallback.
 * 4. Manual on-demand connectivity checks with latency measurement.
 * 5. Full Android 14+ compatibility and resilient error handling.
 */
class ConnectivityModeManager private constructor() {

    companion object {
        private const val TAG = "ConnectivityModeManager"
        private const val SOCKET_TIMEOUT_MS = 2000
        private const val HTTP_TIMEOUT_MS = 2500
        private const val PROBE_URL = "https://clients3.google.com/generate_204"
        private const val FALLBACK_PROBE_URL = "https://www.google.com/generate_204"
        private const val DNS_PROBE_HOST = "8.8.8.8"
        private const val DNS_PROBE_PORT = 53

        @Volatile
        private var INSTANCE: ConnectivityModeManager? = null

        val instance: ConnectivityModeManager
            get() = INSTANCE ?: synchronized(this) {
                INSTANCE ?: ConnectivityModeManager().also { INSTANCE = it }
            }
    }

    enum class ConnectionStatus(val label: String, val badgeColorHex: Long) {
        ONLINE("Online", 0xFF10B981),        // Green
        OFFLINE("Offline", 0xFFEF4444),      // Red
        CHECKING("Checking...", 0xFFF59E0B)  // Amber
    }

    enum class GameMode(val label: String, val description: String, val badgeColorHex: Long) {
        CAREER("CAREER", "Online: Full career matches, events & cloud progression", 0xFF3B82F6),
        EXHIBITION("EXHIBITION", "Offline: Instant exhibition play without internet", 0xFFF97316)
    }

    data class ConnectivityState(
        val status: ConnectionStatus = ConnectionStatus.CHECKING,
        val isInternetAvailable: Boolean = false,
        val selectedMode: GameMode = GameMode.EXHIBITION,
        val lastCheckTime: String = "Not checked yet",
        val lastCheckTimestamp: Long = 0L,
        val latencyMs: Long = 0L,
        val networkType: String = "Unknown",
        val statusDetail: String = "Initializing connection check...",
        val isAutoCheckEnabled: Boolean = true
    )

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var activeCheckJob: Job? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var isCallbackRegistered = false

    private val _connectivityState = MutableStateFlow(ConnectivityState())
    val connectivityState: StateFlow<ConnectivityState> = _connectivityState.asStateFlow()

    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    /**
     * Initializes the network callback and performs an initial connectivity probe.
     */
    fun initialize(context: Context) {
        val appContext = context.applicationContext
        registerNetworkCallback(appContext)
        checkConnectivity(appContext)
    }

    /**
     * Registers system network callback to detect network transitions automatically.
     */
    @Synchronized
    fun registerNetworkCallback(context: Context) {
        if (isCallbackRegistered) return

        try {
            val connectivityManager =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            if (connectivityManager == null) {
                Log.w(TAG, "ConnectivityManager unavailable")
                return
            }

            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    Log.d(TAG, "Network onAvailable: $network")
                    checkConnectivity(context)
                }

                override fun onLost(network: Network) {
                    Log.d(TAG, "Network onLost: $network")
                    checkConnectivity(context)
                }

                override fun onCapabilitiesChanged(
                    network: Network,
                    networkCapabilities: NetworkCapabilities
                ) {
                    Log.d(TAG, "Network onCapabilitiesChanged: $network")
                    checkConnectivity(context)
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(callback)
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                connectivityManager.registerNetworkCallback(request, callback)
            }

            networkCallback = callback
            isCallbackRegistered = true
            Log.i(TAG, "ConnectivityManager.NetworkCallback successfully registered")
        } catch (e: Exception) {
            Log.e(TAG, "Error registering network callback", e)
        }
    }

    /**
     * Unregisters network callback when no longer needed.
     */
    @Synchronized
    fun unregisterNetworkCallback(context: Context) {
        if (!isCallbackRegistered || networkCallback == null) return
        try {
            val connectivityManager =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
            networkCallback = null
            isCallbackRegistered = false
            Log.i(TAG, "ConnectivityManager.NetworkCallback unregistered")
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering network callback", e)
        }
    }

    /**
     * Triggers a real connectivity verification check.
     */
    fun checkConnectivity(context: Context) {
        val appContext = context.applicationContext
        activeCheckJob?.cancel()
        activeCheckJob = scope.launch {
            _connectivityState.update { current ->
                current.copy(
                    status = ConnectionStatus.CHECKING,
                    statusDetail = "Probing real internet reachability..."
                )
            }

            val startTime = System.currentTimeMillis()
            val (hasLink, networkType, validatedByOs) = evaluateNetworkCapabilities(appContext)

            if (!hasLink) {
                val duration = System.currentTimeMillis() - startTime
                updateState(
                    isOnline = false,
                    networkType = "No Connection",
                    latencyMs = duration,
                    detail = "No active network link detected"
                )
                return@launch
            }

            // Real internet reachability probe (Socket / HTTP)
            val probeResult = probeRealInternetAccess()
            val duration = System.currentTimeMillis() - startTime

            if (probeResult.isSuccess) {
                updateState(
                    isOnline = true,
                    networkType = networkType,
                    latencyMs = probeResult.latencyMs.coerceAtLeast(duration),
                    detail = "Connected via $networkType (${probeResult.latencyMs}ms)"
                )
            } else {
                // If direct socket/HTTP probe fails but OS validated it, do a secondary quick probe
                if (validatedByOs) {
                    val secondaryProbe = probeHttpFallback()
                    if (secondaryProbe.isSuccess) {
                        updateState(
                            isOnline = true,
                            networkType = networkType,
                            latencyMs = secondaryProbe.latencyMs,
                            detail = "Connected via $networkType (${secondaryProbe.latencyMs}ms)"
                        )
                        return@launch
                    }
                }

                updateState(
                    isOnline = false,
                    networkType = networkType,
                    latencyMs = duration,
                    detail = "Network link active ($networkType) but no internet access: ${probeResult.message}"
                )
            }
        }
    }

    private fun evaluateNetworkCapabilities(context: Context): Triple<Boolean, String, Boolean> {
        return try {
            val connectivityManager =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                    ?: return Triple(false, "Unknown", false)

            val activeNetwork = connectivityManager.activeNetwork ?: return Triple(false, "Disconnected", false)
            val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
                ?: return Triple(false, "No Capabilities", false)

            val hasInternet = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            val isValidated = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)

            val type = when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                else -> "Network"
            }

            Triple(hasInternet, type, isValidated)
        } catch (e: Exception) {
            Log.e(TAG, "Error evaluating network capabilities", e)
            Triple(false, "Error: ${e.message}", false)
        }
    }

    private data class ProbeResult(
        val isSuccess: Boolean,
        val latencyMs: Long,
        val message: String
    )

    private suspend fun probeRealInternetAccess(): ProbeResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        // 1. First probe: Low-overhead socket connection to reliable DNS server
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(DNS_PROBE_HOST, DNS_PROBE_PORT), SOCKET_TIMEOUT_MS)
                val latency = System.currentTimeMillis() - start
                return@withContext ProbeResult(true, latency, "DNS probe succeeded")
            }
        } catch (e: Exception) {
            Log.d(TAG, "Socket probe failed (${e.message}), trying HTTP 204 probe...")
        }

        // 2. Second probe: HTTP 204 endpoint probe
        probeHttp(PROBE_URL)
    }

    private suspend fun probeHttpFallback(): ProbeResult = withContext(Dispatchers.IO) {
        probeHttp(FALLBACK_PROBE_URL)
    }

    private fun probeHttp(urlString: String): ProbeResult {
        val start = System.currentTimeMillis()
        var connection: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            connection = (url.openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = HTTP_TIMEOUT_MS
                readTimeout = HTTP_TIMEOUT_MS
                useCaches = false
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Android-DlsRobot/Stage8")
            }

            val responseCode = connection.responseCode
            val latency = System.currentTimeMillis() - start
            if (responseCode == 204 || responseCode == 200) {
                ProbeResult(true, latency, "HTTP $responseCode verified")
            } else {
                ProbeResult(false, latency, "HTTP unexpected status $responseCode (Captive portal suspected)")
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - start
            ProbeResult(false, latency, e.message ?: "Connection probe failed")
        } finally {
            connection?.disconnect()
        }
    }

    private fun updateState(
        isOnline: Boolean,
        networkType: String,
        latencyMs: Long,
        detail: String
    ) {
        val now = System.currentTimeMillis()
        val timeString = timeFormatter.format(Date(now))
        val selectedMode = if (isOnline) GameMode.CAREER else GameMode.EXHIBITION
        val status = if (isOnline) ConnectionStatus.ONLINE else ConnectionStatus.OFFLINE

        _connectivityState.update {
            it.copy(
                status = status,
                isInternetAvailable = isOnline,
                selectedMode = selectedMode,
                lastCheckTime = timeString,
                lastCheckTimestamp = now,
                latencyMs = latencyMs,
                networkType = networkType,
                statusDetail = detail
            )
        }

        Log.i(TAG, "Connectivity updated: status=$status, mode=$selectedMode, latency=${latencyMs}ms, type=$networkType")
    }
}
