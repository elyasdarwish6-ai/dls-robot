package com.example.execution

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Stage 6: Android AccessibilityService for real-time touch and swipe gesture dispatching.
 * Interacts with the game without simulated/mock inputs by dispatching real Accessibility Gestures
 * when enabled in Android system settings.
 */
class DlsAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "DlsAccessibilityService"

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        @Volatile
        var instance: DlsAccessibilityService? = null
            private set

        /**
         * Checks whether the DLS Robot accessibility service is currently enabled in Android system settings.
         */
        fun isAccessibilityEnabled(context: Context): Boolean {
            if (_isServiceConnected.value && instance != null) return true

            val expectedComponentName = ComponentName(context, DlsAccessibilityService::class.java).flattenToString()
            val expectedShortComponentName = ComponentName(context, DlsAccessibilityService::class.java).flattenToShortString()

            val enabledServicesSetting = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val colonSplitter = TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServicesSetting)

            while (colonSplitter.hasNext()) {
                val component = colonSplitter.next()
                if (component.equals(expectedComponentName, ignoreCase = true) ||
                    component.equals(expectedShortComponentName, ignoreCase = true)
                ) {
                    return true
                }
            }
            return false
        }

        /**
         * Opens Android Accessibility Settings so the user can easily enable the service.
         */
        fun openAccessibilitySettings(context: Context) {
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to open accessibility settings", e)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
        Log.i(TAG, "DLS Accessibility Service connected successfully")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance == this) {
            instance = null
            _isServiceConnected.value = false
        }
        Log.i(TAG, "DLS Accessibility Service unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
            _isServiceConnected.value = false
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Accessibility events monitoring if needed for app foreground state
    }

    override fun onInterrupt() {
        Log.w(TAG, "DLS Accessibility Service interrupted")
    }

    /**
     * Dispatches a touch gesture path asynchronously with a callback on completion.
     */
    fun dispatchGesturePath(
        path: Path,
        durationMs: Long,
        startTimeMs: Long = 0L,
        onComplete: (Boolean) -> Unit
    ) {
        val safeDuration = durationMs.coerceIn(10L, 5000L)
        val stroke = GestureDescription.StrokeDescription(path, startTimeMs, safeDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    onComplete(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                    Log.w(TAG, "Gesture dispatch cancelled by system")
                    onComplete(false)
                }
            },
            null
        )
    }
}
