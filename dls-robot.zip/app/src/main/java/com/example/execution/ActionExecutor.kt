package com.example.execution

import android.graphics.Path
import android.util.Log
import com.example.decision.DlsDecisionEngine
import com.example.gamestate.DlsGameStateAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

/**
 * Stage 6: Safe Action Execution Module for DLS Robot.
 * Converts Stage 5 tactical decisions into concrete touch and gesture actions
 * (WAIT, TAP, HOLD, RELEASE, SWIPE, MOVE) and dispatches them via Android AccessibilityService.
 * Includes conflict prevention, cooldowns, confidence filtering, and emergency stop.
 */
class ActionExecutor private constructor(
    private val decisionEngine: DlsDecisionEngine = DlsDecisionEngine.instance,
    private val gameStateAnalyzer: DlsGameStateAnalyzer = DlsGameStateAnalyzer.instance
) {

    companion object {
        private const val TAG = "ActionExecutor"
        val instance: ActionExecutor by lazy { ActionExecutor() }
    }

    enum class ExecutionType(val label: String, val colorHex: Long) {
        WAIT("WAIT", 0xFF9E9E9E),
        TAP("TAP", 0xFF00E5FF),
        HOLD("HOLD", 0xFFFFD600),
        RELEASE("RELEASE", 0xFFB0BEC5),
        SWIPE("SWIPE", 0xFFFF1744),
        MOVE("MOVE", 0xFF76FF03)
    }

    data class ExecutionCommand(
        val type: ExecutionType = ExecutionType.WAIT,
        val startX: Float? = null,
        val startY: Float? = null,
        val endX: Float? = null,
        val endY: Float? = null,
        val durationMs: Long = 60L,
        val confidence: Float = 0f,
        val sourceDecision: DlsDecisionEngine.ActionType = DlsDecisionEngine.ActionType.WAIT,
        val reason: String = "Idle"
    )

    data class ExecutionState(
        val lastCommand: ExecutionCommand = ExecutionCommand(),
        val isExecuting: Boolean = false,
        val lastSuccess: Boolean = true,
        val statusMessage: String = "Idle - Waiting for active bot",
        val lastExecutionTimestampMs: Long = 0L,
        val latencyMs: Long = 0L,
        val totalExecutedCount: Long = 0L,
        val failedCount: Long = 0L
    )

    data class ExecutorConfig(
        val defaultTapDurationMs: Long = 60L,
        val defaultHoldDurationMs: Long = 350L,
        val defaultSwipeDurationMs: Long = 180L,
        val defaultMoveDurationMs: Long = 250L,
        val minConfidenceThreshold: Float = 0.40f,
        val cooldownMs: Long = 180L,
        val isExecutionEnabled: Boolean = true,
        val isBotRunning: Boolean = false
    )

    private val executorScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _executionState = MutableStateFlow(ExecutionState())
    val executionState: StateFlow<ExecutionState> = _executionState.asStateFlow()

    private val _config = MutableStateFlow(ExecutorConfig())
    val config: StateFlow<ExecutorConfig> = _config.asStateFlow()

    private var activeGestureJob: Job? = null
    private var lastExecutionTimestamp: Long = 0L
    private var isHoldingDown: Boolean = false
    private var currentHoldX: Float? = null
    private var currentHoldY: Float? = null

    init {
        // Automatically listen to decisions from Stage 5
        executorScope.launch {
            decisionEngine.decision.collectLatest { decision ->
                val cfg = _config.value
                if (cfg.isBotRunning && cfg.isExecutionEnabled) {
                    executeDecision(decision)
                }
            }
        }
    }

    fun setBotRunning(running: Boolean) {
        _config.update { it.copy(isBotRunning = running) }
        if (!running) {
            stopAllActions()
            _executionState.update {
                it.copy(
                    isExecuting = false,
                    statusMessage = "Bot stopped - execution suspended"
                )
            }
        } else {
            _executionState.update {
                it.copy(
                    statusMessage = "Bot running - listening for Stage 5 decisions"
                )
            }
        }
    }

    fun setExecutionEnabled(enabled: Boolean) {
        _config.update { it.copy(isExecutionEnabled = enabled) }
        if (!enabled) {
            stopAllActions()
        }
    }

    fun setCooldownMs(cooldownMs: Long) {
        _config.update { it.copy(cooldownMs = cooldownMs) }
    }

    fun setMinConfidence(threshold: Float) {
        _config.update { it.copy(minConfidenceThreshold = threshold.coerceIn(0.1f, 0.9f)) }
    }

    fun updateConfig(update: (ExecutorConfig) -> ExecutorConfig) {
        _config.update(update)
    }

    /**
     * Converts a Stage 5 tactical Decision into low-level touch commands and executes them.
     */
    fun executeDecision(decision: DlsDecisionEngine.Decision) {
        val cfg = _config.value
        val gs = gameStateAnalyzer.gameState.value
        val frameW = gs.frameWidth.toFloat().takeIf { it > 0 } ?: 1280f
        val frameH = gs.frameHeight.toFloat().takeIf { it > 0 } ?: 720f

        // Check confidence filter
        if (decision.confidence < cfg.minConfidenceThreshold || decision.actionType == DlsDecisionEngine.ActionType.WAIT) {
            executeAction(
                ExecutionCommand(
                    type = ExecutionType.WAIT,
                    confidence = decision.confidence,
                    sourceDecision = decision.actionType,
                    reason = "Decision in WAIT state or below confidence threshold (${(decision.confidence * 100).toInt()}%)"
                )
            )
            return
        }

        // Virtual joystick anchor on left side (typically 18% width, 75% height)
        val joystickCenterX = frameW * 0.18f
        val joystickCenterY = frameH * 0.75f
        val joystickRadius = frameW * 0.08f

        // Action buttons area on right side (B: Pass, A: Shoot, C: Cross/Defend)
        val passButtonX = frameW * 0.88f
        val passButtonY = frameH * 0.82f

        val shootButtonX = frameW * 0.82f
        val shootButtonY = frameH * 0.68f

        val defendButtonX = frameW * 0.94f
        val defendButtonY = frameH * 0.68f

        val command = when (decision.actionType) {
            DlsDecisionEngine.ActionType.CHASE_BALL, DlsDecisionEngine.ActionType.MOVE -> {
                val angleDeg = decision.directionAngleDeg ?: 0f
                val rad = Math.toRadians(angleDeg.toDouble())
                val targetStickX = (joystickCenterX + cos(rad) * joystickRadius).toFloat()
                val targetStickY = (joystickCenterY + sin(rad) * joystickRadius).toFloat()

                ExecutionCommand(
                    type = ExecutionType.MOVE,
                    startX = joystickCenterX,
                    startY = joystickCenterY,
                    endX = targetStickX,
                    endY = targetStickY,
                    durationMs = cfg.defaultMoveDurationMs,
                    confidence = decision.confidence,
                    sourceDecision = decision.actionType,
                    reason = "Joystick movement towards ${decision.direction}"
                )
            }

            DlsDecisionEngine.ActionType.PASS -> {
                ExecutionCommand(
                    type = ExecutionType.TAP,
                    startX = passButtonX,
                    startY = passButtonY,
                    durationMs = cfg.defaultTapDurationMs,
                    confidence = decision.confidence,
                    sourceDecision = decision.actionType,
                    reason = "Tap pass button [B] targeting teammate"
                )
            }

            DlsDecisionEngine.ActionType.SHOOT -> {
                ExecutionCommand(
                    type = ExecutionType.HOLD,
                    startX = shootButtonX,
                    startY = shootButtonY,
                    durationMs = cfg.defaultHoldDurationMs,
                    confidence = decision.confidence,
                    sourceDecision = decision.actionType,
                    reason = "Hold shoot button [A] on attacking lane"
                )
            }

            DlsDecisionEngine.ActionType.DEFEND -> {
                ExecutionCommand(
                    type = ExecutionType.TAP,
                    startX = defendButtonX,
                    startY = defendButtonY,
                    durationMs = cfg.defaultTapDurationMs,
                    confidence = decision.confidence,
                    sourceDecision = decision.actionType,
                    reason = "Tap pressure/containment button [C]"
                )
            }

            DlsDecisionEngine.ActionType.WAIT -> {
                ExecutionCommand(
                    type = ExecutionType.WAIT,
                    confidence = decision.confidence,
                    sourceDecision = decision.actionType,
                    reason = decision.reason
                )
            }
        }

        executeAction(command)
    }

    /**
     * Executes a low-level ExecutionCommand with conflict prevention and safety checks.
     */
    fun executeAction(command: ExecutionCommand) {
        val startTime = System.currentTimeMillis()
        val cfg = _config.value
        val now = System.currentTimeMillis()

        // 1. Safety check: Handle WAIT or RELEASE
        if (command.type == ExecutionType.WAIT) {
            if (isHoldingDown && currentHoldX != null && currentHoldY != null) {
                release(currentHoldX!!, currentHoldY!!)
            }
            _executionState.update {
                it.copy(
                    lastCommand = command,
                    isExecuting = false,
                    statusMessage = "Action: WAIT (${command.reason})",
                    lastExecutionTimestampMs = now,
                    latencyMs = 0L
                )
            }
            return
        }

        // 2. Cooldown check to prevent action thrashing
        if (now - lastExecutionTimestamp < cfg.cooldownMs && command.type != ExecutionType.RELEASE) {
            Log.d(TAG, "Action dropped by cooldown (${now - lastExecutionTimestamp}ms < ${cfg.cooldownMs}ms)")
            return
        }

        // 3. Stop any existing conflicting gesture before launching a new one
        activeGestureJob?.cancel()

        activeGestureJob = executorScope.launch {
            val service = DlsAccessibilityService.instance
            if (service == null) {
                _executionState.update {
                    it.copy(
                        lastCommand = command,
                        isExecuting = false,
                        lastSuccess = false,
                        statusMessage = "Accessibility Service is not enabled/connected",
                        lastExecutionTimestampMs = now,
                        latencyMs = System.currentTimeMillis() - startTime,
                        failedCount = it.failedCount + 1
                    )
                }
                return@launch
            }

            lastExecutionTimestamp = now

            _executionState.update {
                it.copy(
                    lastCommand = command,
                    isExecuting = true,
                    statusMessage = "Executing ${command.type.label} (${command.reason})",
                    lastExecutionTimestampMs = now
                )
            }

            when (command.type) {
                ExecutionType.TAP -> {
                    val x = command.startX ?: 0f
                    val y = command.startY ?: 0f
                    tapInternal(service, x, y, command.durationMs, startTime, command)
                }

                ExecutionType.HOLD -> {
                    val x = command.startX ?: 0f
                    val y = command.startY ?: 0f
                    holdInternal(service, x, y, command.durationMs, startTime, command)
                }

                ExecutionType.RELEASE -> {
                    val x = command.startX ?: 0f
                    val y = command.startY ?: 0f
                    releaseInternal(x, y, startTime, command)
                }

                ExecutionType.SWIPE -> {
                    val sx = command.startX ?: 0f
                    val sy = command.startY ?: 0f
                    val ex = command.endX ?: sx
                    val ey = command.endY ?: sy
                    swipeInternal(service, sx, sy, ex, ey, command.durationMs, startTime, command)
                }

                ExecutionType.MOVE -> {
                    val sx = command.startX ?: 0f
                    val sy = command.startY ?: 0f
                    val ex = command.endX ?: sx
                    val ey = command.endY ?: sy
                    swipeInternal(service, sx, sy, ex, ey, command.durationMs, startTime, command)
                }

                ExecutionType.WAIT -> {
                    // Handled above
                }
            }
        }
    }

    /**
     * Direct Tap helper
     */
    fun tap(x: Float, y: Float, durationMs: Long = _config.value.defaultTapDurationMs) {
        executeAction(
            ExecutionCommand(
                type = ExecutionType.TAP,
                startX = x,
                startY = y,
                durationMs = durationMs,
                confidence = 1.0f,
                reason = "Direct Tap at ($x, $y)"
            )
        )
    }

    /**
     * Direct Hold helper
     */
    fun hold(x: Float, y: Float, durationMs: Long = _config.value.defaultHoldDurationMs) {
        executeAction(
            ExecutionCommand(
                type = ExecutionType.HOLD,
                startX = x,
                startY = y,
                durationMs = durationMs,
                confidence = 1.0f,
                reason = "Direct Hold at ($x, $y) for ${durationMs}ms"
            )
        )
    }

    /**
     * Direct Release helper
     */
    fun release(x: Float, y: Float) {
        isHoldingDown = false
        currentHoldX = null
        currentHoldY = null
        _executionState.update {
            it.copy(
                isExecuting = false,
                statusMessage = "Released touch at ($x, $y)"
            )
        }
    }

    /**
     * Direct Swipe helper
     */
    fun swipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = _config.value.defaultSwipeDurationMs
    ) {
        executeAction(
            ExecutionCommand(
                type = ExecutionType.SWIPE,
                startX = startX,
                startY = startY,
                endX = endX,
                endY = endY,
                durationMs = durationMs,
                confidence = 1.0f,
                reason = "Direct Swipe from ($startX, $startY) to ($endX, $endY)"
            )
        )
    }

    /**
     * Direct Move helper (e.g. Joystick dragging)
     */
    fun move(
        fromX: Float,
        fromY: Float,
        toX: Float,
        toY: Float,
        durationMs: Long = _config.value.defaultMoveDurationMs
    ) {
        executeAction(
            ExecutionCommand(
                type = ExecutionType.MOVE,
                startX = fromX,
                startY = fromY,
                endX = toX,
                endY = toY,
                durationMs = durationMs,
                confidence = 1.0f,
                reason = "Direct Move from ($fromX, $fromY) to ($toX, $toY)"
            )
        )
    }

    /**
     * Emergency Stop: Cancels all ongoing gesture jobs, releases touches, and resets execution state.
     */
    fun stopAllActions() {
        activeGestureJob?.cancel()
        executorScope.coroutineContext.cancelChildren()
        isHoldingDown = false
        currentHoldX = null
        currentHoldY = null

        _executionState.update {
            it.copy(
                lastCommand = ExecutionCommand(type = ExecutionType.WAIT, reason = "EMERGENCY STOPPED"),
                isExecuting = false,
                lastSuccess = true,
                statusMessage = "EMERGENCY STOP ACTIVATED - All gestures cancelled",
                lastExecutionTimestampMs = System.currentTimeMillis(),
                latencyMs = 0L
            )
        }
        Log.w(TAG, "Emergency STOP executed: All actions cancelled.")
    }

    private fun tapInternal(
        service: DlsAccessibilityService,
        x: Float,
        y: Float,
        durationMs: Long,
        startTime: Long,
        command: ExecutionCommand
    ) {
        val path = Path().apply {
            moveTo(x, y)
        }

        service.dispatchGesturePath(path, durationMs) { success ->
            val latency = System.currentTimeMillis() - startTime
            _executionState.update {
                it.copy(
                    isExecuting = false,
                    lastSuccess = success,
                    statusMessage = if (success) "Tap completed at (${x.toInt()}, ${y.toInt()})" else "Tap gesture failed",
                    lastExecutionTimestampMs = System.currentTimeMillis(),
                    latencyMs = latency,
                    totalExecutedCount = if (success) it.totalExecutedCount + 1 else it.totalExecutedCount,
                    failedCount = if (!success) it.failedCount + 1 else it.failedCount
                )
            }
        }
    }

    private fun holdInternal(
        service: DlsAccessibilityService,
        x: Float,
        y: Float,
        durationMs: Long,
        startTime: Long,
        command: ExecutionCommand
    ) {
        isHoldingDown = true
        currentHoldX = x
        currentHoldY = y

        val path = Path().apply {
            moveTo(x, y)
        }

        service.dispatchGesturePath(path, durationMs) { success ->
            val latency = System.currentTimeMillis() - startTime
            isHoldingDown = false
            _executionState.update {
                it.copy(
                    isExecuting = false,
                    lastSuccess = success,
                    statusMessage = if (success) "Hold completed at (${x.toInt()}, ${y.toInt()}) [${durationMs}ms]" else "Hold gesture failed",
                    lastExecutionTimestampMs = System.currentTimeMillis(),
                    latencyMs = latency,
                    totalExecutedCount = if (success) it.totalExecutedCount + 1 else it.totalExecutedCount,
                    failedCount = if (!success) it.failedCount + 1 else it.failedCount
                )
            }
        }
    }

    private fun releaseInternal(
        x: Float,
        y: Float,
        startTime: Long,
        command: ExecutionCommand
    ) {
        isHoldingDown = false
        currentHoldX = null
        currentHoldY = null
        val latency = System.currentTimeMillis() - startTime

        _executionState.update {
            it.copy(
                isExecuting = false,
                lastSuccess = true,
                statusMessage = "Released touch",
                lastExecutionTimestampMs = System.currentTimeMillis(),
                latencyMs = latency,
                totalExecutedCount = it.totalExecutedCount + 1
            )
        }
    }

    private fun swipeInternal(
        service: DlsAccessibilityService,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long,
        startTime: Long,
        command: ExecutionCommand
    ) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        service.dispatchGesturePath(path, durationMs) { success ->
            val latency = System.currentTimeMillis() - startTime
            _executionState.update {
                it.copy(
                    isExecuting = false,
                    lastSuccess = success,
                    statusMessage = if (success) "Swipe from (${startX.toInt()}, ${startY.toInt()}) to (${endX.toInt()}, ${endY.toInt()})" else "Swipe gesture failed",
                    lastExecutionTimestampMs = System.currentTimeMillis(),
                    latencyMs = latency,
                    totalExecutedCount = if (success) it.totalExecutedCount + 1 else it.totalExecutedCount,
                    failedCount = if (!success) it.failedCount + 1 else it.failedCount
                )
            }
        }
    }
}
