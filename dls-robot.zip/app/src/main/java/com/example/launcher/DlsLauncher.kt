package com.example.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Handles package checking and launching for Dream League Soccer (DLS).
 */
class DlsLauncher {

    companion object {
        const val DLS_PACKAGE_NAME = "com.firsttouchgames.dls7"
    }

    sealed interface LaunchResult {
        object Success : LaunchResult
        data class NotInstalled(val packageName: String) : LaunchResult
        data class Error(val message: String) : LaunchResult
    }

    sealed interface Status {
        object Unknown : Status
        object Installed : Status
        object NotInstalled : Status
        object Launched : Status
    }

    /**
     * Checks whether DLS is installed on the device.
     */
    fun isInstalled(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            pm.getPackageInfo(DLS_PACKAGE_NAME, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            // Also check launch intent as fallback
            context.packageManager.getLaunchIntentForPackage(DLS_PACKAGE_NAME) != null
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Attempts to launch the DLS application.
     */
    fun launch(context: Context): LaunchResult {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(DLS_PACKAGE_NAME)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                LaunchResult.Success
            } else {
                LaunchResult.NotInstalled(DLS_PACKAGE_NAME)
            }
        } catch (e: SecurityException) {
            LaunchResult.Error("Security exception launching DLS: ${e.localizedMessage}")
        } catch (e: Exception) {
            LaunchResult.Error("Failed to launch DLS: ${e.localizedMessage ?: "Unknown error"}")
        }
    }
}
