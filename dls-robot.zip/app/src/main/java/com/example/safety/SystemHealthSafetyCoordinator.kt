package com.example.safety

import android.content.Context
import android.util.Log
import com.example.analysis.ImageAnalysisManager
import com.example.bot.BotController
import com.example.capture.ScreenCaptureManager
import com.example.connectivity.ConnectivityModeManager
import com.example.decision.DlsDecisionEngine
import com.example.execution.ActionExecutor
import com.example.execution.DlsAccessibilityService
import com.example.gamestate.DlsGameStateAnalyzer
import com.example.lifecycle.MatchLifecycleManager
import com.example.orchestrator.AutonomousGameplayOrchestrator
import com.example.vision.DlsVisionAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Stage 11: Final Integration, Safety & Stability Coordinator
 *
 * Requirements:
 * 1. Complete end-to-end integration:
 *    Screen Capture -> Vision Analysis -> Game State -> Decision Engine -> Action Execution -> Match Lifecycle -> Mode Manager
 * 2. Central System Status:
 *    - System Status
 *    - Screen Capture Status
 *    - Vision Status
 *    - Game State Status
 *    - Decision Engine Status
 *    - Action Execution Status
 *    - Match Lifecycle Status
 *    - Connectivity/Mode Status
 *    - Overall Confidence
 *    - Last Error
 * 3. Safe Start Automation & Stop Automation system.
 * 4. Emergency Stop: Immediate halt across all pipelines, blocking all actions until safely restarted.
 * 5. Safe state fallback & Recovery:
 *    - Screen capture lost
 *    - Accessibility service disconnect
 *    - Vision data invalid
 *    - Low confidence
 *    - Unexpected errors
 * 6. Protection against duplicate, conflicting, or excessively rapid touch actions.
 */
class SystemHealthSafetyCoordinator private constructor(
    private val captureManager: ScreenCaptureManager = ScreenCaptureManager.instance,
    private val visionAnalyzer: DlsVisionAnalyzer = DlsVisionAnalyzer.instance,
    private val analysisManager: ImageAnalysisManager = ImageAnalysisManager.instance,
    private val gameStateAnalyzer: DlsGameStateAnalyzer = DlsGameStateAnalyzer.instance,
    private val decisionEngine: DlsDecisionEngine = DlsDecisionEngine.instance,
    private val actionExecutor: ActionExecutor = ActionExecutor.instance,
    private val botController: BotController = BotController.instance,
    private val lifecycleManager: MatchLifecycleManager = MatchLifecycleManager.instance,
    private val connectivityManager: ConnectivityModeManager = ConnectivityModeManager.instance,
    private val orchestrator: AutonomousGameplayOrchestrator = AutonomousGameplayOrchestrator.instance
) {

    companion object {
        private const val TAG = "SystemHealthCoordinator"
        val instance: SystemHealthSafetyCoordinator by lazy { SystemHealthSafetyCoordinator() }
    }

    enum class CentralSystemStatus(val label: String, val colorHex: Long, val isOperational: Boolean) {
        STANDBY_READY("STANDBY / READY", 0xFF00B0FF, true),
        OPTIMAL_RUNNING("PIPELINE ACTIVE", 0xFF00E676, true),
        SAFE_WAITING("SAFE WAIT (PAUSED / GATED)", 0xFFFFD600, true),
        DEGRADED_CAUTION("DEGRADED (LOW CONFIDENCE)", 0xFFFF9100, true),
        ERROR_HALTED("ERROR (SERVICE OFFLINE)", 0xFFFF1744, false),
        EMERGENCY_STOPPED("EMERGENCY STOPPED", 0xFFFF1744, false)
    }

    data class PipelineHealthTelemetry(
        // Central System Status
        val systemStatus: CentralSystemStatus = CentralSystemStatus.STANDBY_READY,

        // Component Statuses
        val screenCaptureStatus: String = "IDLE",
        val isScreenCaptureActive: Boolean = false,

        val visionStatus: String = "SEARCHING",
        val isVisionValid: Boolean = false,

        val gameStateStatus: String = "UNKNOWN",
        val isGameStateStable: Boolean = false,

        val decisionEngineStatus: String = "IDLE",
        val currentDecisionAction: String = "WAIT",

        val actionExecutionStatus: String = "READY",
        val isAccessibilityConnected: Boolean = false,

        val matchLifecycleStatus: String = "WAITING",
        val isGameplayGateOpen: Boolean = false,

        val connectivityModeStatus: String = "EXHIBITION (OFFLINE)",
        val isInternetReachabilityConfirmed: Boolean = false,

        // Overall Confidence & Safety
        val overallConfidence: Float = 0f,
        val lastError: String? = null,
        val safeRecoveryReason: String? = null,

        // Pipeline Timing & Performance
        val endToEndPipelineLatencyMs: Long = 0L,
        val totalProcessedFrames: Long = 0L,
        val totalDispatchedTouches: Long = 0L,
        val totalSkippedSafeFrames: Long = 0L,
        val isEmergencyStopTriggered: Boolean = false
    )

    private val coordinatorScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _healthTelemetry = MutableStateFlow(PipelineHealthTelemetry())
    val healthTelemetry: StateFlow<PipelineHealthTelemetry> = _healthTelemetry.asStateFlow()

    private var lastRecordedError: String? = null
    private var isEmergencyHalted: Boolean = false

    private data class Stage1To4(
        val captureState: ScreenCaptureManager.CaptureState,
        val isAccConnected: Boolean,
        val visionResult: DlsVisionAnalyzer.DetectionResult,
        val gameState: DlsGameStateAnalyzer.GameState
    )

    private data class Stage5To8(
        val decision: DlsDecisionEngine.Decision,
        val lifecycle: MatchLifecycleManager.LifecycleTelemetry,
        val connectivity: ConnectivityModeManager.ConnectivityState
    )

    init {
        startHealthMonitoring()
    }

    private fun startHealthMonitoring() {
        val stage1To4Flow = combine(
            captureManager.captureState,
            DlsAccessibilityService.isServiceConnected,
            visionAnalyzer.detectionResult,
            gameStateAnalyzer.gameState
        ) { captureState, isAccConnected, visionResult, gameState ->
            Stage1To4(captureState, isAccConnected, visionResult, gameState)
        }

        val stage5To8Flow = combine(
            decisionEngine.decision,
            lifecycleManager.lifecycleTelemetry,
            connectivityManager.connectivityState
        ) { decision, lifecycle, connectivity ->
            Stage5To8(decision, lifecycle, connectivity)
        }

        combine(stage1To4Flow, stage5To8Flow) { st14, st58 ->
            evaluateSystemHealth(
                captureState = st14.captureState,
                isAccConnected = st14.isAccConnected,
                visionResult = st14.visionResult,
                gameState = st14.gameState,
                decision = st58.decision,
                lifecycle = st58.lifecycle,
                connectivity = st58.connectivity
            )
        }.onEach { newTelemetry ->
            _healthTelemetry.value = newTelemetry
        }.launchIn(coordinatorScope)
    }

    private fun evaluateSystemHealth(
        captureState: ScreenCaptureManager.CaptureState,
        isAccConnected: Boolean,
        visionResult: DlsVisionAnalyzer.DetectionResult,
        gameState: DlsGameStateAnalyzer.GameState,
        decision: DlsDecisionEngine.Decision,
        lifecycle: MatchLifecycleManager.LifecycleTelemetry,
        connectivity: ConnectivityModeManager.ConnectivityState
    ): PipelineHealthTelemetry {
        val orchState = orchestrator.orchestratorState.value
        val execState = actionExecutor.executionState.value

        val isCaptureActive = captureState is ScreenCaptureManager.CaptureState.Capturing
        val capStatusStr = when (captureState) {
            is ScreenCaptureManager.CaptureState.Capturing -> "CAPTURING (${captureState.frameCount} Frames)"
            is ScreenCaptureManager.CaptureState.Error -> {
                lastRecordedError = captureState.message
                "ERROR (${captureState.message})"
            }
            ScreenCaptureManager.CaptureState.Idle -> "STOPPED"
            ScreenCaptureManager.CaptureState.Starting -> "INITIALIZING"
        }

        val isVisionFieldOk = visionResult.isFieldDetected && ((visionResult.fieldRegion?.grassCoveragePercent ?: 0f) > 15f || visionResult.players.isNotEmpty())
        val visStatusStr = if (isVisionFieldOk) {
            "FIELD DETECTED (${visionResult.players.size} Players, Ball: ${if (visionResult.ball != null) "YES" else "SEARCHING"})"
        } else {
            "SEARCHING FIELD / UI"
        }

        val isStateOk = gameState.phase == DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY
        val stateStatusStr = "${gameState.phase.label} (Ball: ${if (gameState.ball?.isTracked == true) "TRACKED" else "UNTRAK"})"

        val decStatusStr = "${decision.actionType.label} (${(decision.confidence * 100).toInt()}% Conf)"

        val accStatusStr = if (!isAccConnected) {
            lastRecordedError = "Accessibility Service is disconnected"
            "SERVICE DISCONNECTED"
        } else if (execState.isExecuting) {
            "EXECUTING (${execState.lastCommand.type.name})"
        } else {
            "READY"
        }

        val lifeStatusStr = lifecycle.lifecycleState.label
        val connStatusStr = "${connectivity.selectedMode.name} (${if (connectivity.isInternetAvailable) "ONLINE" else "OFFLINE"})"

        // Compute aggregate overall confidence score across all pipeline stages
        var confidenceScore = 0f
        if (isCaptureActive) confidenceScore += 0.20f
        if (isAccConnected) confidenceScore += 0.20f
        if (isVisionFieldOk) confidenceScore += 0.25f
        if (isStateOk) confidenceScore += 0.15f
        confidenceScore += (decision.confidence * 0.20f)

        val finalConfidence = confidenceScore.coerceIn(0f, 1f)

        // Central System Status Decision
        var systemStatus: CentralSystemStatus
        var safeRecovery: String? = null

        if (isEmergencyHalted || orchState.isEmergencyStopActive || lifecycle.lifecycleState == MatchLifecycleManager.LifecycleState.EMERGENCY_STOPPED) {
            systemStatus = CentralSystemStatus.EMERGENCY_STOPPED
            safeRecovery = "Emergency stop is active. Touch actions completely locked."
        } else if (!isAccConnected || captureState is ScreenCaptureManager.CaptureState.Error) {
            systemStatus = CentralSystemStatus.ERROR_HALTED
            safeRecovery = if (!isAccConnected) "Accessibility Service offline" else "Screen capture error"
        } else if (!isCaptureActive) {
            systemStatus = CentralSystemStatus.STANDBY_READY
            safeRecovery = "Screen capture offline. Start capture to activate pipeline."
        } else if (orchState.automationStatus == AutonomousGameplayOrchestrator.AutomationStatus.RUNNING) {
            if (!lifecycle.lifecycleState.isGameplayActive) {
                systemStatus = CentralSystemStatus.SAFE_WAITING
                safeRecovery = "Actions safely gated: Match state is ${lifecycle.lifecycleState.label}"
            } else if (decision.confidence < 0.35f || !isVisionFieldOk) {
                systemStatus = CentralSystemStatus.DEGRADED_CAUTION
                safeRecovery = "Low confidence frame ($finalConfidence) - Executing safe wait"
            } else {
                systemStatus = CentralSystemStatus.OPTIMAL_RUNNING
                safeRecovery = null
            }
        } else if (orchState.automationStatus == AutonomousGameplayOrchestrator.AutomationStatus.PAUSED) {
            systemStatus = CentralSystemStatus.SAFE_WAITING
            safeRecovery = "Automation is paused"
        } else {
            systemStatus = CentralSystemStatus.STANDBY_READY
            safeRecovery = "Automation ready to start"
        }

        val totalPipelineLatency = orchState.loopLatencyMs

        return PipelineHealthTelemetry(
            systemStatus = systemStatus,
            screenCaptureStatus = capStatusStr,
            isScreenCaptureActive = isCaptureActive,
            visionStatus = visStatusStr,
            isVisionValid = isVisionFieldOk,
            gameStateStatus = stateStatusStr,
            isGameStateStable = isStateOk,
            decisionEngineStatus = decStatusStr,
            currentDecisionAction = decision.actionType.label,
            actionExecutionStatus = accStatusStr,
            isAccessibilityConnected = isAccConnected,
            matchLifecycleStatus = lifeStatusStr,
            isGameplayGateOpen = lifecycle.lifecycleState.isGameplayActive,
            connectivityModeStatus = connStatusStr,
            isInternetReachabilityConfirmed = connectivity.isInternetAvailable,
            overallConfidence = finalConfidence,
            lastError = lastRecordedError,
            safeRecoveryReason = safeRecovery,
            endToEndPipelineLatencyMs = totalPipelineLatency,
            totalProcessedFrames = orchState.totalCycles,
            totalDispatchedTouches = execState.totalExecutedCount,
            totalSkippedSafeFrames = orchState.skippedFramesCount,
            isEmergencyStopTriggered = isEmergencyHalted
        )
    }

    /**
     * Safe Start Automation with full pipeline validation.
     */
    fun startSafeAutomation(): Result<Unit> {
        isEmergencyHalted = false
        lastRecordedError = null

        // Validate Screen Capture
        if (!captureManager.isCapturing) {
            val err = "Screen Capture is not running. Please start Screen Capture before enabling Automation."
            lastRecordedError = err
            Log.w(TAG, err)
            return Result.failure(IllegalStateException(err))
        }

        // Validate Accessibility Service
        if (!DlsAccessibilityService.isServiceConnected.value) {
            val err = "Accessibility Service is disconnected. Please enable 'DLS Robot Action Service' in Android Settings."
            lastRecordedError = err
            Log.w(TAG, err)
            return Result.failure(IllegalStateException(err))
        }

        // Start Orchestrator
        val orchResult = orchestrator.startAutomation()
        if (orchResult.isFailure) {
            lastRecordedError = orchResult.exceptionOrNull()?.message
            return orchResult
        }

        Log.i(TAG, "Stage 11: Safe Automation started successfully.")
        return Result.success(Unit)
    }

    /**
     * Safe Stop Automation: Gracefully terminates execution and resets actions.
     */
    fun stopSafeAutomation(reason: String = "Automation stopped by user") {
        orchestrator.stopAutomation(reason)
        actionExecutor.stopAllActions()
        Log.i(TAG, "Stage 11: Safe Automation stopped: $reason")
    }

    /**
     * Emergency Stop: Instant safety override halting all background processes and touch inputs.
     */
    fun triggerEmergencyStop() {
        isEmergencyHalted = true
        lastRecordedError = "EMERGENCY STOP TRIGGERED"
        orchestrator.emergencyStop()
        actionExecutor.stopAllActions()
        botController.emergencyStop()
        lifecycleManager.emergencyStop()
        Log.w(TAG, "Stage 11: EMERGENCY STOP TRIGGERED ACROSS ENTIRE PIPELINE.")
    }

    /**
     * Resets emergency halt state.
     */
    fun resetEmergencyStop() {
        isEmergencyHalted = false
        lastRecordedError = null
        lifecycleManager.resetLifecycle("Emergency Stop Cleared")
        Log.i(TAG, "Stage 11: Emergency Stop cleared.")
    }

    /**
     * Quick System Diagnostics & Health Check.
     */
    fun performDiagnosticHealthCheck(context: Context): String {
        connectivityManager.checkConnectivity(context)
        val capOk = captureManager.isCapturing
        val accOk = DlsAccessibilityService.isServiceConnected.value
        val visOk = visionAnalyzer.detectionResult.value.isFieldDetected
        return "Diagnostic: Capture=${if (capOk) "OK" else "OFF"}, Accessibility=${if (accOk) "OK" else "OFF"}, Vision=${if (visOk) "PITCH_OK" else "SEARCHING"}"
    }
}
