package com.example.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import com.example.analysis.ImageAnalysisManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Stage 3: Real Local Computer-Vision Analyzer for Dream League Soccer.
 * Performs fast, efficient, local on-device computer vision to detect:
 * - DLS Grass Pitch / Game Field
 * - Ball position, radius, and confidence
 * - Player positions, bounding boxes, team color hue, and confidence
 */
class DlsVisionAnalyzer private constructor() : ImageAnalysisManager.FrameAnalyzer {

    companion object {
        private const val TAG = "DlsVisionAnalyzer"
        val instance: DlsVisionAnalyzer by lazy { DlsVisionAnalyzer() }
    }

    data class DetectedBall(
        val x: Float,
        val y: Float,
        val normX: Float,
        val normY: Float,
        val radius: Float,
        val confidence: Float
    )

    data class DetectedPlayer(
        val id: Int,
        val x: Float,
        val y: Float,
        val normX: Float,
        val normY: Float,
        val width: Float,
        val height: Float,
        val teamId: Int, // 1 = Home, 2 = Away, 0 = Neutral / Ref
        val hue: Float,
        val confidence: Float
    )

    data class FieldRegion(
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val grassCoveragePercent: Float
    )

    data class VisionConfig(
        val grassHueMin: Float = 60f,
        val grassHueMax: Float = 160f,
        val grassSatMin: Float = 0.20f,
        val grassValMin: Float = 0.15f,
        val ballBrightnessMin: Float = 0.78f,
        val playerClusterMinSize: Int = 4,
        val playerClusterMaxSize: Int = 180,
        val isDebugOverlayEnabled: Boolean = true
    )

    data class DetectionResult(
        val timestampMs: Long = 0L,
        val isFieldDetected: Boolean = false,
        val fieldRegion: FieldRegion? = null,
        val ball: DetectedBall? = null,
        val players: List<DetectedPlayer> = emptyList(),
        val processingDurationMs: Long = 0L,
        val frameWidth: Int = 0,
        val frameHeight: Int = 0,
        val status: String = "No frame analyzed"
    )

    private val _config = MutableStateFlow(VisionConfig())
    val config: StateFlow<VisionConfig> = _config.asStateFlow()

    private val _detectionResult = MutableStateFlow(DetectionResult())
    val detectionResult: StateFlow<DetectionResult> = _detectionResult.asStateFlow()

    // Downsampled processing grid dimensions for fast local inference (<10ms)
    private val gridWidth = 240
    private val gridHeight = 135

    private val pixelBuffer = IntArray(gridWidth * gridHeight)
    private val hsvBuffer = FloatArray(3)
    private val isGrassGrid = BooleanArray(gridWidth * gridHeight)
    private val visitedGrid = BooleanArray(gridWidth * gridHeight)

    init {
        // Automatically register with ImageAnalysisManager
        ImageAnalysisManager.instance.setAnalyzer(this)
    }

    fun updateConfig(update: (VisionConfig) -> VisionConfig) {
        _config.value = update(_config.value)
    }

    override fun analyze(bitmap: Bitmap, timestampMs: Long) {
        val startTime = System.currentTimeMillis()
        val origWidth = bitmap.width
        val origHeight = bitmap.height

        if (origWidth <= 0 || origHeight <= 0) return

        try {
            // 1. Downsample bitmap to working grid for fast local image processing
            val scaledBitmap = Bitmap.createScaledBitmap(bitmap, gridWidth, gridHeight, false)
            scaledBitmap.getPixels(pixelBuffer, 0, gridWidth, 0, 0, gridWidth, gridHeight)
            if (scaledBitmap != bitmap) {
                scaledBitmap.recycle()
            }

            val currentConfig = _config.value

            // 2. Field (Grass) Segmentation
            var grassPixelCount = 0
            var minGrassX = gridWidth
            var maxGrassX = 0
            var minGrassY = gridHeight
            var maxGrassY = 0

            for (y in 0 until gridHeight) {
                for (x in 0 until gridWidth) {
                    val idx = y * gridWidth + x
                    val color = pixelBuffer[idx]
                    Color.colorToHSV(color, hsvBuffer)
                    val h = hsvBuffer[0]
                    val s = hsvBuffer[1]
                    val v = hsvBuffer[2]

                    val isGrass = (h in currentConfig.grassHueMin..currentConfig.grassHueMax) &&
                            (s >= currentConfig.grassSatMin) &&
                            (v >= currentConfig.grassValMin)

                    isGrassGrid[idx] = isGrass
                    visitedGrid[idx] = false

                    if (isGrass) {
                        grassPixelCount++
                        if (x < minGrassX) minGrassX = x
                        if (x > maxGrassX) maxGrassX = x
                        if (y < minGrassY) minGrassY = y
                        if (y > maxGrassY) maxGrassY = y
                    }
                }
            }

            val totalPixels = gridWidth * gridHeight
            val grassCoverage = (grassPixelCount.toFloat() / totalPixels)
            val isField = grassCoverage >= 0.15f

            val fieldRegion = if (isField && maxGrassX > minGrassX && maxGrassY > minGrassY) {
                val scaleX = origWidth.toFloat() / gridWidth
                val scaleY = origHeight.toFloat() / gridHeight
                FieldRegion(
                    left = minGrassX * scaleX,
                    top = minGrassY * scaleY,
                    right = maxGrassX * scaleX,
                    bottom = maxGrassY * scaleY,
                    grassCoveragePercent = grassCoverage * 100f
                )
            } else {
                null
            }

            // 3. Local Ball Detection
            var detectedBall: DetectedBall? = null
            if (isField) {
                detectedBall = detectBall(
                    pixelBuffer = pixelBuffer,
                    isGrassGrid = isGrassGrid,
                    origWidth = origWidth,
                    origHeight = origHeight,
                    minGrassY = minGrassY,
                    maxGrassY = maxGrassY,
                    minGrassX = minGrassX,
                    maxGrassX = maxGrassX,
                    config = currentConfig
                )
            }

            // 4. Local Player Detection
            val detectedPlayers = if (isField) {
                detectPlayers(
                    pixelBuffer = pixelBuffer,
                    isGrassGrid = isGrassGrid,
                    visitedGrid = visitedGrid,
                    origWidth = origWidth,
                    origHeight = origHeight,
                    minGrassY = minGrassY,
                    maxGrassY = maxGrassY,
                    minGrassX = minGrassX,
                    maxGrassX = maxGrassX,
                    config = currentConfig
                )
            } else {
                emptyList()
            }

            val duration = System.currentTimeMillis() - startTime

            val statusText = if (isField) {
                "Field Detected (${(grassCoverage * 100).toInt()}% pitch) | Ball: ${if (detectedBall != null) "Yes" else "No"} | Players: ${detectedPlayers.size}"
            } else {
                "No DLS field detected (${(grassCoverage * 100).toInt()}% grass)"
            }

            _detectionResult.value = DetectionResult(
                timestampMs = timestampMs,
                isFieldDetected = isField,
                fieldRegion = fieldRegion,
                ball = detectedBall,
                players = detectedPlayers,
                processingDurationMs = duration,
                frameWidth = origWidth,
                frameHeight = origHeight,
                status = statusText
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error in vision analysis", e)
        }
    }

    /**
     * Local Ball Detector: Looks for high-contrast, compact, bright white/yellow circular spot
     * within the soccer pitch region surrounded by grass.
     */
    private fun detectBall(
        pixelBuffer: IntArray,
        isGrassGrid: BooleanArray,
        origWidth: Int,
        origHeight: Int,
        minGrassY: Int,
        maxGrassY: Int,
        minGrassX: Int,
        maxGrassX: Int,
        config: VisionConfig
    ): DetectedBall? {
        var bestScore = 0f
        var bestX = -1
        var bestY = -1
        val tempHsv = FloatArray(3)

        // Search within field boundary
        val yStart = max(1, minGrassY)
        val yEnd = min(gridHeight - 2, maxGrassY)
        val xStart = max(1, minGrassX)
        val xEnd = min(gridWidth - 2, maxGrassX)

        for (y in yStart..yEnd) {
            for (x in xStart..xEnd) {
                val idx = y * gridWidth + x
                val color = pixelBuffer[idx]

                Color.colorToHSV(color, tempHsv)
                val h = tempHsv[0]
                val s = tempHsv[1]
                val v = tempHsv[2]

                // Ball criteria: High brightness, low/moderate saturation, or bright white/yellow
                if (v >= config.ballBrightnessMin && s <= 0.55f && (h < 50f || h > 170f || s < 0.20f)) {
                    // Check local contrast with neighborhood (is it a compact spot surrounded by grass?)
                    var grassNeighbors = 0
                    for (dy in -2..2) {
                        for (dx in -2..2) {
                            if (dx == 0 && dy == 0) continue
                            val ny = y + dy
                            val nx = x + dx
                            if (nx in 0 until gridWidth && ny in 0 until gridHeight) {
                                if (isGrassGrid[ny * gridWidth + nx]) {
                                    grassNeighbors++
                                }
                            }
                        }
                    }

                    // Score candidate based on brightness, whiteness, and grass contrast
                    val contrastFactor = grassNeighbors.toFloat() / 24f
                    val brightnessFactor = v
                    val whitenessFactor = (1f - s)
                    val score = (brightnessFactor * 0.4f) + (whitenessFactor * 0.3f) + (contrastFactor * 0.3f)

                    if (score > bestScore && score > 0.65f) {
                        bestScore = score
                        bestX = x
                        bestY = y
                    }
                }
            }
        }

        return if (bestX != -1 && bestY != -1) {
            val scaleX = origWidth.toFloat() / gridWidth
            val scaleY = origHeight.toFloat() / gridHeight
            val px = bestX * scaleX
            val py = bestY * scaleY
            val radius = max(6f, 5f * ((scaleX + scaleY) / 2f))

            DetectedBall(
                x = px,
                y = py,
                normX = px / origWidth,
                normY = py / origHeight,
                radius = radius,
                confidence = bestScore.coerceIn(0f, 1f)
            )
        } else {
            null
        }
    }

    /**
     * Local Player Detector: Identifies non-grass player blobs (kits, silhouettes) standing
     * on the field, clusters them, estimates bounding boxes and team hues.
     */
    private fun detectPlayers(
        pixelBuffer: IntArray,
        isGrassGrid: BooleanArray,
        visitedGrid: BooleanArray,
        origWidth: Int,
        origHeight: Int,
        minGrassY: Int,
        maxGrassY: Int,
        minGrassX: Int,
        maxGrassX: Int,
        config: VisionConfig
    ): List<DetectedPlayer> {
        val players = mutableListOf<DetectedPlayer>()
        val scaleX = origWidth.toFloat() / gridWidth
        val scaleY = origHeight.toFloat() / gridHeight

        // Queue for iterative flood fill clustering
        val queueX = IntArray(gridWidth * gridHeight)
        val queueY = IntArray(gridWidth * gridHeight)
        val tempHsv = FloatArray(3)

        val yStart = max(1, minGrassY)
        val yEnd = min(gridHeight - 2, maxGrassY)
        val xStart = max(1, minGrassX)
        val xEnd = min(gridWidth - 2, maxGrassX)

        var playerId = 1

        for (y in yStart..yEnd) {
            for (x in xStart..xEnd) {
                val idx = y * gridWidth + x

                // Foreground pixel candidate: not grass, not yet visited
                if (!isGrassGrid[idx] && !visitedGrid[idx]) {
                    // Start flood-fill cluster
                    var qHead = 0
                    var qTail = 0

                    queueX[qTail] = x
                    queueY[qTail] = y
                    qTail++
                    visitedGrid[idx] = true

                    var clusterMinX = x
                    var clusterMaxX = x
                    var clusterMinY = y
                    var clusterMaxY = y
                    var sumX = 0L
                    var sumY = 0L
                    var clusterCount = 0
                    var dominantHueSum = 0.0

                    while (qHead < qTail) {
                        val cx = queueX[qHead]
                        val cy = queueY[qHead]
                        qHead++
                        clusterCount++
                        sumX += cx
                        sumY += cy

                        if (cx < clusterMinX) clusterMinX = cx
                        if (cx > clusterMaxX) clusterMaxX = cx
                        if (cy < clusterMinY) clusterMinY = cy
                        if (cy > clusterMaxY) clusterMaxY = cy

                        val cIdx = cy * gridWidth + cx
                        Color.colorToHSV(pixelBuffer[cIdx], tempHsv)
                        dominantHueSum += tempHsv[0]

                        // Check 4-connected neighbors
                        val neighbors = arrayOf(cx - 1 to cy, cx + 1 to cy, cx to cy - 1, cx to cy + 1)
                        for ((nx, ny) in neighbors) {
                            if (nx in xStart..xEnd && ny in yStart..yEnd) {
                                val nIdx = ny * gridWidth + nx
                                if (!isGrassGrid[nIdx] && !visitedGrid[nIdx]) {
                                    visitedGrid[nIdx] = true
                                    queueX[qTail] = nx
                                    queueY[qTail] = ny
                                    qTail++
                                }
                            }
                        }
                    }

                    // Check if cluster matches player dimensions
                    val cWidth = clusterMaxX - clusterMinX + 1
                    val cHeight = clusterMaxY - clusterMinY + 1

                    if (clusterCount in config.playerClusterMinSize..config.playerClusterMaxSize &&
                        cWidth <= 35 && cHeight <= 45 && cHeight >= 2
                    ) {
                        val centerX = (sumX.toFloat() / clusterCount) * scaleX
                        val feetY = clusterMaxY.toFloat() * scaleY
                        val boxWidth = max(cWidth * scaleX, 16f)
                        val boxHeight = max(cHeight * scaleY, 24f)
                        val avgHue = (dominantHueSum / clusterCount).toFloat()

                        // Classify team by hue (Team 1 vs Team 2)
                        val teamId = when {
                            avgHue in 180f..260f -> 1 // Blue / Cyan kits
                            avgHue in 0f..45f || avgHue in 330f..360f -> 2 // Red / Orange kits
                            avgHue in 45f..75f -> 1 // Yellow kits
                            else -> 0 // Neutral / Dark / White
                        }

                        val confidence = (clusterCount.toFloat() / 25f).coerceIn(0.4f, 0.98f)

                        players.add(
                            DetectedPlayer(
                                id = playerId++,
                                x = centerX,
                                y = feetY,
                                normX = centerX / origWidth,
                                normY = feetY / origHeight,
                                width = boxWidth,
                                height = boxHeight,
                                teamId = teamId,
                                hue = avgHue,
                                confidence = confidence
                            )
                        )
                    }
                }
            }
        }

        // Limit to top 22 most confident player detections
        return players.sortedByDescending { it.confidence }.take(22)
    }
}
