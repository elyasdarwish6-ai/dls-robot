package com.example.ui

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.analysis.ImageAnalysisManager
import com.example.bot.BotController
import com.example.capture.ScreenCaptureManager
import com.example.capture.ScreenCaptureService
import com.example.connectivity.ConnectivityModeManager
import com.example.decision.DlsDecisionEngine
import com.example.execution.ActionExecutor
import com.example.execution.DlsAccessibilityService
import com.example.gamestate.DlsGameStateAnalyzer
import com.example.launcher.DlsLauncher
import com.example.lifecycle.MatchLifecycleManager
import com.example.orchestrator.AutonomousGameplayOrchestrator
import com.example.safety.SystemHealthSafetyCoordinator
import com.example.vision.DlsVisionAnalyzer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class MainUiState(
    val dlsStatusDescription: String = "Not Checked",
    val isDlsInstalled: Boolean = false,
    val captureState: ScreenCaptureManager.CaptureState = ScreenCaptureManager.CaptureState.Idle,
    val analysisState: ImageAnalysisManager.AnalysisState = ImageAnalysisManager.AnalysisState(),
    val visionResult: DlsVisionAnalyzer.DetectionResult = DlsVisionAnalyzer.DetectionResult(),
    val visionConfig: DlsVisionAnalyzer.VisionConfig = DlsVisionAnalyzer.VisionConfig(),
    val gameState: DlsGameStateAnalyzer.GameState = DlsGameStateAnalyzer.GameState(),
    val decision: DlsDecisionEngine.Decision = DlsDecisionEngine.Decision(),
    val decisionConfig: DlsDecisionEngine.DecisionConfig = DlsDecisionEngine.DecisionConfig(),
    val isAccessibilityConnected: Boolean = false,
    val executionState: ActionExecutor.ExecutionState = ActionExecutor.ExecutionState(),
    val executorConfig: ActionExecutor.ExecutorConfig = ActionExecutor.ExecutorConfig(),
    val botState: BotController.BotState = BotController.BotState.Stopped,
    val controlLoopState: BotController.ControlLoopState = BotController.ControlLoopState(),
    val controlLoopConfig: BotController.ControlLoopConfig = BotController.ControlLoopConfig(),
    val connectivityState: ConnectivityModeManager.ConnectivityState = ConnectivityModeManager.ConnectivityState(),
    val orchestratorState: AutonomousGameplayOrchestrator.OrchestratorState = AutonomousGameplayOrchestrator.OrchestratorState(),
    val orchestratorConfig: AutonomousGameplayOrchestrator.OrchestratorConfig = AutonomousGameplayOrchestrator.OrchestratorConfig(),
    val lifecycleTelemetry: MatchLifecycleManager.LifecycleTelemetry = MatchLifecycleManager.LifecycleTelemetry(),
    val healthTelemetry: SystemHealthSafetyCoordinator.PipelineHealthTelemetry = SystemHealthSafetyCoordinator.PipelineHealthTelemetry(),
    val userMessage: String? = null
)

class MainViewModel(
    private val dlsLauncher: DlsLauncher = DlsLauncher(),
    private val captureManager: ScreenCaptureManager = ScreenCaptureManager.instance,
    private val analysisManager: ImageAnalysisManager = ImageAnalysisManager.instance,
    private val visionAnalyzer: DlsVisionAnalyzer = DlsVisionAnalyzer.instance,
    private val gameStateAnalyzer: DlsGameStateAnalyzer = DlsGameStateAnalyzer.instance,
    private val decisionEngine: DlsDecisionEngine = DlsDecisionEngine.instance,
    private val actionExecutor: ActionExecutor = ActionExecutor.instance,
    private val botController: BotController = BotController.instance,
    private val connectivityManager: ConnectivityModeManager = ConnectivityModeManager.instance,
    private val orchestrator: AutonomousGameplayOrchestrator = AutonomousGameplayOrchestrator.instance,
    private val lifecycleManager: MatchLifecycleManager = MatchLifecycleManager.instance,
    private val safetyCoordinator: SystemHealthSafetyCoordinator = SystemHealthSafetyCoordinator.instance
) : ViewModel() {

    private val _dlsStatusDescription = MutableStateFlow("Not Checked")
    private val _isDlsInstalled = MutableStateFlow(false)
    private val _userMessage = MutableStateFlow<String?>(null)

    private data class AppCaptureData(
        val dlsDesc: String,
        val isInstalled: Boolean,
        val captureState: ScreenCaptureManager.CaptureState,
        val analysisState: ImageAnalysisManager.AnalysisState,
        val connectivityState: ConnectivityModeManager.ConnectivityState
    )

    private data class VisionStateData(
        val visionResult: DlsVisionAnalyzer.DetectionResult,
        val visionConfig: DlsVisionAnalyzer.VisionConfig,
        val gameState: DlsGameStateAnalyzer.GameState,
        val decision: DlsDecisionEngine.Decision,
        val decisionConfig: DlsDecisionEngine.DecisionConfig
    )

    private data class ExecutionBotData(
        val isAccConnected: Boolean,
        val executionState: ActionExecutor.ExecutionState,
        val executorConfig: ActionExecutor.ExecutorConfig,
        val botState: BotController.BotState,
        val controlLoopState: BotController.ControlLoopState,
        val controlLoopConfig: BotController.ControlLoopConfig,
        val orchestratorState: AutonomousGameplayOrchestrator.OrchestratorState,
        val orchestratorConfig: AutonomousGameplayOrchestrator.OrchestratorConfig,
        val lifecycleTelemetry: MatchLifecycleManager.LifecycleTelemetry,
        val healthTelemetry: SystemHealthSafetyCoordinator.PipelineHealthTelemetry,
        val message: String?
    )

    private val appCaptureFlow = combine(
        _dlsStatusDescription,
        _isDlsInstalled,
        captureManager.captureState,
        analysisManager.analysisState,
        connectivityManager.connectivityState
    ) { desc, inst, cap, ana, conn ->
        AppCaptureData(desc, inst, cap, ana, conn)
    }

    private val visionStateFlow = combine(
        visionAnalyzer.detectionResult,
        visionAnalyzer.config,
        gameStateAnalyzer.gameState,
        decisionEngine.decision,
        decisionEngine.config
    ) { vis, vcfg, gs, dec, dcfg ->
        VisionStateData(vis, vcfg, gs, dec, dcfg)
    }

    private val executionBotFlow = combine(
        combine(
            DlsAccessibilityService.isServiceConnected,
            actionExecutor.executionState,
            actionExecutor.config
        ) { acc, exec, ecfg -> Triple(acc, exec, ecfg) },
        combine(
            botController.botState,
            botController.loopState,
            botController.config
        ) { bot, loop, lcfg -> Triple(bot, loop, lcfg) },
        combine(
            orchestrator.orchestratorState,
            orchestrator.config,
            lifecycleManager.lifecycleTelemetry,
            safetyCoordinator.healthTelemetry,
            _userMessage
        ) { orch, ocfg, life, health, msg -> Quintuple(orch, ocfg, life, health, msg) }
    ) { execTriple, botTriple, orchQuint ->
        ExecutionBotData(
            isAccConnected = execTriple.first,
            executionState = execTriple.second,
            executorConfig = execTriple.third,
            botState = botTriple.first,
            controlLoopState = botTriple.second,
            controlLoopConfig = botTriple.third,
            orchestratorState = orchQuint.first,
            orchestratorConfig = orchQuint.second,
            lifecycleTelemetry = orchQuint.third,
            healthTelemetry = orchQuint.fourth,
            message = orchQuint.fifth
        )
    }

    private data class Quintuple<A, B, C, D, E>(val first: A, val second: B, val third: C, val fourth: D, val fifth: E)

    val uiState: StateFlow<MainUiState> = combine(
        appCaptureFlow,
        visionStateFlow,
        executionBotFlow
    ) { appCap, visState, execBot ->
        MainUiState(
            dlsStatusDescription = appCap.dlsDesc,
            isDlsInstalled = appCap.isInstalled,
            captureState = appCap.captureState,
            analysisState = appCap.analysisState,
            visionResult = visState.visionResult,
            visionConfig = visState.visionConfig,
            gameState = visState.gameState,
            decision = visState.decision,
            decisionConfig = visState.decisionConfig,
            isAccessibilityConnected = execBot.isAccConnected,
            executionState = execBot.executionState,
            executorConfig = execBot.executorConfig,
            botState = execBot.botState,
            controlLoopState = execBot.controlLoopState,
            controlLoopConfig = execBot.controlLoopConfig,
            connectivityState = appCap.connectivityState,
            orchestratorState = execBot.orchestratorState,
            orchestratorConfig = execBot.orchestratorConfig,
            lifecycleTelemetry = execBot.lifecycleTelemetry,
            healthTelemetry = execBot.healthTelemetry,
            userMessage = execBot.message
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState()
    )

    fun refreshDlsStatus(context: Context) {
        val installed = dlsLauncher.isInstalled(context)
        _isDlsInstalled.value = installed
        _dlsStatusDescription.value = if (installed) "Installed (Ready)" else "Not Installed"
    }

    fun launchDls(context: Context) {
        refreshDlsStatus(context)
        when (val result = dlsLauncher.launch(context)) {
            is DlsLauncher.LaunchResult.Success -> {
                _dlsStatusDescription.value = "Launched (Active)"
                _userMessage.value = "Launching Dream League Soccer..."
            }
            is DlsLauncher.LaunchResult.NotInstalled -> {
                _dlsStatusDescription.value = "Not Installed"
                _userMessage.value = "DLS is not installed on this device (com.firsttouchgames.dls7)."
            }
            is DlsLauncher.LaunchResult.Error -> {
                _userMessage.value = result.message
            }
        }
    }

    fun handleCapturePermissionResult(
        context: Context,
        resultCode: Int,
        data: Intent?,
        width: Int,
        height: Int,
        densityDpi: Int
    ) {
        if (resultCode == android.app.Activity.RESULT_OK && data != null) {
            ScreenCaptureService.start(
                context = context,
                resultCode = resultCode,
                resultData = data,
                width = width,
                height = height,
                densityDpi = densityDpi
            )
            _userMessage.value = "Screen capture started."
        } else {
            _userMessage.value = "Screen capture permission was cancelled or denied."
        }
    }

    fun stopScreenCapture(context: Context) {
        ScreenCaptureService.stop(context)
        captureManager.stopCapture()
        _userMessage.value = "Screen capture stopped and resources released."
    }

    fun setAnalysisInterval(intervalMs: Long) {
        botController.setLoopIntervalMs(intervalMs)
    }

    fun setControlLoopInterval(intervalMs: Long) {
        botController.setLoopIntervalMs(intervalMs)
    }

    fun toggleAutoPauseOnMenu() {
        val current = uiState.value.controlLoopConfig.autoPauseOnMenu
        botController.setAutoPauseOnMenu(!current)
        _userMessage.value = if (!current) "Auto-Pause on Menu/Cutscenes Enabled" else "Auto-Pause on Menu Disabled"
    }

    fun toggleDebugOverlay() {
        visionAnalyzer.updateConfig {
            it.copy(isDebugOverlayEnabled = !it.isDebugOverlayEnabled)
        }
    }

    fun updateBallBrightnessMin(value: Float) {
        visionAnalyzer.updateConfig {
            it.copy(ballBrightnessMin = value)
        }
    }

    fun updateGrassHueRange(minHue: Float, maxHue: Float) {
        visionAnalyzer.updateConfig {
            it.copy(grassHueMin = minHue, grassHueMax = maxHue)
        }
    }

    fun setDecisionCooldownMs(cooldownMs: Long) {
        decisionEngine.setActionCooldownMs(cooldownMs)
    }

    fun setDecisionMinConfidence(threshold: Float) {
        decisionEngine.setMinConfidenceThreshold(threshold)
    }

    fun toggleDecisionDebugOverlay() {
        decisionEngine.toggleDebugOverlay()
    }

    // Stage 6 & 7 Action Execution & Control Loop functions
    fun openAccessibilitySettings(context: Context) {
        DlsAccessibilityService.openAccessibilitySettings(context)
    }

    fun emergencyStop() {
        orchestrator.emergencyStop()
        botController.emergencyStop()
        actionExecutor.stopAllActions()
        _userMessage.value = "EMERGENCY STOPPED: All automation, control loops, and touch gestures cancelled immediately."
    }

    // Stage 9: Autonomous Gameplay Orchestrator controls
    fun startAutomation() {
        val result = orchestrator.startAutomation()
        if (result.isSuccess) {
            _userMessage.value = "Autonomous gameplay automation STARTED successfully."
        } else {
            _userMessage.value = result.exceptionOrNull()?.message ?: "Failed to start automation"
        }
    }

    fun stopAutomation() {
        orchestrator.stopAutomation("Automation stopped by user")
        _userMessage.value = "Autonomous gameplay automation stopped."
    }

    fun pauseAutomation() {
        orchestrator.pauseAutomation("Automation paused by user")
        _userMessage.value = "Autonomous gameplay automation paused."
    }

    fun resumeAutomation() {
        val result = orchestrator.resumeAutomation()
        if (result.isSuccess) {
            _userMessage.value = "Autonomous gameplay automation resumed."
        } else {
            _userMessage.value = result.exceptionOrNull()?.message ?: "Failed to resume automation"
        }
    }

    fun setAutomationMinConfidence(threshold: Float) {
        orchestrator.setMinConfidenceThreshold(threshold)
    }

    fun setAutomationCooldownMs(cooldownMs: Long) {
        orchestrator.setActionCooldownMs(cooldownMs)
    }

    fun toggleAutomationAutoPause() {
        val current = uiState.value.orchestratorConfig.autoPauseOnMenu
        orchestrator.setAutoPauseOnMenu(!current)
        _userMessage.value = if (!current) "Auto-Pause on Menu Enabled" else "Auto-Pause on Menu Disabled"
    }

    fun toggleExecutionEnabled() {
        val current = uiState.value.executorConfig.isExecutionEnabled
        actionExecutor.setExecutionEnabled(!current)
        _userMessage.value = if (!current) "Action Execution Enabled" else "Action Execution Disabled (Observation Mode)"
    }

    fun setExecutionCooldownMs(cooldownMs: Long) {
        actionExecutor.setCooldownMs(cooldownMs)
    }

    fun setExecutionMinConfidence(threshold: Float) {
        actionExecutor.setMinConfidence(threshold)
    }

    fun testTap(x: Float, y: Float) {
        actionExecutor.tap(x, y)
    }

    fun testSwipe(startX: Float, startY: Float, endX: Float, endY: Float) {
        actionExecutor.swipe(startX, startY, endX, endY)
    }

    fun testMove(fromX: Float, fromY: Float, toX: Float, toY: Float) {
        actionExecutor.move(fromX, fromY, toX, toY)
    }

    fun startBot() {
        val result = botController.startBot()
        if (result.isSuccess) {
            _userMessage.value = "Real-time control loop STARTED successfully."
        } else {
            _userMessage.value = result.exceptionOrNull()?.message ?: "Failed to start bot"
        }
    }

    fun stopBot() {
        botController.stopBot()
        _userMessage.value = "Bot control loop stopped."
    }

    fun pauseBot() {
        botController.pauseBot("Paused by user")
        _userMessage.value = "Bot control loop paused."
    }

    fun resumeBot() {
        val result = botController.resumeBot()
        if (result.isSuccess) {
            _userMessage.value = "Bot control loop resumed."
        } else {
            _userMessage.value = result.exceptionOrNull()?.message ?: "Failed to resume bot"
        }
    }

    // Stage 8: Connectivity & Mode Manager
    fun initializeConnectivity(context: Context) {
        connectivityManager.initialize(context)
    }

    fun checkConnectivity(context: Context) {
        connectivityManager.checkConnectivity(context)
    }

    // Stage 10: Match Lifecycle Manager
    fun resetLifecycle() {
        lifecycleManager.resetLifecycle("Reset by user")
        _userMessage.value = "Match Lifecycle state reset to WAITING."
    }

    fun advanceLifecycleState(targetState: MatchLifecycleManager.LifecycleState) {
        lifecycleManager.advanceToState(targetState)
        _userMessage.value = "Match Lifecycle transitioned to ${targetState.label}."
    }

    // Stage 11: Central Pipeline, Safety & Stability
    fun startSafeAutomation() {
        val result = safetyCoordinator.startSafeAutomation()
        if (result.isSuccess) {
            _userMessage.value = "Stage 11: Safe Automation started across entire pipeline."
        } else {
            _userMessage.value = result.exceptionOrNull()?.message ?: "Failed to start Safe Automation"
        }
    }

    fun stopSafeAutomation() {
        safetyCoordinator.stopSafeAutomation("Automation safely stopped by user")
        _userMessage.value = "Stage 11: Automation stopped and touch actions cleared."
    }

    fun triggerEmergencyStop() {
        safetyCoordinator.triggerEmergencyStop()
        _userMessage.value = "EMERGENCY STOP TRIGGERED: All actions halted."
    }

    fun resetEmergencyStop() {
        safetyCoordinator.resetEmergencyStop()
        _userMessage.value = "Emergency Stop cleared. Ready for safe operation."
    }

    fun runHealthDiagnostics(context: Context) {
        val result = safetyCoordinator.performDiagnosticHealthCheck(context)
        _userMessage.value = result
    }

    fun dismissUserMessage() {
        _userMessage.value = null
    }
}
