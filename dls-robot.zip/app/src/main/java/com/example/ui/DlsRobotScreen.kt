package com.example.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsFootball
import androidx.compose.material.icons.filled.SportsScore
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Swipe
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.analysis.ImageAnalysisManager
import com.example.bot.BotController
import com.example.capture.ScreenCaptureManager
import com.example.connectivity.ConnectivityModeManager
import com.example.decision.DlsDecisionEngine
import com.example.execution.ActionExecutor
import com.example.gamestate.DlsGameStateAnalyzer
import com.example.lifecycle.MatchLifecycleManager
import com.example.orchestrator.AutonomousGameplayOrchestrator
import com.example.safety.SystemHealthSafetyCoordinator
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusErrorRed
import com.example.ui.theme.StatusInactiveGray
import com.example.ui.theme.StatusWarningAmber
import com.example.vision.DlsVisionAnalyzer
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DlsRobotScreen(
    uiState: MainUiState,
    onLaunchDls: () -> Unit,
    onStartScreenCapture: () -> Unit,
    onStopScreenCapture: () -> Unit,
    onStartBot: () -> Unit,
    onStopBot: () -> Unit,
    onPauseBot: () -> Unit = {},
    onResumeBot: () -> Unit = {},
    onToggleAutoPause: () -> Unit = {},
    onStartAutomation: () -> Unit = {},
    onStopAutomation: () -> Unit = {},
    onPauseAutomation: () -> Unit = {},
    onResumeAutomation: () -> Unit = {},
    onSetAutomationMinConfidence: (Float) -> Unit = {},
    onSetAutomationCooldown: (Long) -> Unit = {},
    onToggleAutomationAutoPause: () -> Unit = {},
    onSetAnalysisInterval: (Long) -> Unit = {},
    onToggleDebugOverlay: () -> Unit = {},
    onUpdateBallBrightness: (Float) -> Unit = {},
    onUpdateGrassHue: (Float, Float) -> Unit = { _, _ -> },
    onSetDecisionCooldown: (Long) -> Unit = {},
    onSetDecisionMinConfidence: (Float) -> Unit = {},
    onToggleDecisionDebugOverlay: () -> Unit = {},
    onOpenAccessibilitySettings: () -> Unit = {},
    onEmergencyStop: () -> Unit = {},
    onToggleExecutionEnabled: () -> Unit = {},
    onSetExecutionCooldown: (Long) -> Unit = {},
    onSetExecutionMinConfidence: (Float) -> Unit = {},
    onRefreshConnectivity: () -> Unit = {},
    onResetLifecycle: () -> Unit = {},
    onAdvanceLifecycleState: (MatchLifecycleManager.LifecycleState) -> Unit = {},
    onStartSafeAutomation: () -> Unit = {},
    onStopSafeAutomation: () -> Unit = {},
    onClearEmergencyHalt: () -> Unit = {},
    onRunHealthDiagnostics: () -> Unit = {},
    onTestTap: (Float, Float) -> Unit = { _, _ -> },
    onTestSwipe: (Float, Float, Float, Float) -> Unit = { _, _, _, _ -> },
    onTestMove: (Float, Float, Float, Float) -> Unit = { _, _, _, _ -> },
    onDismissMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.userMessage) {
        uiState.userMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            onDismissMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = stringResource(R.string.title_dls_robot),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.testTag("snackbar_host")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Stage 7 Header Banner
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(26.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Stage 7: Real-Time Game Control Loop",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Continuous Loop: Screen Capture → Vision Analysis → Game State → Decision Engine → Action Execution",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Stage 8 Header Banner
            Surface(
                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(26.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Stage 8: Connectivity & Game Mode Manager",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        Text(
                            text = "Real Internet Reachability → CAREER MODE | Offline / No Uplink → EXHIBITION MODE",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Stage 9 Header Banner
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(26.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Stage 9: Autonomous Gameplay Orchestrator",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Continuous Closed-Loop: Vision Analysis → Game State Understanding → Decision Engine → Action Execution → Vision Analysis",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Stage 11 Header Banner (Central Integration, Safety & Stability)
            Surface(
                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.90f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(28.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Stage 11: Final Integration, Safety & Stability",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        Text(
                            text = "Unified Pipeline: Capture → Vision → Game State → Decision → Execution → Lifecycle → Mode",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.90f)
                        )
                    }
                }
            }

            val isCapturingActive = uiState.captureState is ScreenCaptureManager.CaptureState.Capturing

            // Stage 11: Central Pipeline & Safety Dashboard Card
            Text(
                text = "CENTRAL PIPELINE & SAFETY DASHBOARD (STAGE 11)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            CentralPipelineSafetyCard(
                healthTelemetry = uiState.healthTelemetry,
                isCapturing = isCapturingActive,
                isAccessibilityConnected = uiState.isAccessibilityConnected,
                onStartSafeAutomation = onStartSafeAutomation,
                onStopSafeAutomation = onStopSafeAutomation,
                onEmergencyStop = onEmergencyStop,
                onClearEmergencyHalt = onClearEmergencyHalt,
                onRunHealthDiagnostics = onRunHealthDiagnostics
            )

            // Stage 10 Header Banner
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.85f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Autorenew,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(26.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Stage 10: Match Lifecycle Manager",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "Full State Machine: WAITING → STARTING → PLAYING → PAUSED → FINISHED → RESULT → MENU → READY",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Stage 10: Match Lifecycle Manager Card
            Text(
                text = "MATCH LIFECYCLE MANAGER (STAGE 10)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            MatchLifecycleCard(
                lifecycleTelemetry = uiState.lifecycleTelemetry,
                onResetLifecycle = onResetLifecycle,
                onAdvanceLifecycleState = onAdvanceLifecycleState
            )

            // Stage 9: Autonomous Gameplay Orchestrator Card
            Text(
                text = "AUTONOMOUS GAMEPLAY ORCHESTRATOR (STAGE 9)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            AutonomousGameplayOrchestratorCard(
                orchestratorState = uiState.orchestratorState,
                config = uiState.orchestratorConfig,
                isCapturing = isCapturingActive,
                isAccessibilityConnected = uiState.isAccessibilityConnected,
                onStartAutomation = onStartAutomation,
                onStopAutomation = onStopAutomation,
                onPauseAutomation = onPauseAutomation,
                onResumeAutomation = onResumeAutomation,
                onSetMinConfidence = onSetAutomationMinConfidence,
                onSetCooldown = onSetAutomationCooldown,
                onToggleAutoPause = onToggleAutomationAutoPause,
                onOpenAccessibilitySettings = onOpenAccessibilitySettings
            )

            // Stage 8: Connectivity & Game Mode Card
            Text(
                text = "CONNECTIVITY & GAME MODE (STAGE 8)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            ConnectivityModeCard(
                connectivityState = uiState.connectivityState,
                onRefreshConnectivity = onRefreshConnectivity
            )

            // Emergency Stop Card
            EmergencyStopCard(onEmergencyStop = onEmergencyStop)

            // 1. Stage 7: Real-Time Game Control Loop Card
            Text(
                text = "REAL-TIME GAME CONTROL LOOP (STAGE 7)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            ControlLoopCard(
                loopState = uiState.controlLoopState,
                config = uiState.controlLoopConfig,
                isCapturing = isCapturingActive,
                isAccessibilityConnected = uiState.isAccessibilityConnected,
                onStartBot = onStartBot,
                onStopBot = onStopBot,
                onPauseBot = onPauseBot,
                onResumeBot = onResumeBot,
                onSetInterval = onSetAnalysisInterval,
                onToggleAutoPause = onToggleAutoPause,
                onOpenAccessibilitySettings = onOpenAccessibilitySettings
            )

            // 2. Action Execution (Stage 6) Card
            Text(
                text = "ACTION EXECUTION (STAGE 6)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            ActionExecutionCard(
                executionState = uiState.executionState,
                isAccessibilityConnected = uiState.isAccessibilityConnected,
                onOpenAccessibilitySettings = onOpenAccessibilitySettings
            )

            // 2. Action Execution Controls & Tests Card
            Text(
                text = "EXECUTION CONTROLS & MANUAL GESTURES",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            ActionExecutionControlsCard(
                config = uiState.executorConfig,
                onToggleExecutionEnabled = onToggleExecutionEnabled,
                onSetCooldown = onSetExecutionCooldown,
                onSetMinConfidence = onSetExecutionMinConfidence,
                onTestTap = { onTestTap(640f, 360f) },
                onTestSwipe = { onTestSwipe(400f, 600f, 800f, 600f) },
                onTestMove = { onTestMove(250f, 600f, 400f, 500f) }
            )

            // 3. Live Frame Preview & CV / Decision Overlay Card
            Text(
                text = "LIVE VISION & ACTION PREVIEW",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            LiveFrameWithOverlayCard(
                analysisState = uiState.analysisState,
                visionResult = uiState.visionResult,
                visionConfig = uiState.visionConfig,
                gameState = uiState.gameState,
                decision = uiState.decision,
                decisionConfig = uiState.decisionConfig,
                executionState = uiState.executionState
            )

            // 4. Stage 5 Decision Engine Output Card
            Text(
                text = "DECISION ENGINE (STAGE 5)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            DecisionEngineCard(decision = uiState.decision)

            // 5. Stage 5 Decision Configuration & Thresholds Card
            Text(
                text = "DECISION THRESHOLDS & COOLDOWNS",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            DecisionControlsCard(
                config = uiState.decisionConfig,
                onSetCooldown = onSetDecisionCooldown,
                onSetMinConfidence = onSetDecisionMinConfidence,
                onToggleOverlay = onToggleDecisionDebugOverlay
            )

            // 6. Stage 4 Game State Metrics Card
            Text(
                text = "GAME STATE UNDERSTANDING (STAGE 4)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            GameStateCard(gameState = uiState.gameState)

            // 7. Stage 3 Raw Vision Analysis Metrics Card
            Text(
                text = "RAW VISION METRICS (STAGE 3)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            VisionAnalysisCard(
                visionResult = uiState.visionResult,
                analysisState = uiState.analysisState
            )

            // 8. Vision Threshold & Debug Mode Settings Card
            Text(
                text = "VISION & DEBUG CONFIGURATION",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            VisionDebugControlsCard(
                config = uiState.visionConfig,
                onToggleDebugOverlay = onToggleDebugOverlay,
                onUpdateBallBrightness = onUpdateBallBrightness,
                onUpdateGrassHue = onUpdateGrassHue
            )

            // 9. System Status Section
            Text(
                text = "SYSTEM STATUS",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            StatusSummaryCard(uiState = uiState)

            // 10. Analysis Interval Configuration
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = stringResource(R.string.label_analysis_interval),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Set how frequently screen frames are extracted and processed for local CV:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(50L to "50ms (20fps)", 100L to "100ms (10fps)", 200L to "200ms (5fps)", 500L to "500ms (2fps)").forEach { (interval, label) ->
                            val isSelected = uiState.analysisState.intervalMs == interval
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSetAnalysisInterval(interval) },
                                label = { Text(text = label, style = MaterialTheme.typography.bodySmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                modifier = Modifier.testTag("interval_chip_${interval}ms")
                            )
                        }
                    }
                }
            }

            // 11. Actions & Controls Section
            Text(
                text = "CONTROLS",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            // Launch DLS Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Game Launcher",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Target Package: com.firsttouchgames.dls7",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = onLaunchDls,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("launch_dls_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.btn_launch_dls),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Screen Capture Controls Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Screen Capture (MediaProjection)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    val isCapturing = uiState.captureState is ScreenCaptureManager.CaptureState.Capturing

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onStartScreenCapture,
                            enabled = !isCapturing,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("start_screen_capture_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.btn_start_screen_capture),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        OutlinedButton(
                            onClick = onStopScreenCapture,
                            enabled = isCapturing,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("stop_screen_capture_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.btn_stop_screen_capture),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Bot Controller Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Autonomous Bot Controller (Stage 6 Active)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    val isBotRunning = uiState.botState is BotController.BotState.Running

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onStartBot,
                            enabled = !isBotRunning,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("start_bot_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.tertiary
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.btn_start_bot),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        OutlinedButton(
                            onClick = onStopBot,
                            enabled = isBotRunning,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("stop_bot_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PauseCircle,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.btn_stop_bot),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/**
 * Emergency STOP Button Card (Prominent Immediate Action Cancellation).
 */
@Composable
private fun EmergencyStopCard(onEmergencyStop: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = StatusErrorRed.copy(alpha = 0.15f)
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, StatusErrorRed.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = null,
                        tint = StatusErrorRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Safety Override",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = StatusErrorRed
                    )
                }
                Text(
                    text = "Instantly aborts all active touches and suspends bot execution",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onEmergencyStop,
                colors = ButtonDefaults.buttonColors(containerColor = StatusErrorRed),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("emergency_stop_button")
            ) {
                Icon(
                    imageVector = Icons.Default.StopCircle,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.btn_emergency_stop),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * Stage 7: Real-Time Game Control Loop Card.
 */
@Composable
private fun ControlLoopCard(
    loopState: BotController.ControlLoopState,
    config: BotController.ControlLoopConfig,
    isCapturing: Boolean,
    isAccessibilityConnected: Boolean,
    onStartBot: () -> Unit,
    onStopBot: () -> Unit,
    onPauseBot: () -> Unit,
    onResumeBot: () -> Unit,
    onSetInterval: (Long) -> Unit,
    onToggleAutoPause: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit
) {
    val (statusColor, statusIcon, statusLabel) = when (loopState.status) {
        BotController.LoopStatus.RUNNING -> Triple(StatusActiveGreen, Icons.Default.PlayCircle, "RUNNING")
        BotController.LoopStatus.PAUSED -> Triple(StatusWarningAmber, Icons.Default.PauseCircle, "PAUSED")
        BotController.LoopStatus.STOPPED -> Triple(StatusInactiveGray, Icons.Default.StopCircle, "STOPPED")
        BotController.LoopStatus.ERROR -> Triple(StatusErrorRed, Icons.Default.Cancel, "ERROR")
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("control_loop_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_control_loop),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = statusColor.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = statusIcon,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }
                }
            }

            // Status message
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = loopState.statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (loopState.status == BotController.LoopStatus.ERROR) StatusErrorRed else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Pipeline Readiness Indicators
            Text(
                text = "PIPELINE PREREQUISITES",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Screen Capture Readiness
                Surface(
                    color = if (isCapturing) StatusActiveGreen.copy(alpha = 0.12f) else StatusWarningAmber.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (isCapturing) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (isCapturing) StatusActiveGreen else StatusWarningAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isCapturing) "Capture Ready" else "Capture Missing",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isCapturing) StatusActiveGreen else StatusWarningAmber
                        )
                    }
                }

                // Accessibility Service Readiness
                Surface(
                    color = if (isAccessibilityConnected) StatusActiveGreen.copy(alpha = 0.12f) else StatusWarningAmber.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (isAccessibilityConnected) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (isAccessibilityConnected) StatusActiveGreen else StatusWarningAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isAccessibilityConnected) "Accessibility Ready" else "Accessibility Off",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isAccessibilityConnected) StatusActiveGreen else StatusWarningAmber
                        )
                    }
                }
            }

            if (!isAccessibilityConnected) {
                OutlinedButton(
                    onClick = onOpenAccessibilitySettings,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccessibilityNew,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.btn_enable_accessibility),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Primary Control Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (loopState.status) {
                    BotController.LoopStatus.RUNNING -> {
                        Button(
                            onClick = onPauseBot,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("pause_bot_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusWarningAmber
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PauseCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.btn_pause_bot), fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onStopBot,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("stop_bot_button_card"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.StopCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.btn_stop_bot), fontWeight = FontWeight.Bold)
                        }
                    }
                    BotController.LoopStatus.PAUSED -> {
                        Button(
                            onClick = onResumeBot,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("resume_bot_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusActiveGreen
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.btn_resume_bot), fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onStopBot,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("stop_bot_button_card"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.StopCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.btn_stop_bot), fontWeight = FontWeight.Bold)
                        }
                    }
                    BotController.LoopStatus.STOPPED, BotController.LoopStatus.ERROR -> {
                        Button(
                            onClick = onStartBot,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("start_bot_primary_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.btn_start_bot), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Real-Time Control Loop Telemetry
            Text(
                text = "REAL-TIME LOOP METRICS",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            // Frames Processed
            StatusItemRow(
                title = stringResource(R.string.label_frames_processed),
                value = "${loopState.framesProcessed} frames",
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Sensors,
                testTag = "loop_frames_processed_value"
            )

            // Decisions Generated
            StatusItemRow(
                title = stringResource(R.string.label_decisions_generated),
                value = "${loopState.decisionsGenerated} (${loopState.lastActionType.label})",
                indicatorColor = Color(loopState.lastActionType.colorHex),
                icon = Icons.Default.FlashOn,
                testTag = "loop_decisions_generated_value"
            )

            // Actions Dispatched
            StatusItemRow(
                title = stringResource(R.string.label_actions_executed),
                value = "${loopState.actionsExecuted} executed (failed: ${loopState.failedActions})",
                indicatorColor = if (loopState.actionsExecuted > 0) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.TouchApp,
                testTag = "loop_actions_executed_value"
            )

            // Average Latency
            StatusItemRow(
                title = stringResource(R.string.label_avg_loop_latency),
                value = "${loopState.avgLoopLatencyMs.toInt()} ms (last: ${loopState.lastCycleDurationMs}ms)",
                indicatorColor = if (loopState.avgLoopLatencyMs < 50) StatusActiveGreen else StatusWarningAmber,
                icon = Icons.Default.Speed,
                testTag = "loop_avg_latency_value"
            )

            // Match Phase
            val phaseColor = when (loopState.currentPhase) {
                DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY -> StatusActiveGreen
                DlsGameStateAnalyzer.MatchPhase.MATCH_STOPPED_OR_REPLAY -> StatusWarningAmber
                DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI -> MaterialTheme.colorScheme.primary
                DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION -> MaterialTheme.colorScheme.tertiary
                DlsGameStateAnalyzer.MatchPhase.UNKNOWN -> StatusInactiveGray
            }
            StatusItemRow(
                title = stringResource(R.string.label_current_phase),
                value = loopState.currentPhase.label,
                indicatorColor = phaseColor,
                icon = Icons.Default.SportsFootball,
                testTag = "loop_current_phase_value"
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Control Loop Interval Selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.label_control_loop_interval),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(50L to "50ms", 100L to "100ms", 200L to "200ms", 500L to "500ms").forEach { (interval, label) ->
                        val isSelected = config.loopIntervalMs == interval
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetInterval(interval) },
                            label = { Text(text = label, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("loop_interval_${interval}ms")
                        )
                    }
                }
            }

            // Auto-pause toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Auto-pause in Menus/Cutscenes",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Suspends actions when game is loading or in menus",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = config.autoPauseOnMenu,
                    onCheckedChange = { onToggleAutoPause() },
                    modifier = Modifier.testTag("auto_pause_menu_switch")
                )
            }
        }
    }
}

/**
 * Stage 6: Action Execution Real-time Metrics Card.
 */
@Composable
private fun ActionExecutionCard(
    executionState: ActionExecutor.ExecutionState,
    isAccessibilityConnected: Boolean,
    onOpenAccessibilitySettings: () -> Unit
) {
    val actionColor = Color(executionState.lastCommand.type.colorHex)

    val actionIcon = when (executionState.lastCommand.type) {
        ActionExecutor.ExecutionType.WAIT -> Icons.Default.HourglassEmpty
        ActionExecutor.ExecutionType.TAP -> Icons.Default.TouchApp
        ActionExecutor.ExecutionType.HOLD -> Icons.Default.PanTool
        ActionExecutor.ExecutionType.RELEASE -> Icons.Default.Cancel
        ActionExecutor.ExecutionType.SWIPE -> Icons.Default.Swipe
        ActionExecutor.ExecutionType.MOVE -> Icons.Default.NearMe
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("action_execution_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_action_execution),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = actionColor.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = actionIcon,
                            contentDescription = null,
                            tint = actionColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = executionState.lastCommand.type.label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = actionColor
                        )
                    }
                }
            }

            // Accessibility Service Status Warning / Prompt if disabled
            if (!isAccessibilityConnected) {
                Surface(
                    color = StatusWarningAmber.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = StatusWarningAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Accessibility Service is not enabled",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusWarningAmber
                            )
                        }
                        Text(
                            text = "To dispatch real touch and swipe gestures to DLS, enable 'DLS Robot Action Service' in Android Accessibility settings.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = onOpenAccessibilitySettings,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("open_accessibility_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.btn_open_accessibility),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 1. Accessibility Service Status
            val accColor = if (isAccessibilityConnected) StatusActiveGreen else StatusWarningAmber
            val accText = if (isAccessibilityConnected) "Connected & Authorized" else "Disabled in Settings"
            StatusItemRow(
                title = stringResource(R.string.label_accessibility_status),
                value = accText,
                indicatorColor = accColor,
                icon = Icons.Default.AccessibilityNew,
                testTag = "accessibility_status_value"
            )

            // 2. Current Executed Action
            StatusItemRow(
                title = stringResource(R.string.label_current_execution_action),
                value = "${executionState.lastCommand.type.label} (${executionState.lastCommand.sourceDecision.label})",
                indicatorColor = actionColor,
                icon = actionIcon,
                testTag = "current_executed_action_value"
            )

            // 3. Touch Coordinates Position Row
            val touchCoordText = if (executionState.lastCommand.startX != null && executionState.lastCommand.startY != null) {
                if (executionState.lastCommand.endX != null && executionState.lastCommand.endY != null) {
                    "(${executionState.lastCommand.startX.toInt()}, ${executionState.lastCommand.startY.toInt()}) → (${executionState.lastCommand.endX.toInt()}, ${executionState.lastCommand.endY.toInt()})"
                } else {
                    "X: ${executionState.lastCommand.startX.toInt()} px | Y: ${executionState.lastCommand.startY.toInt()} px"
                }
            } else {
                "None (WAIT state)"
            }
            StatusItemRow(
                title = stringResource(R.string.label_touch_coordinates),
                value = touchCoordText,
                indicatorColor = if (executionState.lastCommand.startX != null) MaterialTheme.colorScheme.primary else StatusInactiveGray,
                icon = Icons.Default.GpsFixed,
                testTag = "touch_coordinates_value"
            )

            // 4. Action Duration
            StatusItemRow(
                title = stringResource(R.string.label_action_duration),
                value = "${executionState.lastCommand.durationMs} ms",
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Timer,
                testTag = "execution_duration_value"
            )

            // 5. Execution Success / Failure Status
            val (successColor, successText) = if (executionState.lastSuccess) {
                StatusActiveGreen to "Success (Latency: ${executionState.latencyMs}ms)"
            } else {
                StatusErrorRed to "Failed / Rejected"
            }
            StatusItemRow(
                title = "Execution Status",
                value = successText,
                indicatorColor = successColor,
                icon = if (executionState.lastSuccess) Icons.Default.CheckCircle else Icons.Default.Cancel,
                testTag = "execution_success_value"
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 6. Action Message & Reason Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Status: ${executionState.statusMessage}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.testTag("execution_status_message_value")
                )
                Text(
                    text = "Reason: ${executionState.lastCommand.reason}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("execution_reason_value")
                )
            }

            // 7. Stats & Execution Counts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Total Dispatched: ${executionState.totalExecutedCount}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Failed: ${executionState.failedCount}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = if (executionState.failedCount > 0) StatusErrorRed else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Stage 6: Execution Controls & Manual Gesture Triggers Card.
 */
@Composable
private fun ActionExecutionControlsCard(
    config: ActionExecutor.ExecutorConfig,
    onToggleExecutionEnabled: () -> Unit,
    onSetCooldown: (Long) -> Unit,
    onSetMinConfidence: (Float) -> Unit,
    onTestTap: () -> Unit,
    onTestSwipe: () -> Unit,
    onTestMove: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.label_execution_controls),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Enable Execution Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Enable Real Touch Dispatching",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "When enabled, bot dispatches touch gestures to DLS. When disabled, operates in Observation-Only mode.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = config.isExecutionEnabled,
                    onCheckedChange = { onToggleExecutionEnabled() },
                    modifier = Modifier.testTag("toggle_execution_enabled_switch")
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            // Action Cooldown Selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Action Dispatch Cooldown:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(100L to "100ms", 180L to "180ms", 300L to "300ms", 500L to "500ms").forEach { (cd, label) ->
                        val isSelected = config.cooldownMs == cd
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetCooldown(cd) },
                            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("execution_cooldown_chip_${cd}ms")
                        )
                    }
                }
            }

            // Min Confidence Selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Min Execution Confidence Threshold:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0.30f to "30%", 0.40f to "40%", 0.50f to "50%", 0.60f to "60%").forEach { (th, label) ->
                        val isSelected = (config.minConfidenceThreshold - th).let { kotlin.math.abs(it) < 0.05f }
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetMinConfidence(th) },
                            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("execution_confidence_chip_${(th * 100).toInt()}")
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            // Manual Gesture Dispatch Testing Row
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Manual Gesture Verification (Tests Accessibility Service):",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onTestTap,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_tap_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Test Tap", style = MaterialTheme.typography.bodySmall)
                    }

                    OutlinedButton(
                        onClick = onTestSwipe,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_swipe_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Test Swipe", style = MaterialTheme.typography.bodySmall)
                    }

                    OutlinedButton(
                        onClick = onTestMove,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_move_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Test Move", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

/**
 * Live Captured Frame Preview with Dynamic Computer-Vision, Trajectory, Stage 5 Action & Stage 6 Touch Overlay.
 */
@Composable
private fun LiveFrameWithOverlayCard(
    analysisState: ImageAnalysisManager.AnalysisState,
    visionResult: DlsVisionAnalyzer.DetectionResult,
    visionConfig: DlsVisionAnalyzer.VisionConfig,
    gameState: DlsGameStateAnalyzer.GameState,
    decision: DlsDecisionEngine.Decision,
    decisionConfig: DlsDecisionEngine.DecisionConfig,
    executionState: ActionExecutor.ExecutionState = ActionExecutor.ExecutionState()
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("frame_preview_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_live_preview),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = if (analysisState.isAnalyzing) StatusActiveGreen.copy(alpha = 0.15f) else StatusInactiveGray.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (analysisState.isAnalyzing) "LIVE 10fps" else "IDLE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (analysisState.isAnalyzing) StatusActiveGreen else StatusInactiveGray,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            val latestBitmap = analysisState.latestBitmap

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E232A)),
                contentAlignment = Alignment.Center
            ) {
                if (latestBitmap != null) {
                    Image(
                        bitmap = latestBitmap.asImageBitmap(),
                        contentDescription = "Live Captured Screen Frame",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay Canvas
                    if (visionConfig.isDebugOverlayEnabled && latestBitmap.width > 0 && latestBitmap.height > 0) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val canvasW = size.width
                            val canvasH = size.height
                            val bmpW = latestBitmap.width.toFloat()
                            val bmpH = latestBitmap.height.toFloat()

                            val scale = min(canvasW / bmpW, canvasH / bmpH)
                            val renderedW = bmpW * scale
                            val renderedH = bmpH * scale
                            val offsetX = (canvasW - renderedW) / 2f
                            val offsetY = (canvasH - renderedH) / 2f

                            fun mapX(x: Float) = offsetX + (x * scale)
                            fun mapY(y: Float) = offsetY + (y * scale)

                            // 1. Draw Field Pitch Region
                            if (visionResult.isFieldDetected) {
                                val region = visionResult.fieldRegion
                                if (region != null) {
                                    val rLeft = mapX(region.left)
                                    val rTop = mapY(region.top)
                                    val rRight = mapX(region.right)
                                    val rBottom = mapY(region.bottom)

                                    drawRoundRect(
                                        color = Color(0x404CAF50),
                                        topLeft = Offset(rLeft, rTop),
                                        size = Size(rRight - rLeft, rBottom - rTop),
                                        cornerRadius = CornerRadius(8f, 8f),
                                        style = Stroke(
                                            width = 2f,
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
                                        )
                                    )
                                }
                            }

                            // 2. Draw Tracked Players
                            val playersToDraw = if (gameState.players.isNotEmpty()) gameState.players else visionResult.players.map {
                                DlsGameStateAnalyzer.TrackedPlayer(
                                    id = it.id,
                                    x = it.x,
                                    y = it.y,
                                    normX = it.normX,
                                    normY = it.normY,
                                    width = it.width,
                                    height = it.height,
                                    teamId = it.teamId,
                                    confidence = it.confidence
                                )
                            }

                            val closestPlayerId = gameState.closestPlayer?.player?.id

                            playersToDraw.forEach { player ->
                                val px = mapX(player.x)
                                val py = mapY(player.y)
                                val pw = player.width * scale
                                val ph = player.height * scale

                                val isClosest = player.id == closestPlayerId

                                val playerColor = when {
                                    isClosest -> Color(0xFFFF9100)
                                    player.teamId == 1 -> Color(0xFF00E5FF)
                                    player.teamId == 2 -> Color(0xFFFF1744)
                                    else -> Color(0xFFFFD600)
                                }

                                val boxLeft = px - pw / 2f
                                val boxTop = py - ph

                                drawRoundRect(
                                    color = playerColor,
                                    topLeft = Offset(boxLeft, boxTop),
                                    size = Size(pw, ph),
                                    cornerRadius = CornerRadius(4f, 4f),
                                    style = Stroke(width = if (isClosest) 3f else 2f)
                                )

                                drawCircle(
                                    color = playerColor,
                                    radius = if (isClosest) 5f else 3f,
                                    center = Offset(px, py)
                                )
                            }

                            // 3. Draw Closest Player Connection Line to Ball
                            val activeBall = gameState.ball
                            if (activeBall != null && gameState.closestPlayer != null) {
                                val cp = gameState.closestPlayer.player
                                val cpx = mapX(cp.x)
                                val cpy = mapY(cp.y)
                                val bx = mapX(activeBall.x)
                                val by = mapY(activeBall.y)

                                val lineColor = if (gameState.closestPlayer.hasPossession) Color(0xFF00E676) else Color(0xFFFFAB00)

                                drawLine(
                                    color = lineColor,
                                    start = Offset(cpx, cpy),
                                    end = Offset(bx, by),
                                    strokeWidth = 2f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
                                )
                            }

                            // 4. Draw Ball with Velocity Trajectory Vector
                            if (activeBall != null) {
                                val bx = mapX(activeBall.x)
                                val by = mapY(activeBall.y)

                                if (activeBall.speedPxPerSec > 25f) {
                                    val predX = mapX(activeBall.predictedX)
                                    val predY = mapY(activeBall.predictedY)

                                    drawLine(
                                        color = Color(0xFF00E5FF),
                                        start = Offset(bx, by),
                                        end = Offset(predX, predY),
                                        strokeWidth = 3f
                                    )

                                    drawCircle(
                                        color = Color(0xFF00E5FF),
                                        radius = 6f,
                                        center = Offset(predX, predY),
                                        style = Stroke(width = 2f)
                                    )
                                }

                                drawCircle(
                                    color = Color(0x66FFD600),
                                    radius = 16f * scale + 6f,
                                    center = Offset(bx, by)
                                )

                                drawCircle(
                                    color = Color(0xFFFFD600),
                                    radius = max(8f, 10f * scale),
                                    center = Offset(bx, by),
                                    style = Stroke(width = 3f)
                                )

                                drawCircle(
                                    color = Color.White,
                                    radius = 3f,
                                    center = Offset(bx, by)
                                )
                            }

                            // 5. Stage 5 Decision Target Reticle & Action Vector Overlay
                            if (decisionConfig.isDebugOverlayEnabled && decision.targetX != null && decision.targetY != null) {
                                val tx = mapX(decision.targetX)
                                val ty = mapY(decision.targetY)
                                val actionColor = Color(decision.actionType.badgeColorHex)

                                val startX = if (gameState.closestPlayer != null) mapX(gameState.closestPlayer.player.x) else (activeBall?.let { mapX(it.x) } ?: (canvasW / 2f))
                                val startY = if (gameState.closestPlayer != null) mapY(gameState.closestPlayer.player.y) else (activeBall?.let { mapY(it.y) } ?: (canvasH / 2f))

                                drawLine(
                                    color = actionColor,
                                    start = Offset(startX, startY),
                                    end = Offset(tx, ty),
                                    strokeWidth = 3.5f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f))
                                )

                                drawCircle(
                                    color = actionColor,
                                    radius = 18f,
                                    center = Offset(tx, ty),
                                    style = Stroke(width = 2.5f)
                                )

                                drawCircle(
                                    color = actionColor.copy(alpha = 0.4f),
                                    radius = 8f,
                                    center = Offset(tx, ty)
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 3f,
                                    center = Offset(tx, ty)
                                )

                                val spikeLen = 8f
                                drawLine(actionColor, Offset(tx - 24f, ty), Offset(tx - 24f + spikeLen, ty), 2.5f)
                                drawLine(actionColor, Offset(tx + 24f, ty), Offset(tx + 24f - spikeLen, ty), 2.5f)
                                drawLine(actionColor, Offset(tx, ty - 24f), Offset(tx, ty - 24f + spikeLen), 2.5f)
                                drawLine(actionColor, Offset(tx, ty + 24f), Offset(tx, ty + 24f - spikeLen), 2.5f)
                            }

                            // 6. Stage 6 Touch Execution Vector / Ripple Overlay
                            val execCmd = executionState.lastCommand
                            if (execCmd.startX != null && execCmd.startY != null) {
                                val exStartX = mapX(execCmd.startX)
                                val exStartY = mapY(execCmd.startY)
                                val touchColor = Color(execCmd.type.colorHex)

                                if (execCmd.endX != null && execCmd.endY != null) {
                                    val exEndX = mapX(execCmd.endX)
                                    val exEndY = mapY(execCmd.endY)

                                    drawLine(
                                        color = touchColor,
                                        start = Offset(exStartX, exStartY),
                                        end = Offset(exEndX, exEndY),
                                        strokeWidth = 4f
                                    )
                                    drawCircle(
                                        color = touchColor,
                                        radius = 10f,
                                        center = Offset(exEndX, exEndY),
                                        style = Stroke(width = 2.5f)
                                    )
                                }

                                drawCircle(
                                    color = touchColor.copy(alpha = 0.35f),
                                    radius = 14f,
                                    center = Offset(exStartX, exStartY)
                                )
                                drawCircle(
                                    color = touchColor,
                                    radius = 5f,
                                    center = Offset(exStartX, exStartY)
                                )
                            }
                        }
                    }

                    // Top-Left Action Badge overlay on Live Preview
                    val actionBadgeColor = Color(decision.actionType.badgeColorHex)
                    Surface(
                        color = Color.Black.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(actionBadgeColor)
                            )
                            Text(
                                text = "ACTION: ${decision.actionType.label} (${(decision.confidence * 100).toInt()}%)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = actionBadgeColor
                            )
                        }
                    }

                    // Bottom info bar overlay
                    Surface(
                        color = Color.Black.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "${latestBitmap.width}×${latestBitmap.height} | Latency: ${decision.decisionLatencyMs + gameState.totalLatencyMs}ms",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterCenterFocus,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = stringResource(R.string.preview_placeholder_text),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

/**
 * Stage 5: Decision Engine Status & Metrics Card.
 */
@Composable
private fun DecisionEngineCard(decision: DlsDecisionEngine.Decision) {
    val actionColor = Color(decision.actionType.badgeColorHex)

    val actionIcon = when (decision.actionType) {
        DlsDecisionEngine.ActionType.WAIT -> Icons.Default.HourglassEmpty
        DlsDecisionEngine.ActionType.CHASE_BALL -> Icons.Default.FlashOn
        DlsDecisionEngine.ActionType.MOVE -> Icons.Default.NearMe
        DlsDecisionEngine.ActionType.PASS -> Icons.Default.SportsFootball
        DlsDecisionEngine.ActionType.SHOOT -> Icons.Default.TrackChanges
        DlsDecisionEngine.ActionType.DEFEND -> Icons.Default.Shield
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("decision_engine_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_decision_engine),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = actionColor.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = actionIcon,
                            contentDescription = null,
                            tint = actionColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = decision.actionType.label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = actionColor
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 1. Current Action Row
            StatusItemRow(
                title = stringResource(R.string.label_current_action),
                value = "${decision.actionType.label} (${(decision.confidence * 100).toInt()}% confidence)",
                indicatorColor = actionColor,
                icon = actionIcon,
                testTag = "current_action_value"
            )

            // 2. Target Position Row
            val targetText = if (decision.targetX != null && decision.targetY != null) {
                val normX = decision.targetNormX?.let { " (${(it * 100).toInt()}% X" } ?: ""
                val normY = decision.targetNormY?.let { ", ${(it * 100).toInt()}% Y)" } ?: ""
                "X: ${decision.targetX.toInt()} px | Y: ${decision.targetY.toInt()} px$normX$normY"
            } else {
                "None (Holding / Waiting)"
            }
            StatusItemRow(
                title = stringResource(R.string.label_target_position),
                value = targetText,
                indicatorColor = if (decision.targetX != null) MaterialTheme.colorScheme.primary else StatusInactiveGray,
                icon = Icons.Default.GpsFixed,
                testTag = "decision_target_value"
            )

            // 3. Direction Row
            StatusItemRow(
                title = stringResource(R.string.label_action_direction),
                value = decision.direction + (decision.directionAngleDeg?.let { " (${it.toInt()}°)" } ?: ""),
                indicatorColor = if (decision.direction != "None") MaterialTheme.colorScheme.primary else StatusInactiveGray,
                icon = Icons.Default.Explore,
                testTag = "decision_direction_value"
            )

            // 4. Action Duration Row
            StatusItemRow(
                title = stringResource(R.string.label_action_duration),
                value = "${decision.durationMs} ms",
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Timer,
                testTag = "decision_duration_value"
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 5. Decision Reason Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = stringResource(R.string.label_decision_reason),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = decision.reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.testTag("decision_reason_value")
                )
            }

            // 6. Decision Latency & Timestamp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Latency: ${decision.decisionLatencyMs} ms",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Time: ${if (decision.timestampMs > 0) "${System.currentTimeMillis() - decision.timestampMs}ms ago" else "N/A"}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Stage 5: Decision Thresholds & Cooldown Configuration Card.
 */
@Composable
private fun DecisionControlsCard(
    config: DlsDecisionEngine.DecisionConfig,
    onSetCooldown: (Long) -> Unit,
    onSetMinConfidence: (Float) -> Unit,
    onToggleOverlay: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.label_decision_controls),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Action Cooldown Selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Action Hysteresis Cooldown (prevents frame jitter):",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(150L to "150ms", 300L to "300ms", 500L to "500ms", 1000L to "1s").forEach { (cd, label) ->
                        val isSelected = config.actionCooldownMs == cd
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetCooldown(cd) },
                            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("cooldown_chip_${cd}ms")
                        )
                    }
                }
            }

            // Min Confidence Selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Min GameState Confidence to Act (else WAIT):",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0.30f to "30%", 0.40f to "40%", 0.50f to "50%", 0.60f to "60%").forEach { (th, label) ->
                        val isSelected = (config.minConfidenceThreshold - th).let { kotlin.math.abs(it) < 0.05f }
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetMinConfidence(th) },
                            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("confidence_chip_${(th * 100).toInt()}")
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            // Toggle Decision Debug Overlay
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Show Action Target Reticle on Overlay",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Renders target crosshairs and action vector lines on the live screen frame",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = config.isDebugOverlayEnabled,
                    onCheckedChange = { onToggleOverlay() },
                    modifier = Modifier.testTag("toggle_decision_overlay_switch")
                )
            }
        }
    }
}

/**
 * Stage 4: Game State Understanding Metrics Card.
 */
@Composable
private fun GameStateCard(gameState: DlsGameStateAnalyzer.GameState) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("game_state_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_game_state),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                val phaseBadgeColor = when (gameState.phase) {
                    DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY -> StatusActiveGreen
                    DlsGameStateAnalyzer.MatchPhase.MATCH_STOPPED_OR_REPLAY -> StatusWarningAmber
                    DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI -> StatusInactiveGray
                    DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION -> Color(0xFFFFD600)
                    DlsGameStateAnalyzer.MatchPhase.UNKNOWN -> StatusInactiveGray
                }

                Surface(
                    color = phaseBadgeColor.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = gameState.phase.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = phaseBadgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 1. Current Phase Row
            StatusItemRow(
                title = stringResource(R.string.label_game_state_phase),
                value = gameState.phaseDescription,
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Explore,
                testTag = "game_state_phase_value"
            )

            // 2. Ball State & Position
            val ball = gameState.ball
            val (ballColor, ballText) = if (ball != null && ball.isTracked) {
                StatusActiveGreen to "X: ${ball.x.toInt()}, Y: ${ball.y.toInt()} (${(ball.confidence * 100).toInt()}%)"
            } else {
                StatusWarningAmber to "Lost / Not Detected"
            }
            StatusItemRow(
                title = stringResource(R.string.label_ball_state),
                value = ballText,
                indicatorColor = ballColor,
                icon = Icons.Default.SportsSoccer,
                testTag = "game_state_ball_value"
            )

            // 3. Ball Velocity & Direction
            val velText = if (ball != null && ball.speedPxPerSec > 15f) {
                "${ball.speedPxPerSec.toInt()} px/s | ${ball.directionName}"
            } else if (ball != null) {
                "Stationary (< 15 px/s)"
            } else {
                "N/A"
            }
            StatusItemRow(
                title = stringResource(R.string.label_ball_velocity),
                value = velText,
                indicatorColor = if (ball != null && ball.speedPxPerSec > 15f) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.Speed,
                testTag = "game_state_velocity_value"
            )

            // 4. Closest Player & Possession
            val closest = gameState.closestPlayer
            val (closestColor, closestText) = if (closest != null) {
                val poss = if (closest.hasPossession) " [IN POSSESSION]" else ""
                (if (closest.hasPossession) StatusActiveGreen else StatusWarningAmber) to "${closest.teamName} #${closest.player.id} (${closest.distancePx.toInt()} px)$poss"
            } else {
                StatusInactiveGray to "None detected"
            }
            StatusItemRow(
                title = stringResource(R.string.label_closest_player),
                value = closestText,
                indicatorColor = closestColor,
                icon = Icons.Default.GpsFixed,
                testTag = "game_state_closest_player_value"
            )

            // 5. Tracked Players & Team Grouping
            val tg = gameState.teamGrouping
            val teamGroupingText = "${gameState.players.size} players (Team 1: ${tg.team1Count}, Team 2: ${tg.team2Count})"
            StatusItemRow(
                title = stringResource(R.string.label_tracked_players),
                value = teamGroupingText,
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Groups,
                testTag = "game_state_players_value"
            )

            // 6. Overall Confidence & Latency
            val (confColor, confText) = "${(gameState.overallConfidence * 100).toInt()}%".let {
                if (gameState.overallConfidence >= 0.7f) StatusActiveGreen to it
                else if (gameState.overallConfidence >= 0.4f) StatusWarningAmber to it
                else StatusErrorRed to it
            }
            StatusItemRow(
                title = stringResource(R.string.label_overall_confidence),
                value = confText,
                indicatorColor = confColor,
                icon = Icons.Default.CheckCircle,
                testTag = "game_state_confidence_value"
            )

            StatusItemRow(
                title = stringResource(R.string.label_state_latency),
                value = "${gameState.stateProcessingDurationMs} ms (Total: ${gameState.totalLatencyMs} ms)",
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Timer,
                testTag = "game_state_latency_value"
            )
        }
    }
}

/**
 * Stage 3: Vision Analysis Metrics Card.
 */
@Composable
private fun VisionAnalysisCard(
    visionResult: DlsVisionAnalyzer.DetectionResult,
    analysisState: ImageAnalysisManager.AnalysisState
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vision_analysis_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Analytics,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = stringResource(R.string.title_vision_analysis),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 1. Field Pitch Detection Row
            val pitchCoverage = visionResult.fieldRegion?.grassCoveragePercent?.let { (it * 100).toInt() } ?: 0
            val (pitchColor, pitchText) = if (visionResult.isFieldDetected) {
                StatusActiveGreen to "Detected ($pitchCoverage% grass coverage)"
            } else {
                StatusWarningAmber to "Not Detected (< 20% grass)"
            }
            StatusItemRow(
                title = stringResource(R.string.label_field_detection),
                value = pitchText,
                indicatorColor = pitchColor,
                icon = Icons.Default.Layers,
                testTag = "field_detection_value"
            )

            // 2. Ball Detection Row
            val ball = visionResult.ball
            val (ballColor, ballText) = if (ball != null) {
                StatusActiveGreen to "Detected (${(ball.confidence * 100).toInt()}%)"
            } else {
                StatusWarningAmber to "Searching for ball..."
            }
            StatusItemRow(
                title = stringResource(R.string.label_ball_status),
                value = ballText,
                indicatorColor = ballColor,
                icon = Icons.Default.SportsSoccer,
                testTag = "ball_status_value"
            )

            // 3. Ball Coordinates
            val ballCoordsText = if (ball != null) {
                "X: ${ball.x.toInt()} px | Y: ${ball.y.toInt()} px (r: ${ball.radius.toInt()}px)"
            } else {
                "N/A"
            }
            StatusItemRow(
                title = stringResource(R.string.label_ball_coordinates),
                value = ballCoordsText,
                indicatorColor = if (ball != null) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.GpsFixed,
                testTag = "ball_coordinates_value"
            )

            // 4. Detected Players Row
            val playersCount = visionResult.players.size
            val team1Count = visionResult.players.count { it.teamId == 1 }
            val team2Count = visionResult.players.count { it.teamId == 2 }
            val playersText = if (playersCount > 0) {
                "$playersCount players (Team 1: $team1Count | Team 2: $team2Count)"
            } else {
                "No players segmented"
            }
            StatusItemRow(
                title = stringResource(R.string.label_players_count),
                value = playersText,
                indicatorColor = if (playersCount > 0) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.Groups,
                testTag = "players_count_value"
            )

            // 5. Vision Latency Row
            StatusItemRow(
                title = stringResource(R.string.label_vision_latency),
                value = "${visionResult.processingDurationMs} ms / frame",
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Speed,
                testTag = "vision_latency_value"
            )

            // 6. Frame Size Row
            val frameSizeDesc = if (visionResult.frameWidth > 0 && visionResult.frameHeight > 0) {
                "${visionResult.frameWidth} × ${visionResult.frameHeight} px"
            } else {
                "N/A"
            }
            StatusItemRow(
                title = stringResource(R.string.label_frame_size),
                value = frameSizeDesc,
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Analytics,
                testTag = "frame_size_value"
            )
        }
    }
}

/**
 * Stage 3 Vision Debug Sliders & Toggles Card.
 */
@Composable
private fun VisionDebugControlsCard(
    config: DlsVisionAnalyzer.VisionConfig,
    onToggleDebugOverlay: () -> Unit,
    onUpdateBallBrightness: (Float) -> Unit,
    onUpdateGrassHue: (Float, Float) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.label_debug_controls),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Enable CV Pitch & Player Overlay",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Draws real-time pitch bounds and player ground anchors on the preview",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = config.isDebugOverlayEnabled,
                    onCheckedChange = { onToggleDebugOverlay() },
                    modifier = Modifier.testTag("toggle_debug_overlay_switch")
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Ball Brightness Sensitivity (Min V in HSV):",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0.70f to "High (0.70)", 0.80f to "Standard (0.80)", 0.88f to "Strict (0.88)").forEach { (value, label) ->
                        val isSelected = (config.ballBrightnessMin - value).let { kotlin.math.abs(it) < 0.02f }
                        FilterChip(
                            selected = isSelected,
                            onClick = { onUpdateBallBrightness(value) },
                            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("ball_bright_chip_${(value * 100).toInt()}")
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Grass Field Hue Range:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        Triple(55f, 155f, "Standard (55°-155°)"),
                        Triple(50f, 165f, "Wide (50°-165°)"),
                        Triple(65f, 145f, "Strict (65°-145°)")
                    ).forEach { (minH, maxH, label) ->
                        val isSelected = (config.grassHueMin - minH).let { kotlin.math.abs(it) < 2f }
                        FilterChip(
                            selected = isSelected,
                            onClick = { onUpdateGrassHue(minH, maxH) },
                            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("grass_hue_chip_${minH.toInt()}")
                        )
                    }
                }
            }
        }
    }
}

/**
 * System Status Summary Card.
 */
@Composable
private fun StatusSummaryCard(uiState: MainUiState) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. DLS Installed / Status
            val dlsColor = if (uiState.isDlsInstalled) StatusActiveGreen else StatusErrorRed
            StatusItemRow(
                title = stringResource(R.string.status_dls),
                value = uiState.dlsStatusDescription,
                indicatorColor = dlsColor,
                icon = Icons.Default.Android,
                testTag = "status_dls_value"
            )

            // 2. Accessibility Service Status
            val (accColor, accText) = if (uiState.isAccessibilityConnected) {
                StatusActiveGreen to "Connected & Authorized"
            } else {
                StatusWarningAmber to "Disabled (Action Input Inactive)"
            }
            StatusItemRow(
                title = stringResource(R.string.label_accessibility_status),
                value = accText,
                indicatorColor = accColor,
                icon = Icons.Default.AccessibilityNew,
                testTag = "summary_accessibility_status_value"
            )

            // 3. Screen Capture Status
            val (captureColor, captureText) = when (val state = uiState.captureState) {
                is ScreenCaptureManager.CaptureState.Capturing -> {
                    StatusActiveGreen to "Capturing (${state.frameCount} frames, ${state.width}x${state.height})"
                }
                is ScreenCaptureManager.CaptureState.Starting -> {
                    StatusWarningAmber to "Starting capture service..."
                }
                is ScreenCaptureManager.CaptureState.Error -> {
                    StatusErrorRed to "Error: ${state.message}"
                }
                is ScreenCaptureManager.CaptureState.Idle -> {
                    StatusInactiveGray to "Idle (Not Capturing)"
                }
            }
            StatusItemRow(
                title = stringResource(R.string.status_screen_capture),
                value = captureText,
                indicatorColor = captureColor,
                icon = if (uiState.captureState is ScreenCaptureManager.CaptureState.Capturing) Icons.Default.Videocam else Icons.Default.VideocamOff,
                testTag = "status_screen_capture_value"
            )

            // 4. Image Analysis Status
            val analysisColor = if (uiState.analysisState.isAnalyzing) StatusActiveGreen else StatusInactiveGray
            StatusItemRow(
                title = stringResource(R.string.status_analysis),
                value = uiState.analysisState.statusMessage,
                indicatorColor = analysisColor,
                icon = Icons.Default.Sensors,
                testTag = "status_analysis_value"
            )

            // 5. Bot Execution Status
            val (botColor, botText) = when (uiState.controlLoopState.status) {
                BotController.LoopStatus.RUNNING -> StatusActiveGreen to "RUNNING (Loop Active)"
                BotController.LoopStatus.PAUSED -> StatusWarningAmber to "PAUSED (${uiState.controlLoopState.statusMessage})"
                BotController.LoopStatus.STOPPED -> StatusInactiveGray to "STOPPED"
                BotController.LoopStatus.ERROR -> StatusErrorRed to "ERROR (${uiState.controlLoopState.statusMessage})"
            }
            StatusItemRow(
                title = stringResource(R.string.status_bot),
                value = botText,
                indicatorColor = botColor,
                icon = Icons.Default.SmartToy,
                testTag = "status_bot_value"
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Stage 8 Compact Status Panel (Requirement 13)
            Text(
                text = "STAGE 8: CONNECTIVITY & MODE",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Stage 8: 1. Connection Status
            val connStatusColor = when (uiState.connectivityState.status) {
                ConnectivityModeManager.ConnectionStatus.ONLINE -> StatusActiveGreen
                ConnectivityModeManager.ConnectionStatus.OFFLINE -> StatusErrorRed
                ConnectivityModeManager.ConnectionStatus.CHECKING -> StatusWarningAmber
            }
            StatusItemRow(
                title = stringResource(R.string.label_connection_status),
                value = uiState.connectivityState.status.label,
                indicatorColor = connStatusColor,
                icon = if (uiState.connectivityState.status == ConnectivityModeManager.ConnectionStatus.ONLINE) Icons.Default.Wifi else Icons.Default.WifiOff,
                testTag = "summary_connection_status_value"
            )

            // Stage 8: 2. Internet Available
            val (summaryAvailColor, summaryAvailText) = if (uiState.connectivityState.isInternetAvailable) {
                StatusActiveGreen to "Yes (Verified)"
            } else if (uiState.connectivityState.status == ConnectivityModeManager.ConnectionStatus.CHECKING) {
                StatusWarningAmber to "Checking..."
            } else {
                StatusErrorRed to "No (Offline)"
            }
            StatusItemRow(
                title = stringResource(R.string.label_internet_available),
                value = summaryAvailText,
                indicatorColor = summaryAvailColor,
                icon = Icons.Default.Public,
                testTag = "summary_internet_available_value"
            )

            // Stage 8: 3. Selected Mode
            val summaryModeColor = if (uiState.connectivityState.selectedMode == ConnectivityModeManager.GameMode.CAREER) {
                Color(0xFF3B82F6)
            } else {
                Color(0xFFF97316)
            }
            StatusItemRow(
                title = stringResource(R.string.label_selected_mode),
                value = uiState.connectivityState.selectedMode.label,
                indicatorColor = summaryModeColor,
                icon = Icons.Default.SportsScore,
                testTag = "summary_selected_mode_value"
            )

            // Stage 8: 4. Last Check Time
            StatusItemRow(
                title = stringResource(R.string.label_last_check_time),
                value = uiState.connectivityState.lastCheckTime,
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Timer,
                testTag = "summary_last_check_time_value"
            )

            // Stage 8: 5. Connection Check Latency
            val summaryLatencyText = if (uiState.connectivityState.latencyMs > 0) "${uiState.connectivityState.latencyMs} ms" else "N/A"
            StatusItemRow(
                title = stringResource(R.string.label_check_latency),
                value = summaryLatencyText,
                indicatorColor = if (uiState.connectivityState.isInternetAvailable) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.Speed,
                testTag = "summary_check_latency_value"
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Stage 9 Compact Status Panel (Requirement 7)
            Text(
                text = "STAGE 9: AUTONOMOUS ORCHESTRATOR",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Stage 9: 1. Automation Status
            val autoStatusColor = when (uiState.orchestratorState.automationStatus) {
                AutonomousGameplayOrchestrator.AutomationStatus.RUNNING -> StatusActiveGreen
                AutonomousGameplayOrchestrator.AutomationStatus.PAUSED -> StatusWarningAmber
                AutonomousGameplayOrchestrator.AutomationStatus.STOPPED,
                AutonomousGameplayOrchestrator.AutomationStatus.IDLE -> StatusInactiveGray
                AutonomousGameplayOrchestrator.AutomationStatus.ERROR,
                AutonomousGameplayOrchestrator.AutomationStatus.EMERGENCY_STOPPED -> StatusErrorRed
            }
            StatusItemRow(
                title = stringResource(R.string.label_automation_status),
                value = uiState.orchestratorState.automationStatus.label,
                indicatorColor = autoStatusColor,
                icon = Icons.Default.RocketLaunch,
                testTag = "summary_automation_status_value"
            )

            // Stage 9: 2. Current Mode
            val currModeColor = if (uiState.orchestratorState.currentMode == ConnectivityModeManager.GameMode.CAREER) {
                Color(0xFF3B82F6)
            } else {
                Color(0xFFF97316)
            }
            StatusItemRow(
                title = stringResource(R.string.label_current_mode),
                value = uiState.orchestratorState.currentMode.label,
                indicatorColor = currModeColor,
                icon = Icons.Default.Public,
                testTag = "summary_current_mode_value"
            )

            // Stage 9: 3. Current Game State
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_state),
                value = uiState.orchestratorState.currentGameState.label,
                indicatorColor = MaterialTheme.colorScheme.secondary,
                icon = Icons.Default.SportsSoccer,
                testTag = "summary_current_game_state_value"
            )

            // Stage 9: 4. Current Action
            val actionColor = Color(uiState.orchestratorState.currentAction.colorHex)
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_action),
                value = uiState.orchestratorState.currentAction.label,
                indicatorColor = actionColor,
                icon = Icons.Default.TouchApp,
                testTag = "summary_current_action_value"
            )

            // Stage 9: 5. Loop Status
            val orchLoopColor = when (uiState.orchestratorState.loopStatus) {
                BotController.LoopStatus.RUNNING -> StatusActiveGreen
                BotController.LoopStatus.PAUSED -> StatusWarningAmber
                BotController.LoopStatus.STOPPED -> StatusInactiveGray
                BotController.LoopStatus.ERROR -> StatusErrorRed
            }
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_loop_status),
                value = uiState.orchestratorState.loopStatus.label,
                indicatorColor = orchLoopColor,
                icon = Icons.Default.Timeline,
                testTag = "summary_orchestrator_loop_status_value"
            )

            // Stage 9: 6. Last Decision
            val decisionText = if (uiState.orchestratorState.lastDecisionConfidence > 0f) {
                "${uiState.orchestratorState.lastDecision.label} (${(uiState.orchestratorState.lastDecisionConfidence * 100).toInt()}%)"
            } else {
                uiState.orchestratorState.lastDecision.label
            }
            StatusItemRow(
                title = stringResource(R.string.label_last_decision),
                value = decisionText,
                indicatorColor = Color(uiState.orchestratorState.lastDecision.badgeColorHex),
                icon = Icons.Default.Psychology,
                testTag = "summary_last_decision_value"
            )

            // Stage 9: 7. Loop Latency
            val latencyText = if (uiState.orchestratorState.loopLatencyMs > 0) {
                "${uiState.orchestratorState.loopLatencyMs} ms (Avg: ${uiState.orchestratorState.avgLoopLatencyMs.toInt()} ms)"
            } else "N/A"
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_latency),
                value = latencyText,
                indicatorColor = if (uiState.orchestratorState.loopLatencyMs > 0) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.Speed,
                testTag = "summary_orchestrator_latency_value"
            )

            // Stage 9: 8. Safety Status
            val safetyColor = Color(uiState.orchestratorState.safetyStatus.colorHex)
            StatusItemRow(
                title = stringResource(R.string.label_safety_status),
                value = uiState.orchestratorState.safetyStatus.label,
                indicatorColor = safetyColor,
                icon = Icons.Default.Shield,
                testTag = "summary_safety_status_value"
            )
        }
    }
}

@Composable
private fun StatusItemRow(
    title: String,
    value: String,
    indicatorColor: Color,
    icon: ImageVector,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(indicatorColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = indicatorColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
        }

        Surface(
            color = indicatorColor.copy(alpha = 0.12f),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = indicatorColor,
                modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag(testTag)
            )
        }
    }
}

/**
 * Stage 8: Connectivity & Mode Manager Card.
 */
@Composable
private fun ConnectivityModeCard(
    connectivityState: ConnectivityModeManager.ConnectivityState,
    onRefreshConnectivity: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connectivity_mode_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row with Title and Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_connectivity_mode),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                val badgeBg = when (connectivityState.status) {
                    ConnectivityModeManager.ConnectionStatus.ONLINE -> StatusActiveGreen.copy(alpha = 0.16f)
                    ConnectivityModeManager.ConnectionStatus.OFFLINE -> StatusErrorRed.copy(alpha = 0.16f)
                    ConnectivityModeManager.ConnectionStatus.CHECKING -> StatusWarningAmber.copy(alpha = 0.16f)
                }
                val badgeFg = when (connectivityState.status) {
                    ConnectivityModeManager.ConnectionStatus.ONLINE -> StatusActiveGreen
                    ConnectivityModeManager.ConnectionStatus.OFFLINE -> StatusErrorRed
                    ConnectivityModeManager.ConnectionStatus.CHECKING -> StatusWarningAmber
                }
                val statusLabel = when (connectivityState.status) {
                    ConnectivityModeManager.ConnectionStatus.ONLINE -> "ONLINE"
                    ConnectivityModeManager.ConnectionStatus.OFFLINE -> "OFFLINE"
                    ConnectivityModeManager.ConnectionStatus.CHECKING -> "CHECKING..."
                }
                val statusIcon = when (connectivityState.status) {
                    ConnectivityModeManager.ConnectionStatus.ONLINE -> Icons.Default.Wifi
                    ConnectivityModeManager.ConnectionStatus.OFFLINE -> Icons.Default.WifiOff
                    ConnectivityModeManager.ConnectionStatus.CHECKING -> Icons.Default.Refresh
                }

                Surface(
                    color = badgeBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = statusIcon,
                            contentDescription = null,
                            tint = badgeFg,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = badgeFg,
                            modifier = Modifier.testTag("connectivity_status_badge")
                        )
                    }
                }
            }

            // Selected Game Mode Highlight Banner
            val isCareer = connectivityState.selectedMode == ConnectivityModeManager.GameMode.CAREER
            val modeContainerColor = if (isCareer) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
            } else {
                MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f)
            }
            val modeContentColor = if (isCareer) {
                MaterialTheme.colorScheme.onPrimaryContainer
            } else {
                MaterialTheme.colorScheme.onTertiaryContainer
            }

            Surface(
                color = modeContainerColor,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(modeContentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCareer) Icons.Default.SportsSoccer else Icons.Default.SportsFootball,
                            contentDescription = null,
                            tint = modeContentColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "SELECTED MODE:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = modeContentColor.copy(alpha = 0.8f)
                            )
                            Text(
                                text = connectivityState.selectedMode.label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = modeContentColor,
                                modifier = Modifier.testTag("selected_game_mode_banner_text")
                            )
                        }
                        Text(
                            text = connectivityState.selectedMode.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = modeContentColor.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // 1. Connection Status Row
            val statusColor = when (connectivityState.status) {
                ConnectivityModeManager.ConnectionStatus.ONLINE -> StatusActiveGreen
                ConnectivityModeManager.ConnectionStatus.OFFLINE -> StatusErrorRed
                ConnectivityModeManager.ConnectionStatus.CHECKING -> StatusWarningAmber
            }
            StatusItemRow(
                title = stringResource(R.string.label_connection_status),
                value = connectivityState.status.label,
                indicatorColor = statusColor,
                icon = if (connectivityState.status == ConnectivityModeManager.ConnectionStatus.ONLINE) Icons.Default.Wifi else Icons.Default.WifiOff,
                testTag = "connectivity_status_value"
            )

            // 2. Internet Available Row
            val (availColor, availText) = if (connectivityState.isInternetAvailable) {
                StatusActiveGreen to "Yes (Online Reachable)"
            } else if (connectivityState.status == ConnectivityModeManager.ConnectionStatus.CHECKING) {
                StatusWarningAmber to "Checking Reachability..."
            } else {
                StatusErrorRed to "No (Offline / No Uplink)"
            }
            StatusItemRow(
                title = stringResource(R.string.label_internet_available),
                value = availText,
                indicatorColor = availColor,
                icon = Icons.Default.Public,
                testTag = "internet_available_value"
            )

            // 3. Selected Mode Row
            val modeBadgeColor = if (isCareer) Color(0xFF3B82F6) else Color(0xFFF97316)
            StatusItemRow(
                title = stringResource(R.string.label_selected_mode),
                value = connectivityState.selectedMode.label,
                indicatorColor = modeBadgeColor,
                icon = Icons.Default.SportsScore,
                testTag = "selected_mode_value"
            )

            // 4. Last Check Time Row
            StatusItemRow(
                title = stringResource(R.string.label_last_check_time),
                value = connectivityState.lastCheckTime,
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Timer,
                testTag = "last_check_time_value"
            )

            // 5. Connection Check Latency Row
            val latencyText = if (connectivityState.latencyMs > 0) "${connectivityState.latencyMs} ms" else "N/A"
            StatusItemRow(
                title = stringResource(R.string.label_check_latency),
                value = latencyText,
                indicatorColor = if (connectivityState.isInternetAvailable) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.Speed,
                testTag = "connectivity_latency_value"
            )

            // 6. Network Interface / Diagnostic Detail
            StatusItemRow(
                title = stringResource(R.string.label_network_type),
                value = connectivityState.networkType,
                indicatorColor = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Layers,
                testTag = "network_type_value"
            )

            // Manual Refresh / Check Connection Button
            Button(
                onClick = onRefreshConnectivity,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("check_connection_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.btn_check_connection),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

/**
 * Stage 9: Autonomous Gameplay Orchestrator Panel Card.
 * Displays real-time continuous pipeline telemetry and controls.
 */
@Composable
private fun AutonomousGameplayOrchestratorCard(
    orchestratorState: AutonomousGameplayOrchestrator.OrchestratorState,
    config: AutonomousGameplayOrchestrator.OrchestratorConfig,
    isCapturing: Boolean,
    isAccessibilityConnected: Boolean,
    onStartAutomation: () -> Unit,
    onStopAutomation: () -> Unit,
    onPauseAutomation: () -> Unit,
    onResumeAutomation: () -> Unit,
    onSetMinConfidence: (Float) -> Unit,
    onSetCooldown: (Long) -> Unit,
    onToggleAutoPause: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit
) {
    val isRunning = orchestratorState.automationStatus == AutonomousGameplayOrchestrator.AutomationStatus.RUNNING
    val isPaused = orchestratorState.automationStatus == AutonomousGameplayOrchestrator.AutomationStatus.PAUSED

    val statusBadgeColor = when (orchestratorState.automationStatus) {
        AutonomousGameplayOrchestrator.AutomationStatus.RUNNING -> StatusActiveGreen
        AutonomousGameplayOrchestrator.AutomationStatus.PAUSED -> StatusWarningAmber
        AutonomousGameplayOrchestrator.AutomationStatus.STOPPED,
        AutonomousGameplayOrchestrator.AutomationStatus.IDLE -> StatusInactiveGray
        AutonomousGameplayOrchestrator.AutomationStatus.ERROR,
        AutonomousGameplayOrchestrator.AutomationStatus.EMERGENCY_STOPPED -> StatusErrorRed
    }

    val modeColor = if (orchestratorState.currentMode == ConnectivityModeManager.GameMode.CAREER) {
        Color(0xFF3B82F6) // Bright Blue for Career
    } else {
        Color(0xFFF97316) // Bright Orange for Exhibition
    }

    val safetyBadgeColor = Color(orchestratorState.safetyStatus.colorHex)

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("autonomous_orchestrator_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row with Title and Dynamic Automation Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_stage9_orchestrator),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = statusBadgeColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(statusBadgeColor)
                        )
                        Text(
                            text = orchestratorState.automationStatus.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = statusBadgeColor,
                            modifier = Modifier.testTag("orchestrator_status_badge")
                        )
                    }
                }
            }

            // Highlight Banner: Mode & Automation State
            Surface(
                color = modeColor.copy(alpha = 0.10f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(modeColor.copy(alpha = 0.20f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (orchestratorState.currentMode == ConnectivityModeManager.GameMode.CAREER) Icons.Default.Public else Icons.Default.SportsFootball,
                            contentDescription = null,
                            tint = modeColor,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "ACTIVE MODE:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Surface(
                                color = modeColor.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = orchestratorState.currentMode.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = modeColor,
                                    modifier = Modifier
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                        .testTag("orchestrator_mode_badge")
                                )
                            }
                        }

                        Text(
                            text = orchestratorState.statusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("orchestrator_status_message")
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Stage 9 Required Status Items (Requirement 7)
            Text(
                text = "PIPELINE ORCHESTRATION TELEMETRY",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            // 1. Current Game State
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_state),
                value = orchestratorState.currentGameState.label,
                indicatorColor = MaterialTheme.colorScheme.secondary,
                icon = Icons.Default.SportsSoccer,
                testTag = "orchestrator_game_state_value"
            )

            // 2. Current Action
            val actionColor = Color(orchestratorState.currentAction.colorHex)
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_action),
                value = orchestratorState.currentAction.label,
                indicatorColor = actionColor,
                icon = Icons.Default.TouchApp,
                testTag = "orchestrator_current_action_value"
            )

            // 3. Loop Status
            val loopColor = when (orchestratorState.loopStatus) {
                BotController.LoopStatus.RUNNING -> StatusActiveGreen
                BotController.LoopStatus.PAUSED -> StatusWarningAmber
                BotController.LoopStatus.STOPPED -> StatusInactiveGray
                BotController.LoopStatus.ERROR -> StatusErrorRed
            }
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_loop_status),
                value = orchestratorState.loopStatus.label,
                indicatorColor = loopColor,
                icon = Icons.Default.Timeline,
                testTag = "orchestrator_loop_status_value"
            )

            // 4. Last Decision with Confidence & Reason
            val decisionLabel = if (orchestratorState.lastDecisionConfidence > 0f) {
                "${orchestratorState.lastDecision.label} (${(orchestratorState.lastDecisionConfidence * 100).toInt()}%)"
            } else {
                orchestratorState.lastDecision.label
            }
            StatusItemRow(
                title = stringResource(R.string.label_last_decision),
                value = decisionLabel,
                indicatorColor = Color(orchestratorState.lastDecision.badgeColorHex),
                icon = Icons.Default.Psychology,
                testTag = "orchestrator_last_decision_value"
            )
            Text(
                text = "Reason: ${orchestratorState.lastDecisionReason}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .padding(start = 4.dp)
                    .testTag("orchestrator_decision_reason_text")
            )

            // 5. Loop Latency
            val latencyDisplay = if (orchestratorState.loopLatencyMs > 0) {
                "${orchestratorState.loopLatencyMs} ms (Avg: ${orchestratorState.avgLoopLatencyMs.toInt()} ms)"
            } else "N/A"
            StatusItemRow(
                title = stringResource(R.string.label_orchestrator_latency),
                value = latencyDisplay,
                indicatorColor = if (orchestratorState.loopLatencyMs > 0) StatusActiveGreen else StatusInactiveGray,
                icon = Icons.Default.Speed,
                testTag = "orchestrator_loop_latency_value"
            )

            // 6. Safety Status
            Surface(
                color = safetyBadgeColor.copy(alpha = 0.12f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = safetyBadgeColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.label_safety_status) + ":",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = safetyBadgeColor
                            )
                            Text(
                                text = orchestratorState.safetyStatus.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = safetyBadgeColor,
                                modifier = Modifier.testTag("orchestrator_safety_status_value")
                            )
                        }
                        Text(
                            text = orchestratorState.safetyMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.testTag("orchestrator_safety_message_text")
                        )
                    }
                }
            }

            // Stats counters: Cycles, Executed Actions, Skipped Frames
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("orchestrator_total_cycles_chip")
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "Total Cycles", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "${orchestratorState.totalCycles}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("orchestrator_dispatched_actions_chip")
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "Actions Dispatched", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "${orchestratorState.executedActionsCount}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = StatusActiveGreen)
                    }
                }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("orchestrator_skipped_frames_chip")
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "Skipped (Safe)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "${orchestratorState.skippedFramesCount}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = StatusWarningAmber)
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Prerequisite Warnings
            if (!isCapturing || !isAccessibilityConnected) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (!isCapturing) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.VideocamOff, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                Text("Screen Capture is NOT active. Tap 'Start Screen Capture' above.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                        if (!isAccessibilityConnected) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                Text("Accessibility Service is NOT enabled.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                            OutlinedButton(
                                onClick = onOpenAccessibilitySettings,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_orchestrator_open_accessibility")
                            ) {
                                Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Enable Accessibility in Settings", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            // Controls (Requirement 8)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (!isRunning && !isPaused) {
                    Button(
                        onClick = onStartAutomation,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusActiveGreen),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_start_automation")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.btn_start_automation), fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onStopAutomation,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusErrorRed),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_stop_automation")
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.btn_stop_automation), fontWeight = FontWeight.Bold)
                    }

                    if (isRunning) {
                        OutlinedButton(
                            onClick = onPauseAutomation,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_pause_automation")
                        ) {
                            Icon(Icons.Default.PauseCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(stringResource(R.string.btn_pause_automation), fontWeight = FontWeight.SemiBold)
                        }
                    } else if (isPaused) {
                        Button(
                            onClick = onResumeAutomation,
                            colors = ButtonDefaults.buttonColors(containerColor = StatusActiveGreen),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_resume_automation")
                        ) {
                            Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(stringResource(R.string.btn_resume_automation), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // Safety Configuration Sliders & Toggles
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Text(
                text = "SAFETY CONFIGURATION & DEBOUNCING",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            // Auto-pause toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Auto-Pause in Menus & Cutscenes",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Suspends action dispatch during UI screens and resumes when in-play",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = config.autoPauseOnMenu,
                    onCheckedChange = { onToggleAutoPause() },
                    modifier = Modifier.testTag("switch_orchestrator_auto_pause")
                )
            }

            // Min Confidence Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Safety Min Confidence: ${(config.minConfidenceThreshold * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0.30f, 0.40f, 0.50f, 0.70f).forEach { threshold ->
                        FilterChip(
                            selected = (config.minConfidenceThreshold - threshold).let { it >= -0.01f && it <= 0.01f },
                            onClick = { onSetMinConfidence(threshold) },
                            label = { Text("${(threshold * 100).toInt()}%", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("chip_conf_${(threshold * 100).toInt()}")
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// STAGE 10: MATCH LIFECYCLE MANAGER CARD
// ==========================================

@Composable
fun MatchLifecycleCard(
    lifecycleTelemetry: MatchLifecycleManager.LifecycleTelemetry,
    onResetLifecycle: () -> Unit = {},
    onAdvanceLifecycleState: (MatchLifecycleManager.LifecycleState) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val state = lifecycleTelemetry.lifecycleState
    val badgeColor = when (state) {
        MatchLifecycleManager.LifecycleState.WAITING -> StatusInactiveGray
        MatchLifecycleManager.LifecycleState.MATCH_STARTING -> Color(0xFF2196F3)
        MatchLifecycleManager.LifecycleState.PLAYING -> StatusActiveGreen
        MatchLifecycleManager.LifecycleState.MATCH_PAUSED -> StatusWarningAmber
        MatchLifecycleManager.LifecycleState.MATCH_FINISHED -> Color(0xFFFF9800)
        MatchLifecycleManager.LifecycleState.MATCH_RESULT -> Color(0xFF9C27B0)
        MatchLifecycleManager.LifecycleState.RETURNING_TO_MENU -> Color(0xFF3F51B5)
        MatchLifecycleManager.LifecycleState.READY_FOR_NEXT_MATCH -> Color(0xFF00E676)
        MatchLifecycleManager.LifecycleState.EMERGENCY_STOPPED -> StatusErrorRed
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("match_lifecycle_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row: Icon, Title & State Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Icon(
                        imageVector = Icons.Default.Autorenew,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_stage10_match_lifecycle),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = badgeColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, badgeColor)
                ) {
                    Text(
                        text = state.label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        modifier = Modifier
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                            .testTag("lifecycle_state_value")
                    )
                }
            }

            // Status message & Duration in state
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = lifecycleTelemetry.statusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.testTag("lifecycle_status_message_text")
                        )
                        Text(
                            text = "State active for ${lifecycleTelemetry.stateDurationSeconds}s",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Requirement 11 Key Metrics: Current Mode, Detection Confidence, Lifecycle Latency
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Current Mode
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = stringResource(R.string.label_lifecycle_mode),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = lifecycleTelemetry.currentMode.label,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("lifecycle_mode_value")
                        )
                    }
                }

                // Detection Confidence
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = stringResource(R.string.label_lifecycle_confidence),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${(lifecycleTelemetry.detectionConfidence * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (lifecycleTelemetry.detectionConfidence >= 0.5f) StatusActiveGreen else StatusWarningAmber,
                            modifier = Modifier.testTag("lifecycle_confidence_value")
                        )
                    }
                }

                // Lifecycle Latency
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = stringResource(R.string.label_lifecycle_latency),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${lifecycleTelemetry.lifecycleLatencyMs} ms",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("lifecycle_latency_value")
                        )
                    }
                }
            }

            // Lifecycle Flags: Match Detected, Match Started, Match Finished, Result Screen Detected, Ready For Next Match
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "LIFECYCLE SIGNALS & DETECTION GATES",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Row 1: Match Detected & Match Started
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LifecycleFlagItem(
                            label = stringResource(R.string.label_match_detected),
                            value = lifecycleTelemetry.isMatchDetected,
                            testTag = "lifecycle_match_detected_value",
                            modifier = Modifier.weight(1f)
                        )
                        LifecycleFlagItem(
                            label = stringResource(R.string.label_match_started),
                            value = lifecycleTelemetry.isMatchStarted,
                            testTag = "lifecycle_match_started_value",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                    // Row 2: Match Finished & Result Screen Detected
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LifecycleFlagItem(
                            label = stringResource(R.string.label_match_finished),
                            value = lifecycleTelemetry.isMatchFinished,
                            testTag = "lifecycle_match_finished_value",
                            modifier = Modifier.weight(1f)
                        )
                        LifecycleFlagItem(
                            label = stringResource(R.string.label_result_screen_detected),
                            value = lifecycleTelemetry.isResultScreenDetected,
                            testTag = "lifecycle_result_screen_value",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                    // Row 3: Ready For Next Match
                    LifecycleFlagItem(
                        label = stringResource(R.string.label_ready_for_next_match),
                        value = lifecycleTelemetry.isReadyForNextMatch,
                        testTag = "lifecycle_ready_next_match_value",
                        highlightIfTrue = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Frame Stability Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StabilityChip(
                    label = "In-Play Frames",
                    count = lifecycleTelemetry.consecutivePlayingFrames,
                    active = lifecycleTelemetry.consecutivePlayingFrames > 0,
                    modifier = Modifier.weight(1f)
                )
                StabilityChip(
                    label = "Paused Frames",
                    count = lifecycleTelemetry.consecutivePausedFrames,
                    active = lifecycleTelemetry.consecutivePausedFrames > 0,
                    modifier = Modifier.weight(1f)
                )
                StabilityChip(
                    label = "Menu/Result",
                    count = lifecycleTelemetry.consecutiveMenuFrames,
                    active = lifecycleTelemetry.consecutiveMenuFrames > 0,
                    modifier = Modifier.weight(1f)
                )
                StabilityChip(
                    label = "Finished",
                    count = lifecycleTelemetry.consecutiveFinishedFrames,
                    active = lifecycleTelemetry.consecutiveFinishedFrames > 0,
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Action & Transition Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onResetLifecycle,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_reset_lifecycle")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.btn_reset_lifecycle), style = MaterialTheme.typography.labelSmall)
                }
            }

            // Quick State Advance Chips for Simulation & Diagnostic Testing
            Text(
                text = "MANUAL STATE SIMULATION & DIAGNOSTICS",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    MatchLifecycleManager.LifecycleState.WAITING,
                    MatchLifecycleManager.LifecycleState.MATCH_STARTING,
                    MatchLifecycleManager.LifecycleState.PLAYING,
                    MatchLifecycleManager.LifecycleState.MATCH_PAUSED
                ).forEach { targetState ->
                    FilterChip(
                        selected = state == targetState,
                        onClick = { onAdvanceLifecycleState(targetState) },
                        label = { Text(targetState.name.take(7), style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_advance_state_${targetState.name.lowercase()}")
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    MatchLifecycleManager.LifecycleState.MATCH_FINISHED,
                    MatchLifecycleManager.LifecycleState.MATCH_RESULT,
                    MatchLifecycleManager.LifecycleState.RETURNING_TO_MENU,
                    MatchLifecycleManager.LifecycleState.READY_FOR_NEXT_MATCH
                ).forEach { targetState ->
                    FilterChip(
                        selected = state == targetState,
                        onClick = { onAdvanceLifecycleState(targetState) },
                        label = { Text(targetState.name.take(7), style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_advance_state_${targetState.name.lowercase()}")
                    )
                }
            }
        }
    }
}

@Composable
private fun LifecycleFlagItem(
    label: String,
    value: Boolean,
    testTag: String,
    highlightIfTrue: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = if (value) Icons.Default.CheckCircle else Icons.Default.Cancel,
            contentDescription = null,
            tint = if (value) {
                if (highlightIfTrue) Color(0xFF00E676) else StatusActiveGreen
            } else StatusInactiveGray,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = label + ":",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = if (value) "YES" else "NO",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = if (value) {
                if (highlightIfTrue) Color(0xFF00E676) else StatusActiveGreen
            } else StatusInactiveGray,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun StabilityChip(
    label: String,
    count: Int,
    active: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (active) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 9.sp
            )
            Text(
                text = "$count",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// ==========================================
// STAGE 11: CENTRAL PIPELINE & SAFETY DASHBOARD
// ==========================================

@Composable
fun CentralPipelineSafetyCard(
    healthTelemetry: SystemHealthSafetyCoordinator.PipelineHealthTelemetry,
    isCapturing: Boolean,
    isAccessibilityConnected: Boolean,
    onStartSafeAutomation: () -> Unit = {},
    onStopSafeAutomation: () -> Unit = {},
    onEmergencyStop: () -> Unit = {},
    onClearEmergencyHalt: () -> Unit = {},
    onRunHealthDiagnostics: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val status = healthTelemetry.systemStatus
    val badgeColor = Color(status.colorHex)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("central_pipeline_safety_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        border = BorderStroke(1.5.dp, badgeColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row: Title & Central System Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = stringResource(R.string.title_stage11_safety_integration),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = badgeColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, badgeColor)
                ) {
                    Text(
                        text = status.label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        modifier = Modifier
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                            .testTag("central_system_status_value")
                    )
                }
            }

            // Overall Pipeline Confidence Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.label_central_confidence),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${(healthTelemetry.overallConfidence * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (healthTelemetry.overallConfidence >= 0.70f) StatusActiveGreen
                            else if (healthTelemetry.overallConfidence >= 0.40f) StatusWarningAmber else StatusErrorRed,
                            modifier = Modifier.testTag("central_confidence_value")
                        )
                    }

                    // Visual Confidence Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(healthTelemetry.overallConfidence.coerceIn(0.01f, 1f))
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    if (healthTelemetry.overallConfidence >= 0.70f) StatusActiveGreen
                                    else if (healthTelemetry.overallConfidence >= 0.40f) StatusWarningAmber else StatusErrorRed
                                )
                        )
                    }
                }
            }

            // Last Error or Degradation Alert Notice (Requirement 2 & 5)
            if (healthTelemetry.lastError != null || healthTelemetry.safeRecoveryReason != null) {
                Surface(
                    color = if (healthTelemetry.lastError != null) StatusErrorRed.copy(alpha = 0.12f) else StatusWarningAmber.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (healthTelemetry.lastError != null) StatusErrorRed else StatusWarningAmber),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (healthTelemetry.lastError != null) Icons.Default.Warning else Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = if (healthTelemetry.lastError != null) StatusErrorRed else StatusWarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (healthTelemetry.lastError != null) stringResource(R.string.label_last_error) else stringResource(R.string.label_safe_recovery),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (healthTelemetry.lastError != null) StatusErrorRed else StatusWarningAmber
                            )
                            Text(
                                text = healthTelemetry.lastError ?: healthTelemetry.safeRecoveryReason ?: "Operating under safe state constraints",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("central_last_error_text")
                            )
                        }
                    }
                }
            }

            // 7-Stage Central Pipeline Status Table (Requirement 1 & 2)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "UNIFIED 7-STAGE PIPELINE STATUS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // 1. Screen Capture Status
                    PipelineStatusRow(
                        stageIndex = "1",
                        label = stringResource(R.string.label_screen_capture_status_st11),
                        statusText = healthTelemetry.screenCaptureStatus,
                        isValid = healthTelemetry.isScreenCaptureActive,
                        testTag = "st11_screen_capture_status"
                    )

                    // 2. Vision Status
                    PipelineStatusRow(
                        stageIndex = "2",
                        label = stringResource(R.string.label_vision_status_st11),
                        statusText = healthTelemetry.visionStatus,
                        isValid = healthTelemetry.isVisionValid,
                        testTag = "st11_vision_status"
                    )

                    // 3. Game State Status
                    PipelineStatusRow(
                        stageIndex = "3",
                        label = stringResource(R.string.label_game_state_status_st11),
                        statusText = healthTelemetry.gameStateStatus,
                        isValid = healthTelemetry.isGameStateStable,
                        testTag = "st11_game_state_status"
                    )

                    // 4. Decision Engine Status
                    PipelineStatusRow(
                        stageIndex = "4",
                        label = stringResource(R.string.label_decision_engine_status_st11),
                        statusText = healthTelemetry.decisionEngineStatus,
                        isValid = true,
                        testTag = "st11_decision_engine_status"
                    )

                    // 5. Action Execution Status
                    PipelineStatusRow(
                        stageIndex = "5",
                        label = stringResource(R.string.label_action_execution_status_st11),
                        statusText = healthTelemetry.actionExecutionStatus,
                        isValid = healthTelemetry.isAccessibilityConnected,
                        testTag = "st11_action_execution_status"
                    )

                    // 6. Match Lifecycle Status
                    PipelineStatusRow(
                        stageIndex = "6",
                        label = stringResource(R.string.label_match_lifecycle_status_st11),
                        statusText = healthTelemetry.matchLifecycleStatus,
                        isValid = healthTelemetry.isGameplayGateOpen,
                        testTag = "st11_match_lifecycle_status"
                    )

                    // 7. Connectivity/Mode Status
                    PipelineStatusRow(
                        stageIndex = "7",
                        label = stringResource(R.string.label_connectivity_mode_status_st11),
                        statusText = healthTelemetry.connectivityModeStatus,
                        isValid = true,
                        testTag = "st11_connectivity_mode_status"
                    )
                }
            }

            // Key Telemetry Metrics (Latency, Cycles, Dispatched, Skipped)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "Pipeline Latency",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "${healthTelemetry.endToEndPipelineLatencyMs} ms",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("st11_pipeline_latency_value")
                        )
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "Cycles Processed",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "${healthTelemetry.totalProcessedFrames}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("st11_processed_cycles_value")
                        )
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "Actions Dispatched",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "${healthTelemetry.totalDispatchedTouches}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusActiveGreen,
                            modifier = Modifier.testTag("st11_dispatched_actions_value")
                        )
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "Safe Skips",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "${healthTelemetry.totalSkippedSafeFrames}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusWarningAmber,
                            modifier = Modifier.testTag("st11_skipped_frames_value")
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Primary Control Actions (Safe Start, Safe Stop, Emergency Stop) (Requirements 3 & 4)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onStartSafeAutomation,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                    enabled = isCapturing && isAccessibilityConnected && status != SystemHealthSafetyCoordinator.CentralSystemStatus.EMERGENCY_STOPPED,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_safe_start_automation")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.btn_safe_start_automation), style = MaterialTheme.typography.labelSmall)
                }

                Button(
                    onClick = onStopSafeAutomation,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_safe_stop_automation")
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.btn_safe_stop_automation), style = MaterialTheme.typography.labelSmall)
                }
            }

            // Emergency Stop & Clear Emergency Row (Requirement 4)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onEmergencyStop,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusErrorRed),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_stage11_emergency_stop")
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.btn_emergency_stop), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }

                if (status == SystemHealthSafetyCoordinator.CentralSystemStatus.EMERGENCY_STOPPED) {
                    OutlinedButton(
                        onClick = onClearEmergencyHalt,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF00E676)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_clear_emergency_halt")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.btn_clear_emergency), style = MaterialTheme.typography.labelSmall)
                    }
                } else {
                    OutlinedButton(
                        onClick = onRunHealthDiagnostics,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_run_health_diagnostics")
                    ) {
                        Icon(Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.btn_run_diagnostics), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun PipelineStatusRow(
    stageIndex: String,
    label: String,
    statusText: String,
    isValid: Boolean,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.weight(1f, fill = false)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                shape = CircleShape,
                modifier = Modifier.size(18.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = stageIndex,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (isValid) Icons.Default.CheckCircle else Icons.Default.Cancel,
                contentDescription = null,
                tint = if (isValid) StatusActiveGreen else StatusInactiveGray,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = if (isValid) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.testTag(testTag)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DlsRobotScreenPreview() {
    MyApplicationTheme {
        DlsRobotScreen(
            uiState = MainUiState(
                dlsStatusDescription = "Installed (Ready)",
                isDlsInstalled = true,
                isAccessibilityConnected = true,
                captureState = ScreenCaptureManager.CaptureState.Capturing(
                    width = 1080,
                    height = 2400,
                    densityDpi = 480,
                    frameCount = 120
                ),
                analysisState = ImageAnalysisManager.AnalysisState(
                    isCaptureActive = true,
                    isAnalyzing = true,
                    frameCount = 120,
                    analyzedCount = 24,
                    frameWidth = 1080,
                    frameHeight = 2400,
                    statusMessage = "Analyzing (8ms / frame)"
                ),
                visionResult = DlsVisionAnalyzer.DetectionResult(
                    isFieldDetected = true,
                    ball = DlsVisionAnalyzer.DetectedBall(
                        x = 540f,
                        y = 1200f,
                        normX = 0.5f,
                        normY = 0.5f,
                        radius = 12f,
                        confidence = 0.92f
                    ),
                    players = listOf(
                        DlsVisionAnalyzer.DetectedPlayer(
                            id = 1,
                            x = 500f,
                            y = 1100f,
                            normX = 0.46f,
                            normY = 0.45f,
                            width = 40f,
                            height = 60f,
                            teamId = 1,
                            hue = 210f,
                            confidence = 0.88f
                        )
                    ),
                    processingDurationMs = 8L,
                    frameWidth = 1080,
                    frameHeight = 2400,
                    status = "Pitch Detected (78%) | 1 Player | Ball Located"
                ),
                gameState = DlsGameStateAnalyzer.GameState(
                    phase = DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY,
                    phaseDescription = "Match Active (78% pitch, 1 player)",
                    ball = DlsGameStateAnalyzer.BallState(
                        x = 540f,
                        y = 1200f,
                        normX = 0.5f,
                        normY = 0.5f,
                        velocityX = 120f,
                        velocityY = -45f,
                        speedPxPerSec = 128f,
                        directionAngleDeg = 339f,
                        directionName = "Up-Right (↗)",
                        predictedX = 576f,
                        predictedY = 1186f,
                        confidence = 0.92f,
                        isTracked = true
                    ),
                    overallConfidence = 0.85f,
                    stateProcessingDurationMs = 1L,
                    totalLatencyMs = 9L
                ),
                decision = DlsDecisionEngine.Decision(
                    actionType = DlsDecisionEngine.ActionType.CHASE_BALL,
                    targetX = 576f,
                    targetY = 1186f,
                    targetNormX = 0.53f,
                    targetNormY = 0.49f,
                    direction = "Up-Right (↗)",
                    directionAngleDeg = 339f,
                    durationMs = 300L,
                    confidence = 0.90f,
                    reason = "Loose ball nearby. Intercepting ball trajectory",
                    timestampMs = System.currentTimeMillis(),
                    decisionLatencyMs = 1L
                ),
                executionState = ActionExecutor.ExecutionState(
                    lastCommand = ActionExecutor.ExecutionCommand(
                        type = ActionExecutor.ExecutionType.MOVE,
                        startX = 194f,
                        startY = 540f,
                        endX = 280f,
                        endY = 500f,
                        durationMs = 250L,
                        confidence = 0.90f,
                        sourceDecision = DlsDecisionEngine.ActionType.CHASE_BALL,
                        reason = "Joystick movement towards Up-Right (↗)"
                    ),
                    isExecuting = false,
                    lastSuccess = true,
                    statusMessage = "Executing MOVE (Joystick movement towards Up-Right (↗))",
                    lastExecutionTimestampMs = System.currentTimeMillis(),
                    latencyMs = 2L,
                    totalExecutedCount = 15L
                ),
                botState = BotController.BotState.Running
            ),
            onLaunchDls = {},
            onStartScreenCapture = {},
            onStopScreenCapture = {},
            onStartBot = {},
            onStopBot = {},
            onPauseBot = {},
            onResumeBot = {},
            onToggleAutoPause = {},
            onSetAnalysisInterval = {},
            onToggleDebugOverlay = {},
            onUpdateBallBrightness = {},
            onUpdateGrassHue = { _, _ -> },
            onSetDecisionCooldown = {},
            onSetDecisionMinConfidence = {},
            onToggleDecisionDebugOverlay = {},
            onOpenAccessibilitySettings = {},
            onEmergencyStop = {},
            onToggleExecutionEnabled = {},
            onSetExecutionCooldown = {},
            onSetExecutionMinConfidence = {},
            onRefreshConnectivity = {},
            onTestTap = { _, _ -> },
            onTestSwipe = { _, _, _, _ -> },
            onTestMove = { _, _, _, _ -> },
            onDismissMessage = {}
        )
    }
}
