package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme
val TechPrimaryLight = Color(0xFF006399)
val TechOnPrimaryLight = Color(0xFFFFFFFF)
val TechPrimaryContainerLight = Color(0xFFCDE5FF)
val TechOnPrimaryContainerLight = Color(0xFF001D32)

val TechSecondaryLight = Color(0xFF006874)
val TechOnSecondaryLight = Color(0xFFFFFFFF)
val TechSecondaryContainerLight = Color(0xFF97F0FF)
val TechOnSecondaryContainerLight = Color(0xFF001F24)

val TechTertiaryLight = Color(0xFF006D44)
val TechOnTertiaryLight = Color(0xFFFFFFFF)
val TechTertiaryContainerLight = Color(0xFF90F7BE)
val TechOnTertiaryContainerLight = Color(0xFF002111)

val TechBackgroundLight = Color(0xFFF6FAFE)
val TechSurfaceLight = Color(0xFFF6FAFE)
val TechSurfaceVariantLight = Color(0xFFDEE3EB)
val TechOutlineLight = Color(0xFF72777F)

// Dark Scheme
val TechPrimaryDark = Color(0xFF94CCFF)
val TechOnPrimaryDark = Color(0xFF003352)
val TechPrimaryContainerDark = Color(0xFF004B74)
val TechOnPrimaryContainerDark = Color(0xFFCDE5FF)

val TechSecondaryDark = Color(0xFF4FD8EB)
val TechOnSecondaryDark = Color(0xFF00363D)
val TechSecondaryContainerDark = Color(0xFF004F58)
val TechOnSecondaryContainerDark = Color(0xFF97F0FF)

val TechTertiaryDark = Color(0xFF73DAA3)
val TechOnTertiaryDark = Color(0xFF003921)
val TechTertiaryContainerDark = Color(0xFF005232)
val TechOnTertiaryContainerDark = Color(0xFF90F7BE)

val TechBackgroundDark = Color(0xFF101418)
val TechSurfaceDark = Color(0xFF101418)
val TechSurfaceVariantDark = Color(0xFF41474D)
val TechOutlineDark = Color(0xFF8B9198)

// Status colors
val StatusActiveGreen = Color(0xFF00C853)
val StatusWarningAmber = Color(0xFFFFB300)
val StatusInactiveGray = Color(0xFF78909C)
val StatusErrorRed = Color(0xFFD32F2F)

