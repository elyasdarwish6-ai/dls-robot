package com.example.lifecycle

import android.util.Log
import com.example.analysis.ImageAnalysisManager
import com.example.connectivity.ConnectivityModeManager
import com.example.gamestate.DlsGameStateAnalyzer
import com.example.vision.DlsVisionAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Stage 10: Match Lifecycle Manager
 *
 * Requirements:
 * 1. Detect current match lifecycle state:
 *    - WAITING
 *    - MATCH_STARTING
 *    - PLAYING
 *    - MATCH_PAUSED
 *    - MATCH_FINISHED
 *    - MATCH_RESULT
 *    - RETURNING_TO_MENU
 *    - READY_FOR_NEXT_MATCH
 * 2. Multi-signal detection across consecutive frames:
 *    - Grass pitch segmentation & field coverage
 *    - Ball presence & tracking confidence
 *    - Player count & cluster distributions
 *    - Game state phase (In-play, Replay/Stopped, Menu/UI, Loading/Cutscene)
 *    - Match duration & phase stability
 * 3. Match pause & interruption detection
 * 4. Safe post-match sequencing:
 *    MATCH_FINISHED -> MATCH_RESULT -> RETURNING_TO_MENU -> READY_FOR_NEXT_MATCH
 * 5. Does NOT auto-start another match yet (prepares READY_FOR_NEXT_MATCH only)
 * 6. Stage 8 Mode Integration (CAREER when online, EXHIBITION when offline)
 * 7. Stage 9 Orchestrator Integration (gates touch actions to PLAYING state only)
 * 8. Emergency stop immediate override across all lifecycle states.
 */
class MatchLifecycleManager private constructor(
    private val visionAnalyzer: DlsVisionAnalyzer = DlsVisionAnalyzer.instance,
    private val gameStateAnalyzer: DlsGameStateAnalyzer = DlsGameStateAnalyzer.instance,
    private val connectivityManager: ConnectivityModeManager = ConnectivityModeManager.instance
) {

    companion object {
        private const val TAG = "MatchLifecycleManager"
        val instance: MatchLifecycleManager by lazy { MatchLifecycleManager() }
    }

    enum class LifecycleState(val label: String, val colorHex: Long, val isGameplayActive: Boolean) {
        WAITING("WAITING", 0xFF9E9E9E, false),
        MATCH_STARTING("MATCH STARTING", 0xFF00B0FF, false),
        PLAYING("PLAYING", 0xFF00E676, true),
        MATCH_PAUSED("MATCH PAUSED", 0xFFFFD600, false),
        MATCH_FINISHED("MATCH FINISHED", 0xFFFF9100, false),
        MATCH_RESULT("MATCH RESULT", 0xFFAB47BC, false),
        RETURNING_TO_MENU("RETURNING TO MENU", 0xFF26C6DA, false),
        READY_FOR_NEXT_MATCH("READY FOR NEXT MATCH", 0xFF76FF03, false),
        EMERGENCY_STOPPED("EMERGENCY STOPPED", 0xFFFF1744, false)
    }

    data class LifecycleTelemetry(
        val lifecycleState: LifecycleState = LifecycleState.WAITING,
        val currentMode: ConnectivityModeManager.GameMode = ConnectivityModeManager.GameMode.EXHIBITION,
        val isMatchDetected: Boolean = false,
        val isMatchStarted: Boolean = false,
        val isMatchFinished: Boolean = false,
        val isResultScreenDetected: Boolean = false,
        val isReadyForNextMatch: Boolean = false,
        val detectionConfidence: Float = 0f,
        val lifecycleLatencyMs: Long = 0L,
        val stateDurationSeconds: Long = 0L,
        val stateTransitionTimestampMs: Long = 0L,
        val consecutivePlayingFrames: Int = 0,
        val consecutivePausedFrames: Int = 0,
        val consecutiveMenuFrames: Int = 0,
        val consecutiveFinishedFrames: Int = 0,
        val statusMessage: String = "Lifecycle initialized. Waiting for match.",
        val matchElapsedSeconds: Long = 0L
    )

    private val lifecycleScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _lifecycleTelemetry = MutableStateFlow(LifecycleTelemetry())
    val lifecycleTelemetry: StateFlow<LifecycleTelemetry> = _lifecycleTelemetry.asStateFlow()

    // Multi-frame confirmation thresholds
    private val requiredPlayingFramesToStart = 3
    private val requiredPausedFramesToPause = 4
    private val requiredMenuFramesToResult = 4
    private val requiredMenuFramesToReady = 4

    private var playingFrameCounter = 0
    private var pausedFrameCounter = 0
    private var menuFrameCounter = 0
    private var transitionFrameCounter = 0

    private var matchStartTimeMs: Long = 0L
    private var stateStartTimeMs: Long = System.currentTimeMillis()
    private var isEmergencyStopActive = false

    init {
        // 1. Observe Stage 8 Connectivity Mode transitions
        lifecycleScope.launch {
            connectivityManager.connectivityState.collectLatest { connState ->
                _lifecycleTelemetry.update {
                    it.copy(currentMode = connState.selectedMode)
                }
            }
        }

        // 2. Continuous Multi-Signal Evaluation from Vision & Game State
        lifecycleScope.launch {
            gameStateAnalyzer.gameState.collectLatest { gameState ->
                if (!isEmergencyStopActive) {
                    processGameStateFrame(gameState)
                }
            }
        }
    }

    /**
     * Multi-Signal Frame Processing Engine for robust state machine transitions.
     */
    private fun processGameStateFrame(gameState: DlsGameStateAnalyzer.GameState) {
        val startTime = System.currentTimeMillis()
        val now = System.currentTimeMillis()

        val visionResult = visionAnalyzer.detectionResult.value
        val activeMode = connectivityManager.connectivityState.value.selectedMode

        val isPitchPresent = visionResult.isFieldDetected && (visionResult.fieldRegion?.grassCoveragePercent ?: 0f) >= 18f
        val grassCoverage = visionResult.fieldRegion?.grassCoveragePercent ?: 0f
        val playerCount = visionResult.players.size
        val hasBall = gameState.ball?.isTracked == true
        val gamePhase = gameState.phase
        val currentLifecycle = _lifecycleTelemetry.value.lifecycleState

        // Multi-signal in-play indicator score (0.0 to 1.0)
        var signalScore = 0f
        if (isPitchPresent) signalScore += 0.40f
        if (playerCount >= 2) signalScore += 0.30f
        if (hasBall) signalScore += 0.15f
        if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY) signalScore += 0.15f

        val calculatedConfidence = signalScore.coerceIn(0f, 1f)

        var nextLifecycle = currentLifecycle
        var statusMsg = _lifecycleTelemetry.value.statusMessage

        when (currentLifecycle) {
            LifecycleState.WAITING,
            LifecycleState.READY_FOR_NEXT_MATCH -> {
                if (gamePhase == DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION) {
                    transitionFrameCounter++
                    if (transitionFrameCounter >= 2) {
                        nextLifecycle = LifecycleState.MATCH_STARTING
                        statusMsg = "Match starting detected ($activeMode Mode)"
                        transitionFrameCounter = 0
                    }
                } else if (signalScore >= 0.70f) {
                    playingFrameCounter++
                    if (playingFrameCounter >= requiredPlayingFramesToStart) {
                        nextLifecycle = LifecycleState.PLAYING
                        matchStartTimeMs = now
                        statusMsg = "Match active and confirmed ($activeMode Mode)"
                        playingFrameCounter = 0
                    }
                } else {
                    playingFrameCounter = 0
                    transitionFrameCounter = 0
                }
            }

            LifecycleState.MATCH_STARTING -> {
                if (signalScore >= 0.70f) {
                    playingFrameCounter++
                    if (playingFrameCounter >= requiredPlayingFramesToStart) {
                        nextLifecycle = LifecycleState.PLAYING
                        matchStartTimeMs = now
                        statusMsg = "Kickoff confirmed ($activeMode Mode)"
                        playingFrameCounter = 0
                    }
                } else if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI) {
                    menuFrameCounter++
                    if (menuFrameCounter >= requiredMenuFramesToResult) {
                        nextLifecycle = LifecycleState.WAITING
                        statusMsg = "Returned to menu before kickoff"
                        menuFrameCounter = 0
                    }
                }
            }

            LifecycleState.PLAYING -> {
                if (signalScore >= 0.55f) {
                    // Stable playing frame
                    pausedFrameCounter = 0
                    menuFrameCounter = 0
                } else if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MATCH_STOPPED_OR_REPLAY) {
                    pausedFrameCounter++
                    if (pausedFrameCounter >= requiredPausedFramesToPause) {
                        nextLifecycle = LifecycleState.MATCH_PAUSED
                        statusMsg = "Match play paused or replay active"
                        pausedFrameCounter = 0
                    }
                } else if (gamePhase == DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION) {
                    // Possible full-time cutscene / transition
                    transitionFrameCounter++
                    if (transitionFrameCounter >= 3) {
                        nextLifecycle = LifecycleState.MATCH_FINISHED
                        statusMsg = "Match finished! Processing post-match sequence"
                        transitionFrameCounter = 0
                    }
                } else if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI && grassCoverage < 10f) {
                    menuFrameCounter++
                    if (menuFrameCounter >= requiredMenuFramesToResult) {
                        nextLifecycle = LifecycleState.MATCH_RESULT
                        statusMsg = "Match result screen detected"
                        menuFrameCounter = 0
                    }
                }
            }

            LifecycleState.MATCH_PAUSED -> {
                if (signalScore >= 0.70f) {
                    playingFrameCounter++
                    if (playingFrameCounter >= requiredPlayingFramesToStart) {
                        nextLifecycle = LifecycleState.PLAYING
                        statusMsg = "Match resumed ($activeMode Mode)"
                        playingFrameCounter = 0
                    }
                } else if (gamePhase == DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION) {
                    transitionFrameCounter++
                    if (transitionFrameCounter >= 3) {
                        nextLifecycle = LifecycleState.MATCH_FINISHED
                        statusMsg = "Match terminated / Final whistle"
                        transitionFrameCounter = 0
                    }
                } else if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI && grassCoverage < 10f) {
                    menuFrameCounter++
                    if (menuFrameCounter >= requiredMenuFramesToResult) {
                        nextLifecycle = LifecycleState.MATCH_RESULT
                        statusMsg = "Match summary / Result screen"
                        menuFrameCounter = 0
                    }
                }
            }

            LifecycleState.MATCH_FINISHED -> {
                // Post-match finished: wait for result screen
                if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI || grassCoverage < 12f) {
                    menuFrameCounter++
                    if (menuFrameCounter >= requiredMenuFramesToResult) {
                        nextLifecycle = LifecycleState.MATCH_RESULT
                        statusMsg = "Match result screen displayed"
                        menuFrameCounter = 0
                    }
                }
            }

            LifecycleState.MATCH_RESULT -> {
                // Wait for result screen to be completed / dismissed
                if (gamePhase == DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION) {
                    transitionFrameCounter++
                    if (transitionFrameCounter >= 2) {
                        nextLifecycle = LifecycleState.RETURNING_TO_MENU
                        statusMsg = "Dismissing result screen, returning to menu"
                        transitionFrameCounter = 0
                    }
                } else if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI) {
                    menuFrameCounter++
                    // After result screen is acknowledged, transitions towards READY_FOR_NEXT_MATCH
                    if (menuFrameCounter >= 6) {
                        nextLifecycle = LifecycleState.READY_FOR_NEXT_MATCH
                        statusMsg = "Main menu reached. Ready for next match ($activeMode Mode)"
                        menuFrameCounter = 0
                    }
                }
            }

            LifecycleState.RETURNING_TO_MENU -> {
                if (gamePhase == DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI) {
                    menuFrameCounter++
                    if (menuFrameCounter >= requiredMenuFramesToReady) {
                        nextLifecycle = LifecycleState.READY_FOR_NEXT_MATCH
                        statusMsg = "Hub menu active. READY FOR NEXT MATCH ($activeMode Mode)"
                        menuFrameCounter = 0
                    }
                }
            }

            LifecycleState.EMERGENCY_STOPPED -> {
                // Emergency stop overrides and remains locked until explicitly reset
                return
            }
        }

        // State transition tracking
        if (nextLifecycle != currentLifecycle) {
            stateStartTimeMs = now
            Log.i(TAG, "Lifecycle transition: $currentLifecycle -> $nextLifecycle ($statusMsg)")
        }

        val stateDuration = (now - stateStartTimeMs) / 1000L
        val matchElapsed = if (matchStartTimeMs > 0 && (nextLifecycle == LifecycleState.PLAYING || nextLifecycle == LifecycleState.MATCH_PAUSED)) {
            (now - matchStartTimeMs) / 1000L
        } else {
            0L
        }

        val isMatchDetected = isPitchPresent && playerCount > 0
        val isMatchStarted = nextLifecycle == LifecycleState.PLAYING || nextLifecycle == LifecycleState.MATCH_PAUSED || nextLifecycle == LifecycleState.MATCH_FINISHED
        val isMatchFinished = nextLifecycle == LifecycleState.MATCH_FINISHED || nextLifecycle == LifecycleState.MATCH_RESULT || nextLifecycle == LifecycleState.RETURNING_TO_MENU || nextLifecycle == LifecycleState.READY_FOR_NEXT_MATCH
        val isResultScreenDetected = nextLifecycle == LifecycleState.MATCH_RESULT
        val isReadyForNextMatch = nextLifecycle == LifecycleState.READY_FOR_NEXT_MATCH

        val latency = System.currentTimeMillis() - startTime

        _lifecycleTelemetry.value = LifecycleTelemetry(
            lifecycleState = nextLifecycle,
            currentMode = activeMode,
            isMatchDetected = isMatchDetected,
            isMatchStarted = isMatchStarted,
            isMatchFinished = isMatchFinished,
            isResultScreenDetected = isResultScreenDetected,
            isReadyForNextMatch = isReadyForNextMatch,
            detectionConfidence = calculatedConfidence,
            lifecycleLatencyMs = latency,
            stateDurationSeconds = stateDuration,
            stateTransitionTimestampMs = stateStartTimeMs,
            consecutivePlayingFrames = playingFrameCounter,
            consecutivePausedFrames = pausedFrameCounter,
            consecutiveMenuFrames = menuFrameCounter,
            consecutiveFinishedFrames = transitionFrameCounter,
            statusMessage = statusMsg,
            matchElapsedSeconds = matchElapsed
        )
    }

    /**
     * Emergency Stop: Immediately halts all lifecycle processing and locks into EMERGENCY_STOPPED.
     */
    fun emergencyStop() {
        isEmergencyStopActive = true
        _lifecycleTelemetry.update {
            it.copy(
                lifecycleState = LifecycleState.EMERGENCY_STOPPED,
                statusMessage = "EMERGENCY STOPPED - All match lifecycle processing halted."
            )
        }
        Log.w(TAG, "MatchLifecycleManager: Emergency stop activated.")
    }

    /**
     * Resets the lifecycle state back to WAITING.
     */
    fun resetLifecycle(reason: String = "Lifecycle reset") {
        isEmergencyStopActive = false
        playingFrameCounter = 0
        pausedFrameCounter = 0
        menuFrameCounter = 0
        transitionFrameCounter = 0
        matchStartTimeMs = 0L
        stateStartTimeMs = System.currentTimeMillis()

        val activeMode = connectivityManager.connectivityState.value.selectedMode
        _lifecycleTelemetry.value = LifecycleTelemetry(
            lifecycleState = LifecycleState.WAITING,
            currentMode = activeMode,
            statusMessage = "Reset: $reason"
        )
        Log.i(TAG, "MatchLifecycleManager reset: $reason")
    }

    /**
     * Manual state advance for simulation or testing.
     */
    fun advanceToState(targetState: LifecycleState) {
        stateStartTimeMs = System.currentTimeMillis()
        val activeMode = connectivityManager.connectivityState.value.selectedMode
        _lifecycleTelemetry.update {
            it.copy(
                lifecycleState = targetState,
                currentMode = activeMode,
                isMatchDetected = targetState == LifecycleState.PLAYING || targetState == LifecycleState.MATCH_PAUSED,
                isMatchStarted = targetState == LifecycleState.PLAYING || targetState == LifecycleState.MATCH_FINISHED,
                isMatchFinished = targetState == LifecycleState.MATCH_FINISHED || targetState == LifecycleState.MATCH_RESULT || targetState == LifecycleState.READY_FOR_NEXT_MATCH,
                isResultScreenDetected = targetState == LifecycleState.MATCH_RESULT,
                isReadyForNextMatch = targetState == LifecycleState.READY_FOR_NEXT_MATCH,
                statusMessage = "Manually transitioned to ${targetState.label}"
            )
        }
    }
}
