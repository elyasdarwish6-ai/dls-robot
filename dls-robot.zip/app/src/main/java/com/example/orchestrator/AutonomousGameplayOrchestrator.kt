package com.example.orchestrator

import android.util.Log
import com.example.analysis.ImageAnalysisManager
import com.example.bot.BotController
import com.example.capture.ScreenCaptureManager
import com.example.connectivity.ConnectivityModeManager
import com.example.decision.DlsDecisionEngine
import com.example.execution.ActionExecutor
import com.example.execution.DlsAccessibilityService
import com.example.gamestate.DlsGameStateAnalyzer
import com.example.lifecycle.MatchLifecycleManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Stage 9: Autonomous Gameplay Orchestrator
 *
 * Central gameplay loop connecting:
 * Vision Analysis -> Game State Understanding -> Decision Engine -> Action Execution -> Vision Analysis
 *
 * Features:
 * 1. Continuous closed-loop orchestration while automation is running.
 * 2. Stage 8 Connectivity Mode integration (CAREER when online, EXHIBITION when offline).
 * 3. Pre-execution safety validation:
 *    - Automation enabled
 *    - Emergency stop inactive
 *    - Game state valid (active match phase)
 *    - Decision confidence above safety threshold
 * 4. Safe fallback: Low-confidence or invalid frames skip execution and wait for next frame.
 * 5. Debounce & Cooldown protection against conflicting/duplicate actions.
 * 6. Real-time telemetry: Automation Status, Current Mode, Current Game State, Current Action,
 *    Loop Status, Last Decision, Loop Latency, and Safety Status.
 * 7. Android 14 compatible lifecycle with graceful error handling.
 */
class AutonomousGameplayOrchestrator private constructor(
    private val captureManager: ScreenCaptureManager = ScreenCaptureManager.instance,
    private val analysisManager: ImageAnalysisManager = ImageAnalysisManager.instance,
    private val gameStateAnalyzer: DlsGameStateAnalyzer = DlsGameStateAnalyzer.instance,
    private val decisionEngine: DlsDecisionEngine = DlsDecisionEngine.instance,
    private val actionExecutor: ActionExecutor = ActionExecutor.instance,
    private val botController: BotController = BotController.instance,
    private val connectivityManager: ConnectivityModeManager = ConnectivityModeManager.instance,
    private val matchLifecycleManager: MatchLifecycleManager = MatchLifecycleManager.instance
) {

    companion object {
        private const val TAG = "AutonomousOrchestrator"
        val instance: AutonomousGameplayOrchestrator by lazy { AutonomousGameplayOrchestrator() }
    }

    enum class AutomationStatus(val label: String, val colorHex: Long) {
        IDLE("IDLE", 0xFF9E9E9E),                       // Gray
        RUNNING("AUTOMATION ACTIVE", 0xFF00E676),        // Bright Green
        PAUSED("PAUSED (MENU / CUTSCENE)", 0xFFFFD600), // Amber
        STOPPED("STOPPED", 0xFF9E9E9E),                 // Gray
        ERROR("ERROR", 0xFFFF1744),                     // Red
        EMERGENCY_STOPPED("EMERGENCY STOPPED", 0xFFFF1744) // Bright Red
    }

    enum class SafetyState(val label: String, val isSafe: Boolean, val colorHex: Long) {
        SECURE("SECURE & VALIDATED", true, 0xFF00E676),
        WARNING("CAUTION (LOW CONFIDENCE / DEBOUNCING)", true, 0xFFFFD600),
        BLOCKED("PREREQUISITES NOT MET", false, 0xFFFF1744),
        EMERGENCY_HALTED("EMERGENCY STOP ACTIVE", false, 0xFFFF1744)
    }

    data class OrchestratorConfig(
        val minConfidenceThreshold: Float = 0.40f,
        val actionCooldownMs: Long = 200L,
        val autoPauseOnMenu: Boolean = true
    )

    data class OrchestratorState(
        val automationStatus: AutomationStatus = AutomationStatus.IDLE,
        val currentMode: ConnectivityModeManager.GameMode = ConnectivityModeManager.GameMode.EXHIBITION,
        val currentGameState: DlsGameStateAnalyzer.MatchPhase = DlsGameStateAnalyzer.MatchPhase.UNKNOWN,
        val currentAction: ActionExecutor.ExecutionType = ActionExecutor.ExecutionType.WAIT,
        val loopStatus: BotController.LoopStatus = BotController.LoopStatus.STOPPED,
        val lastDecision: DlsDecisionEngine.ActionType = DlsDecisionEngine.ActionType.WAIT,
        val lastDecisionReason: String = "Idle - Waiting for automation start",
        val lastDecisionConfidence: Float = 0f,
        val loopLatencyMs: Long = 0L,
        val avgLoopLatencyMs: Float = 0f,
        val safetyStatus: SafetyState = SafetyState.SECURE,
        val safetyMessage: String = "All systems nominal",
        val totalCycles: Long = 0L,
        val executedActionsCount: Long = 0L,
        val skippedFramesCount: Long = 0L,
        val lastCycleTimestampMs: Long = 0L,
        val isEmergencyStopActive: Boolean = false,
        val statusMessage: String = "Automation Ready to Start",
        val errorMessage: String? = null
    )

    private val orchestratorScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _orchestratorState = MutableStateFlow(OrchestratorState())
    val orchestratorState: StateFlow<OrchestratorState> = _orchestratorState.asStateFlow()

    private val _config = MutableStateFlow(OrchestratorConfig())
    val config: StateFlow<OrchestratorConfig> = _config.asStateFlow()

    private var smoothedLatency: Float = 0f
    private var lastActionDispatchTime: Long = 0L
    private var lastDispatchedActionType: DlsDecisionEngine.ActionType = DlsDecisionEngine.ActionType.WAIT

    init {
        // 1. Observe Stage 8 Connectivity Mode transitions
        orchestratorScope.launch {
            connectivityManager.connectivityState.collectLatest { connState ->
                _orchestratorState.update {
                    it.copy(currentMode = connState.selectedMode)
                }
            }
        }

        // 2. Observe Screen Capture State for safety
        orchestratorScope.launch {
            captureManager.captureState.collectLatest { capState ->
                if (capState !is ScreenCaptureManager.CaptureState.Capturing) {
                    if (_orchestratorState.value.automationStatus == AutomationStatus.RUNNING) {
                        Log.w(TAG, "Screen capture lost during automation. Stopping gameplay loop.")
                        stopAutomation(
                            reason = "Screen capture terminated. Gameplay automation halted.",
                            isError = true
                        )
                    }
                }
            }
        }

        // 3. Observe Accessibility Service Connection for safety
        orchestratorScope.launch {
            DlsAccessibilityService.isServiceConnected.collectLatest { connected ->
                if (!connected && _orchestratorState.value.automationStatus == AutomationStatus.RUNNING) {
                    Log.w(TAG, "Accessibility service disconnected during automation. Stopping gameplay loop.")
                    stopAutomation(
                        reason = "Accessibility service disconnected. Action execution disabled.",
                        isError = true
                    )
                }
            }
        }

        // 4. Central Closed-Loop Orchestration Pipeline:
        // Vision Analysis -> Game State Understanding -> Decision Engine -> Action Execution -> Telemetry
        orchestratorScope.launch {
            analysisManager.analysisState.collectLatest { analysisState ->
                val isRunning = _orchestratorState.value.automationStatus == AutomationStatus.RUNNING
                if (!isRunning) return@collectLatest

                processOrchestrationCycle(analysisState)
            }
        }

        // 5. Observe BotController loop state for synchronization
        orchestratorScope.launch {
            botController.loopState.collectLatest { loopState ->
                _orchestratorState.update {
                    it.copy(
                        loopStatus = loopState.status,
                        avgLoopLatencyMs = loopState.avgLoopLatencyMs
                    )
                }
            }
        }
    }

    /**
     * Executes one complete orchestration cycle:
     * Validates safety, verifies game state and decision confidence, applies debouncing,
     * updates action execution, and measures end-to-end loop latency.
     */
    private fun processOrchestrationCycle(analysisState: ImageAnalysisManager.AnalysisState) {
        val cycleStart = System.currentTimeMillis()
        val currentEmergency = _orchestratorState.value.isEmergencyStopActive

        // Safety Check 1: Emergency Stop
        if (currentEmergency) {
            _orchestratorState.update {
                it.copy(
                    automationStatus = AutomationStatus.EMERGENCY_STOPPED,
                    safetyStatus = SafetyState.EMERGENCY_HALTED,
                    safetyMessage = "Emergency stop is active. Touch actions blocked."
                )
            }
            return
        }

        // Safety Check 2: Active Connections
        if (!captureManager.isCapturing || !DlsAccessibilityService.isServiceConnected.value) {
            _orchestratorState.update {
                it.copy(
                    safetyStatus = SafetyState.BLOCKED,
                    safetyMessage = "Prerequisites missing (Screen Capture or Accessibility Service offline)"
                )
            }
            return
        }

        val gameState = gameStateAnalyzer.gameState.value
        val decision = decisionEngine.decision.value
        val execState = actionExecutor.executionState.value
        val activeMode = connectivityManager.connectivityState.value.selectedMode

        // Stage 10: Match Lifecycle Gate (Requirement 9: Never execute touches when lifecycle is not PLAYING)
        val lifecycleTelemetry = matchLifecycleManager.lifecycleTelemetry.value
        if (!lifecycleTelemetry.lifecycleState.isGameplayActive) {
            actionExecutor.stopAllActions()
            _orchestratorState.update {
                it.copy(
                    totalCycles = it.totalCycles + 1,
                    skippedFramesCount = it.skippedFramesCount + 1,
                    currentGameState = gameState.phase,
                    currentMode = activeMode,
                    currentAction = ActionExecutor.ExecutionType.WAIT,
                    lastDecision = decision.actionType,
                    lastDecisionReason = "Gated: Match lifecycle state is ${lifecycleTelemetry.lifecycleState.label}",
                    lastDecisionConfidence = decision.confidence,
                    safetyStatus = SafetyState.SECURE,
                    safetyMessage = "Actions gated by Match Lifecycle (${lifecycleTelemetry.lifecycleState.label})",
                    statusMessage = "Lifecycle: ${lifecycleTelemetry.lifecycleState.label} ($activeMode)",
                    lastCycleTimestampMs = System.currentTimeMillis()
                )
            }
            return
        }

        // Handle match phases (Auto-pause on menu / loading)
        val autoPause = _config.value.autoPauseOnMenu
        if (autoPause) {
            when (gameState.phase) {
                DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI -> {
                    _orchestratorState.update {
                        it.copy(
                            automationStatus = AutomationStatus.PAUSED,
                            currentGameState = gameState.phase,
                            currentMode = activeMode,
                            safetyStatus = SafetyState.SECURE,
                            safetyMessage = "Paused: Menu / UI detected in $activeMode mode",
                            statusMessage = "Paused: Navigating $activeMode mode menu"
                        )
                    }
                    return
                }
                DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION -> {
                    _orchestratorState.update {
                        it.copy(
                            automationStatus = AutomationStatus.PAUSED,
                            currentGameState = gameState.phase,
                            currentMode = activeMode,
                            safetyStatus = SafetyState.SECURE,
                            safetyMessage = "Paused: Loading screen or cutscene transition",
                            statusMessage = "Paused: Waiting for match transition"
                        )
                    }
                    return
                }
                DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY,
                DlsGameStateAnalyzer.MatchPhase.MATCH_STOPPED_OR_REPLAY,
                DlsGameStateAnalyzer.MatchPhase.UNKNOWN -> {
                    // In-play match phase
                }
            }
        }

        // Confidence and State Validation:
        // If vision/state data is invalid or confidence is below threshold, do NOT execute risky actions.
        val minConfidence = _config.value.minConfidenceThreshold
        val isConfidenceSufficient = decision.confidence >= minConfidence
        val isActionRisky = decision.actionType != DlsDecisionEngine.ActionType.WAIT

        val now = System.currentTimeMillis()
        val cooldown = _config.value.actionCooldownMs
        val isCooldownSatisfied = (now - lastActionDispatchTime) >= cooldown

        if (!isConfidenceSufficient && isActionRisky) {
            // Confidence too low -> Safe Wait fallback
            _orchestratorState.update {
                it.copy(
                    totalCycles = it.totalCycles + 1,
                    skippedFramesCount = it.skippedFramesCount + 1,
                    currentGameState = gameState.phase,
                    currentMode = activeMode,
                    currentAction = ActionExecutor.ExecutionType.WAIT,
                    lastDecision = decision.actionType,
                    lastDecisionReason = "Skipped: Confidence (${(decision.confidence * 100).toInt()}%) below safe threshold (${(minConfidence * 100).toInt()}%)",
                    lastDecisionConfidence = decision.confidence,
                    safetyStatus = SafetyState.WARNING,
                    safetyMessage = "Low confidence frame skipped for safety (${(decision.confidence * 100).toInt()}%)",
                    lastCycleTimestampMs = now
                )
            }
            return
        }

        // Action Debounce & Cooldown Check
        if (isActionRisky && !isCooldownSatisfied && decision.actionType == lastDispatchedActionType) {
            _orchestratorState.update {
                it.copy(
                    totalCycles = it.totalCycles + 1,
                    skippedFramesCount = it.skippedFramesCount + 1,
                    currentGameState = gameState.phase,
                    currentMode = activeMode,
                    currentAction = execState.lastCommand.type,
                    lastDecision = decision.actionType,
                    lastDecisionReason = "Debounced: Action ${decision.actionType.label} in cooldown (${now - lastActionDispatchTime}ms < ${cooldown}ms)",
                    lastDecisionConfidence = decision.confidence,
                    safetyStatus = SafetyState.WARNING,
                    safetyMessage = "Action debounced to prevent input conflict",
                    lastCycleTimestampMs = now
                )
            }
            return
        }

        // Validated & Safe -> Track execution
        if (isActionRisky) {
            lastActionDispatchTime = now
            lastDispatchedActionType = decision.actionType
        }

        val cycleDuration = (now - cycleStart) + analysisState.lastProcessingTimeMs + gameState.stateProcessingDurationMs + decision.decisionLatencyMs

        if (cycleDuration > 0) {
            smoothedLatency = if (smoothedLatency == 0f) {
                cycleDuration.toFloat()
            } else {
                smoothedLatency * 0.85f + cycleDuration * 0.15f
            }
        }

        _orchestratorState.update {
            it.copy(
                automationStatus = AutomationStatus.RUNNING,
                currentMode = activeMode,
                currentGameState = gameState.phase,
                currentAction = execState.lastCommand.type,
                lastDecision = decision.actionType,
                lastDecisionReason = decision.reason,
                lastDecisionConfidence = decision.confidence,
                loopLatencyMs = cycleDuration,
                avgLoopLatencyMs = smoothedLatency,
                safetyStatus = SafetyState.SECURE,
                safetyMessage = "Nominal ($activeMode Mode - ${gameState.phase.label})",
                totalCycles = it.totalCycles + 1,
                executedActionsCount = execState.totalExecutedCount,
                lastCycleTimestampMs = now,
                statusMessage = "Autonomous orchestrator running in $activeMode mode"
            )
        }
    }

    /**
     * Starts autonomous gameplay orchestration after validating all prerequisites.
     */
    fun startAutomation(): Result<Unit> {
        // Reset emergency flag upon explicit start
        _orchestratorState.update { it.copy(isEmergencyStopActive = false) }

        // Prerequisite 1: Screen Capture
        if (!captureManager.isCapturing) {
            val err = "Cannot start Automation: Screen Capture is not active. Please start Screen Capture first."
            Log.w(TAG, err)
            _orchestratorState.update {
                it.copy(
                    automationStatus = AutomationStatus.ERROR,
                    safetyStatus = SafetyState.BLOCKED,
                    safetyMessage = err,
                    errorMessage = err,
                    statusMessage = err
                )
            }
            return Result.failure(IllegalStateException(err))
        }

        // Prerequisite 2: Accessibility Service
        if (!DlsAccessibilityService.isServiceConnected.value) {
            val err = "Cannot start Automation: Accessibility Service is offline. Enable 'DLS Robot Action Service' in Settings."
            Log.w(TAG, err)
            _orchestratorState.update {
                it.copy(
                    automationStatus = AutomationStatus.ERROR,
                    safetyStatus = SafetyState.BLOCKED,
                    safetyMessage = err,
                    errorMessage = err,
                    statusMessage = err
                )
            }
            return Result.failure(IllegalStateException(err))
        }

        // Start underlying bot controller loop and execution engine
        val botResult = botController.startBot()
        if (botResult.isFailure) {
            val err = botResult.exceptionOrNull()?.message ?: "Failed to start control loop"
            _orchestratorState.update {
                it.copy(
                    automationStatus = AutomationStatus.ERROR,
                    safetyStatus = SafetyState.BLOCKED,
                    safetyMessage = err,
                    errorMessage = err,
                    statusMessage = err
                )
            }
            return botResult
        }

        val activeMode = connectivityManager.connectivityState.value.selectedMode
        _orchestratorState.update {
            it.copy(
                automationStatus = AutomationStatus.RUNNING,
                currentMode = activeMode,
                loopStatus = BotController.LoopStatus.RUNNING,
                safetyStatus = SafetyState.SECURE,
                safetyMessage = "Automation running safely ($activeMode Mode)",
                statusMessage = "Autonomous gameplay loop active in $activeMode mode",
                errorMessage = null
            )
        }

        Log.i(TAG, "Autonomous Gameplay Orchestrator STARTED ($activeMode Mode).")
        return Result.success(Unit)
    }

    /**
     * Stops autonomous gameplay orchestration safely.
     */
    fun stopAutomation(reason: String = "Automation stopped by user", isError: Boolean = false) {
        botController.stopBot(reason)
        actionExecutor.stopAllActions()

        _orchestratorState.update {
            it.copy(
                automationStatus = if (isError) AutomationStatus.ERROR else AutomationStatus.STOPPED,
                loopStatus = if (isError) BotController.LoopStatus.ERROR else BotController.LoopStatus.STOPPED,
                safetyStatus = if (isError) SafetyState.BLOCKED else SafetyState.SECURE,
                safetyMessage = reason,
                statusMessage = reason,
                errorMessage = if (isError) reason else null,
                currentAction = ActionExecutor.ExecutionType.WAIT
            )
        }
        Log.i(TAG, "Autonomous Gameplay Orchestrator STOPPED: $reason")
    }

    /**
     * Emergency Stop: Immediately halts all orchestration and dispatches zero touches.
     */
    fun emergencyStop() {
        _orchestratorState.update {
            it.copy(
                isEmergencyStopActive = true,
                automationStatus = AutomationStatus.EMERGENCY_STOPPED,
                loopStatus = BotController.LoopStatus.STOPPED,
                safetyStatus = SafetyState.EMERGENCY_HALTED,
                safetyMessage = "EMERGENCY STOP TRIGGERED - All inputs and loop cancelled.",
                statusMessage = "EMERGENCY STOP ACTIVE - Touch actions halted.",
                currentAction = ActionExecutor.ExecutionType.WAIT
            )
        }
        botController.emergencyStop()
        actionExecutor.stopAllActions()
        matchLifecycleManager.emergencyStop()
        Log.w(TAG, "Autonomous Gameplay Orchestrator: EMERGENCY STOP TRIGGERED.")
    }

    /**
     * Pauses the orchestrator temporarily.
     */
    fun pauseAutomation(reason: String = "Automation paused by user") {
        botController.pauseBot(reason)
        _orchestratorState.update {
            it.copy(
                automationStatus = AutomationStatus.PAUSED,
                loopStatus = BotController.LoopStatus.PAUSED,
                statusMessage = reason,
                safetyMessage = reason
            )
        }
        Log.i(TAG, "Autonomous Gameplay Orchestrator PAUSED: $reason")
    }

    /**
     * Resumes the orchestrator.
     */
    fun resumeAutomation(): Result<Unit> {
        return startAutomation()
    }

    fun setMinConfidenceThreshold(threshold: Float) {
        val safe = threshold.coerceIn(0.10f, 0.95f)
        _config.update { it.copy(minConfidenceThreshold = safe) }
    }

    fun setActionCooldownMs(cooldownMs: Long) {
        val safe = cooldownMs.coerceIn(50L, 1000L)
        _config.update { it.copy(actionCooldownMs = safe) }
    }

    fun setAutoPauseOnMenu(enabled: Boolean) {
        _config.update { it.copy(autoPauseOnMenu = enabled) }
        botController.setAutoPauseOnMenu(enabled)
    }
}
