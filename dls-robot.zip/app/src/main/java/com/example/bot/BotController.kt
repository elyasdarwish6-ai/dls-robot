package com.example.bot

import android.util.Log
import com.example.analysis.ImageAnalysisManager
import com.example.capture.ScreenCaptureManager
import com.example.decision.DlsDecisionEngine
import com.example.execution.ActionExecutor
import com.example.execution.DlsAccessibilityService
import com.example.gamestate.DlsGameStateAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Stage 7: Real-Time Game Control Loop Engine.
 * Connects and orchestrates the full autonomous pipeline:
 * Screen Capture -> Vision Analysis -> Game State Understanding -> Decision Engine -> Action Execution.
 *
 * Provides real-time loop synchronization, safety monitoring, automatic pause/stopping,
 * conflict prevention, and live performance metrics without mock/random data.
 */
class BotController(
    private val captureManager: ScreenCaptureManager = ScreenCaptureManager.instance,
    private val analysisManager: ImageAnalysisManager = ImageAnalysisManager.instance,
    private val gameStateAnalyzer: DlsGameStateAnalyzer = DlsGameStateAnalyzer.instance,
    private val decisionEngine: DlsDecisionEngine = DlsDecisionEngine.instance,
    private val actionExecutor: ActionExecutor = ActionExecutor.instance
) {

    companion object {
        private const val TAG = "BotController"
        val instance: BotController by lazy { BotController() }
    }

    enum class LoopStatus(val label: String, val colorHex: Long) {
        STOPPED("STOPPED", 0xFF9E9E9E),   // Gray
        RUNNING("RUNNING", 0xFF00E676),   // Vibrant Green
        PAUSED("PAUSED", 0xFFFFD600),     // Amber / Yellow
        ERROR("ERROR", 0xFFFF1744)        // Red
    }

    sealed class BotState(val label: String) {
        object Stopped : BotState("Stopped")
        object Running : BotState("Running")
        data class Paused(val reason: String) : BotState("Paused")
        data class Error(val message: String) : BotState("Error")
    }

    data class ControlLoopConfig(
        val loopIntervalMs: Long = ImageAnalysisManager.DEFAULT_INTERVAL_MS,
        val autoPauseOnMenu: Boolean = true,
        val isConflictPreventionEnabled: Boolean = true
    )

    data class ControlLoopState(
        val status: LoopStatus = LoopStatus.STOPPED,
        val framesProcessed: Long = 0L,
        val decisionsGenerated: Long = 0L,
        val actionsExecuted: Long = 0L,
        val failedActions: Long = 0L,
        val avgLoopLatencyMs: Float = 0f,
        val lastLoopTimestampMs: Long = 0L,
        val lastCycleDurationMs: Long = 0L,
        val statusMessage: String = "Bot Stopped - Waiting to start",
        val errorMessage: String? = null,
        val currentPhase: DlsGameStateAnalyzer.MatchPhase = DlsGameStateAnalyzer.MatchPhase.UNKNOWN,
        val lastActionType: ActionExecutor.ExecutionType = ActionExecutor.ExecutionType.WAIT,
        val loopIntervalMs: Long = ImageAnalysisManager.DEFAULT_INTERVAL_MS
    )

    private val loopScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _loopState = MutableStateFlow(ControlLoopState())
    val loopState: StateFlow<ControlLoopState> = _loopState.asStateFlow()

    private val _botState = MutableStateFlow<BotState>(BotState.Stopped)
    val botState: StateFlow<BotState> = _botState.asStateFlow()

    private val _config = MutableStateFlow(ControlLoopConfig())
    val config: StateFlow<ControlLoopConfig> = _config.asStateFlow()

    private var previousDecisionTimestamp: Long = 0L
    private var smoothedLatency: Float = 0f

    init {
        // 1. Safety Monitor: Observe ScreenCapture state
        loopScope.launch {
            captureManager.captureState.collectLatest { captureState ->
                try {
                    if (captureState !is ScreenCaptureManager.CaptureState.Capturing) {
                        if (_loopState.value.status == LoopStatus.RUNNING) {
                            Log.w(TAG, "Screen Capture stopped while bot was running. Halting control loop.")
                            stopLoopInternal(
                                reason = "Screen Capture stopped. Control loop halted.",
                                isError = false
                            )
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in capture state observer", e)
                }
            }
        }

        // 2. Safety Monitor: Observe Accessibility Service state
        loopScope.launch {
            DlsAccessibilityService.isServiceConnected.collectLatest { isConnected ->
                try {
                    if (!isConnected && _loopState.value.status == LoopStatus.RUNNING) {
                        Log.w(TAG, "Accessibility Service disconnected while bot was running. Aborting control loop.")
                        stopLoopInternal(
                            reason = "Accessibility Service disconnected. Action execution disabled.",
                            isError = true
                        )
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in accessibility service observer", e)
                }
            }
        }

        // 3. Pipeline Monitor: Observe GameState & Auto-Pause on Menu/Loading
        loopScope.launch {
            gameStateAnalyzer.gameState.collectLatest { gameState ->
                try {
                    val currentStatus = _loopState.value.status
                    val autoPause = _config.value.autoPauseOnMenu

                    if (currentStatus == LoopStatus.RUNNING && autoPause) {
                        when (gameState.phase) {
                            DlsGameStateAnalyzer.MatchPhase.MENU_OR_UI -> {
                                _loopState.update {
                                    it.copy(
                                        status = LoopStatus.PAUSED,
                                        currentPhase = gameState.phase,
                                        statusMessage = "Paused: Menu / UI detected"
                                    )
                                }
                                _botState.value = BotState.Paused("Menu / UI Screen detected")
                                actionExecutor.setBotRunning(false)
                            }
                            DlsGameStateAnalyzer.MatchPhase.LOADING_OR_TRANSITION -> {
                                _loopState.update {
                                    it.copy(
                                        status = LoopStatus.PAUSED,
                                        currentPhase = gameState.phase,
                                        statusMessage = "Paused: Loading / Cutscene detected"
                                    )
                                }
                                _botState.value = BotState.Paused("Loading / Cutscene detected")
                                actionExecutor.setBotRunning(false)
                            }
                            DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY,
                            DlsGameStateAnalyzer.MatchPhase.MATCH_STOPPED_OR_REPLAY,
                            DlsGameStateAnalyzer.MatchPhase.UNKNOWN -> {
                                // In play
                                _loopState.update {
                                    it.copy(currentPhase = gameState.phase)
                                }
                            }
                        }
                    } else if (currentStatus == LoopStatus.PAUSED && autoPause) {
                        // Check if gameplay resumed
                        if (gameState.phase == DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY ||
                            gameState.phase == DlsGameStateAnalyzer.MatchPhase.MATCH_STOPPED_OR_REPLAY
                        ) {
                            Log.i(TAG, "Match gameplay resumed. Resuming control loop.")
                            _loopState.update {
                                it.copy(
                                    status = LoopStatus.RUNNING,
                                    currentPhase = gameState.phase,
                                    statusMessage = "Real-time control loop running (Gameplay Resumed)"
                                )
                            }
                            _botState.value = BotState.Running
                            actionExecutor.setBotRunning(true)
                        } else {
                            _loopState.update {
                                it.copy(currentPhase = gameState.phase)
                            }
                        }
                    } else {
                        _loopState.update {
                            it.copy(currentPhase = gameState.phase)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in game state observer", e)
                }
            }
        }

        // 4. Telemetry Collector: Live Decision & Action Execution synchronization
        loopScope.launch {
            decisionEngine.decision.collectLatest { decision ->
                try {
                    if (decision.timestampMs > 0 && decision.timestampMs != previousDecisionTimestamp) {
                        previousDecisionTimestamp = decision.timestampMs
                        _loopState.update {
                            it.copy(
                                decisionsGenerated = it.decisionsGenerated + 1,
                                lastLoopTimestampMs = decision.timestampMs
                            )
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error tracking decision telemetry", e)
                }
            }
        }

        // 5. Telemetry Collector: Frames and Latency synchronization from ImageAnalysis
        loopScope.launch {
            analysisManager.analysisState.collectLatest { analysis ->
                try {
                    val gs = gameStateAnalyzer.gameState.value
                    val dec = decisionEngine.decision.value
                    val exec = actionExecutor.executionState.value

                    val cycleDuration = analysis.lastProcessingTimeMs + gs.stateProcessingDurationMs + dec.decisionLatencyMs + exec.latencyMs

                    if (cycleDuration > 0) {
                        smoothedLatency = if (smoothedLatency == 0f) {
                            cycleDuration.toFloat()
                        } else {
                            smoothedLatency * 0.85f + cycleDuration * 0.15f
                        }
                    }

                    _loopState.update {
                        it.copy(
                            framesProcessed = analysis.analyzedCount,
                            actionsExecuted = exec.totalExecutedCount,
                            failedActions = exec.failedCount,
                            lastActionType = exec.lastCommand.type,
                            lastCycleDurationMs = cycleDuration,
                            avgLoopLatencyMs = smoothedLatency
                        )
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error tracking frame analysis telemetry", e)
                }
            }
        }
    }

    val isRunning: Boolean
        get() = _loopState.value.status == LoopStatus.RUNNING

    /**
     * Starts the Real-Time Game Control Loop after validating all required prerequisites.
     * Throws or returns Failure if Screen Capture or Accessibility Service is missing.
     */
    fun startBot(): Result<Unit> {
        // Prerequisite Check 1: Screen Capture
        if (!captureManager.isCapturing) {
            val errorMsg = "Cannot start Bot: Screen Capture is NOT active. Please tap 'Start Screen Capture' first."
            Log.w(TAG, errorMsg)
            _loopState.update {
                it.copy(
                    status = LoopStatus.ERROR,
                    statusMessage = errorMsg,
                    errorMessage = errorMsg
                )
            }
            _botState.value = BotState.Error(errorMsg)
            return Result.failure(IllegalStateException(errorMsg))
        }

        // Prerequisite Check 2: Accessibility Service
        if (!DlsAccessibilityService.isServiceConnected.value) {
            val errorMsg = "Cannot start Bot: Accessibility Service is NOT enabled. Please enable 'DLS Robot Action Service' in Android Settings."
            Log.w(TAG, errorMsg)
            _loopState.update {
                it.copy(
                    status = LoopStatus.ERROR,
                    statusMessage = errorMsg,
                    errorMessage = errorMsg
                )
            }
            _botState.value = BotState.Error(errorMsg)
            return Result.failure(IllegalStateException(errorMsg))
        }

        // Prerequisites passed -> Start Control Loop
        val interval = _config.value.loopIntervalMs
        analysisManager.setIntervalMs(interval)
        actionExecutor.setBotRunning(true)

        _loopState.update {
            it.copy(
                status = LoopStatus.RUNNING,
                statusMessage = "Real-time control loop running (@${interval}ms interval)",
                errorMessage = null,
                loopIntervalMs = interval
            )
        }
        _botState.value = BotState.Running
        Log.i(TAG, "Real-Time Game Control Loop STARTED successfully.")
        return Result.success(Unit)
    }

    /**
     * Stops the Real-Time Game Control Loop and cancels all ongoing touches.
     */
    fun stopBot(reason: String = "Bot stopped by user"): Boolean {
        stopLoopInternal(reason, isError = false)
        Log.i(TAG, "Real-Time Game Control Loop STOPPED: $reason")
        return true
    }

    /**
     * Immediate Emergency Stop: instantly cancels all gestures and halts the control loop.
     */
    fun emergencyStop() {
        actionExecutor.stopAllActions()
        actionExecutor.setBotRunning(false)
        val msg = "EMERGENCY STOP TRIGGERED - Control loop & all gestures cancelled immediately."
        _loopState.update {
            it.copy(
                status = LoopStatus.STOPPED,
                statusMessage = msg,
                errorMessage = null
            )
        }
        _botState.value = BotState.Stopped
        Log.w(TAG, msg)
    }

    /**
     * Pauses the loop temporarily (e.g. while in menus or upon user request).
     */
    fun pauseBot(reason: String = "Bot paused by user") {
        actionExecutor.stopAllActions()
        actionExecutor.setBotRunning(false)
        _loopState.update {
            it.copy(
                status = LoopStatus.PAUSED,
                statusMessage = reason
            )
        }
        _botState.value = BotState.Paused(reason)
        Log.i(TAG, "Real-Time Game Control Loop PAUSED: $reason")
    }

    /**
     * Resumes the loop from paused state.
     */
    fun resumeBot(): Result<Unit> {
        return startBot()
    }

    /**
     * Configures the control-loop execution interval (milliseconds).
     */
    fun setLoopIntervalMs(intervalMs: Long) {
        val safeInterval = intervalMs.coerceIn(16L, 1000L)
        _config.update { it.copy(loopIntervalMs = safeInterval) }
        analysisManager.setIntervalMs(safeInterval)
        _loopState.update { it.copy(loopIntervalMs = safeInterval) }
    }

    /**
     * Toggles automatic pause when menu or loading screens are detected.
     */
    fun setAutoPauseOnMenu(enabled: Boolean) {
        _config.update { it.copy(autoPauseOnMenu = enabled) }
    }

    private fun stopLoopInternal(reason: String, isError: Boolean) {
        actionExecutor.stopAllActions()
        actionExecutor.setBotRunning(false)

        _loopState.update {
            it.copy(
                status = if (isError) LoopStatus.ERROR else LoopStatus.STOPPED,
                statusMessage = reason,
                errorMessage = if (isError) reason else null
            )
        }
        _botState.value = if (isError) BotState.Error(reason) else BotState.Stopped
    }
}
