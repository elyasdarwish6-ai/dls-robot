package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.DlsRobotScreen
import com.example.ui.MainUiState
import com.example.ui.MainViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                // Register MediaProjection ActivityResult launcher
                val captureLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    val metrics = getScreenMetrics(context)
                    viewModel.handleCapturePermissionResult(
                        context = context,
                        resultCode = result.resultCode,
                        data = result.data,
                        width = metrics.widthPixels,
                        height = metrics.heightPixels,
                        densityDpi = metrics.densityDpi
                    )
                }

                // Notification permission launcher for Android 13+
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) {
                    // Proceed with screen capture intent
                    val mediaProjectionManager =
                        getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    captureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
                }

                LaunchedEffect(Unit) {
                    viewModel.refreshDlsStatus(context)
                    viewModel.initializeConnectivity(context)
                }

                DlsRobotScreen(
                    uiState = uiState,
                    onLaunchDls = { viewModel.launchDls(context) },
                    onStartScreenCapture = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            val mediaProjectionManager =
                                getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            captureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
                        }
                    },
                    onStopScreenCapture = { viewModel.stopScreenCapture(context) },
                    onStartBot = { viewModel.startBot() },
                    onStopBot = { viewModel.stopBot() },
                    onPauseBot = { viewModel.pauseBot() },
                    onResumeBot = { viewModel.resumeBot() },
                    onToggleAutoPause = { viewModel.toggleAutoPauseOnMenu() },
                    onStartAutomation = { viewModel.startAutomation() },
                    onStopAutomation = { viewModel.stopAutomation() },
                    onPauseAutomation = { viewModel.pauseAutomation() },
                    onResumeAutomation = { viewModel.resumeAutomation() },
                    onSetAutomationMinConfidence = { viewModel.setAutomationMinConfidence(it) },
                    onSetAutomationCooldown = { viewModel.setAutomationCooldownMs(it) },
                    onToggleAutomationAutoPause = { viewModel.toggleAutomationAutoPause() },
                    onRefreshConnectivity = { viewModel.checkConnectivity(context) },
                    onResetLifecycle = { viewModel.resetLifecycle() },
                    onAdvanceLifecycleState = { viewModel.advanceLifecycleState(it) },
                    onStartSafeAutomation = { viewModel.startSafeAutomation() },
                    onStopSafeAutomation = { viewModel.stopSafeAutomation() },
                    onClearEmergencyHalt = { viewModel.resetEmergencyStop() },
                    onRunHealthDiagnostics = { viewModel.runHealthDiagnostics(context) },
                    onSetAnalysisInterval = { viewModel.setAnalysisInterval(it) },
                    onToggleDebugOverlay = { viewModel.toggleDebugOverlay() },
                    onUpdateBallBrightness = { viewModel.updateBallBrightnessMin(it) },
                    onUpdateGrassHue = { minH, maxH -> viewModel.updateGrassHueRange(minH, maxH) },
                    onSetDecisionCooldown = { viewModel.setDecisionCooldownMs(it) },
                    onSetDecisionMinConfidence = { viewModel.setDecisionMinConfidence(it) },
                    onToggleDecisionDebugOverlay = { viewModel.toggleDecisionDebugOverlay() },
                    onOpenAccessibilitySettings = { viewModel.openAccessibilitySettings(context) },
                    onEmergencyStop = { viewModel.emergencyStop() },
                    onToggleExecutionEnabled = { viewModel.toggleExecutionEnabled() },
                    onSetExecutionCooldown = { viewModel.setExecutionCooldownMs(it) },
                    onSetExecutionMinConfidence = { viewModel.setExecutionMinConfidence(it) },
                    onTestTap = { x, y -> viewModel.testTap(x, y) },
                    onTestSwipe = { sx, sy, ex, ey -> viewModel.testSwipe(sx, sy, ex, ey) },
                    onTestMove = { sx, sy, ex, ey -> viewModel.testMove(sx, sy, ex, ey) },
                    onDismissMessage = { viewModel.dismissUserMessage() },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDlsStatus(this)
    }

    private fun getScreenMetrics(context: Context): DisplayMetrics {
        val metrics = DisplayMetrics()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.currentWindowMetrics
            val bounds = windowMetrics.bounds
            metrics.widthPixels = bounds.width()
            metrics.heightPixels = bounds.height()
            metrics.densityDpi = resources.configuration.densityDpi
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
        }
        return metrics
    }
}

@Preview(showBackground = true)
@Composable
fun MainActivityPreview() {
    MyApplicationTheme {
        DlsRobotScreen(
            uiState = MainUiState(
                dlsStatusDescription = "Not Installed",
                isDlsInstalled = false
            ),
            onLaunchDls = {},
            onStartScreenCapture = {},
            onStopScreenCapture = {},
            onStartBot = {},
            onStopBot = {},
            onDismissMessage = {}
        )
    }
}
