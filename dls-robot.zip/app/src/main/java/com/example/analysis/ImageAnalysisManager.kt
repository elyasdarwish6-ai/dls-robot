package com.example.analysis

import android.graphics.Bitmap
import android.media.Image
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Stage 2: Core Image Analysis Foundation.
 * Manages frame ingestion from MediaProjection, conversion to Android Bitmaps,
 * and a decoupled, throttled analysis loop ready for computer-vision algorithms.
 */
class ImageAnalysisManager private constructor() {

    companion object {
        private const val TAG = "ImageAnalysisManager"
        const val DEFAULT_INTERVAL_MS = 100L // 10 FPS analysis loop

        val instance: ImageAnalysisManager by lazy { ImageAnalysisManager() }
    }

    data class AnalysisState(
        val isCaptureActive: Boolean = false,
        val isAnalyzing: Boolean = false,
        val frameCount: Long = 0L,
        val analyzedCount: Long = 0L,
        val frameWidth: Int = 0,
        val frameHeight: Int = 0,
        val intervalMs: Long = DEFAULT_INTERVAL_MS,
        val lastProcessingTimeMs: Long = 0L,
        val statusMessage: String = "Idle",
        val latestBitmap: Bitmap? = null
    )

    private val _analysisState = MutableStateFlow(AnalysisState())
    val analysisState: StateFlow<AnalysisState> = _analysisState.asStateFlow()

    private var analysisIntervalMs: Long = DEFAULT_INTERVAL_MS
    private var lastAnalyzedTimestampMs: Long = 0L
    private var totalFramesReceived: Long = 0L
    private var totalFramesAnalyzed: Long = 0L

    private val isProcessingFrame = AtomicBoolean(false)
    private var analysisScope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    /**
     * Interface for pluggable computer-vision analyzers in Stage 3+.
     */
    fun interface FrameAnalyzer {
        fun analyze(bitmap: Bitmap, timestampMs: Long)
    }

    private var customAnalyzer: FrameAnalyzer? = null

    /**
     * Set a custom analyzer for computer vision processing.
     */
    fun setAnalyzer(analyzer: FrameAnalyzer?) {
        this.customAnalyzer = analyzer
    }

    /**
     * Updates the target interval between analyzed frames in milliseconds.
     */
    fun setIntervalMs(intervalMs: Long) {
        this.analysisIntervalMs = intervalMs.coerceAtLeast(16L)
        _analysisState.value = _analysisState.value.copy(
            intervalMs = this.analysisIntervalMs
        )
    }

    /**
     * Called when screen capture starts.
     */
    fun onCaptureStarted(width: Int, height: Int) {
        totalFramesReceived = 0L
        totalFramesAnalyzed = 0L
        lastAnalyzedTimestampMs = 0L

        _analysisState.value = AnalysisState(
            isCaptureActive = true,
            isAnalyzing = true,
            frameCount = 0L,
            analyzedCount = 0L,
            frameWidth = width,
            frameHeight = height,
            intervalMs = analysisIntervalMs,
            statusMessage = "Analyzing @ ${analysisIntervalMs}ms interval",
            latestBitmap = null
        )
        Log.i(TAG, "Analysis session started for ${width}x${height}")
    }

    /**
     * Called by ScreenCaptureManager when a raw ImageReader frame is available.
     * Extracts and converts the frame according to the configured interval.
     */
    fun onImageAvailable(image: Image) {
        totalFramesReceived++
        val now = System.currentTimeMillis()

        // Check if capture is active and interval has passed
        val shouldAnalyze = (now - lastAnalyzedTimestampMs >= analysisIntervalMs)

        if (!shouldAnalyze || !_analysisState.value.isCaptureActive) {
            // Keep total frame counter in sync
            _analysisState.value = _analysisState.value.copy(
                frameCount = totalFramesReceived
            )
            return
        }

        // Prevent overlapping frame processing
        if (!isProcessingFrame.compareAndSet(false, true)) {
            return
        }

        val startTime = System.currentTimeMillis()
        var convertedBitmap: Bitmap? = null

        try {
            convertedBitmap = convertImageToBitmap(image)
            lastAnalyzedTimestampMs = now
            totalFramesAnalyzed++

            if (convertedBitmap != null) {
                // Pass to custom analyzer if registered (e.g. for Stage 3 CV pipeline)
                customAnalyzer?.analyze(convertedBitmap, now)

                val processingDuration = System.currentTimeMillis() - startTime

                // Safely update state with new preview Bitmap
                val previousBitmap = _analysisState.value.latestBitmap
                _analysisState.value = _analysisState.value.copy(
                    frameCount = totalFramesReceived,
                    analyzedCount = totalFramesAnalyzed,
                    frameWidth = convertedBitmap.width,
                    frameHeight = convertedBitmap.height,
                    lastProcessingTimeMs = processingDuration,
                    statusMessage = "Analyzing (${processingDuration}ms / frame)",
                    latestBitmap = convertedBitmap
                )

                // Recycle previous preview bitmap if different to avoid memory leaks
                if (previousBitmap != null && previousBitmap != convertedBitmap && !previousBitmap.isRecycled) {
                    previousBitmap.recycle()
                }
            } else {
                _analysisState.value = _analysisState.value.copy(
                    frameCount = totalFramesReceived
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing frame in analysis loop", e)
            convertedBitmap?.let {
                if (!it.isRecycled) it.recycle()
            }
        } finally {
            isProcessingFrame.set(false)
        }
    }

    /**
     * Converts an android.media.Image in RGBA_8888 format to an Android Bitmap.
     * Correctly handles rowStride, pixelStride, and buffer size differences across devices.
     */
    private fun convertImageToBitmap(image: Image): Bitmap? {
        return try {
            val planes = image.planes
            if (planes.isEmpty()) return null

            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val width = image.width
            val height = image.height

            val rowPadding = rowStride - pixelStride * width

            if (rowPadding == 0 && pixelStride == 4) {
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                buffer.rewind()
                bitmap.copyPixelsFromBuffer(buffer)
                bitmap
            } else {
                val paddedWidth = width + rowPadding / pixelStride
                val expectedBufferSize = paddedWidth * height * 4
                buffer.rewind()

                val workingBuffer: ByteBuffer = if (buffer.remaining() >= expectedBufferSize) {
                    buffer
                } else {
                    // When the buffer does not include trailing padding on the last row
                    val paddedBuf = ByteBuffer.allocateDirect(expectedBufferSize)
                    paddedBuf.put(buffer)
                    paddedBuf.rewind()
                    paddedBuf
                }

                val tempBitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
                tempBitmap.copyPixelsFromBuffer(workingBuffer)

                if (paddedWidth != width) {
                    val croppedBitmap = Bitmap.createBitmap(tempBitmap, 0, 0, width, height)
                    if (croppedBitmap != tempBitmap) {
                        tempBitmap.recycle()
                    }
                    croppedBitmap
                } else {
                    tempBitmap
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to convert Image to Bitmap", e)
            null
        }
    }

    /**
     * Called when screen capture stops. Safely releases resources.
     */
    fun onCaptureStopped() {
        val currentBitmap = _analysisState.value.latestBitmap
        _analysisState.value = _analysisState.value.copy(
            isCaptureActive = false,
            isAnalyzing = false,
            statusMessage = "Idle (Stopped)"
        )
        // Keep the last frame in UI preview or release if needed
        Log.i(TAG, "Analysis session stopped")
    }

    /**
     * Fully releases all held bitmaps and scopes.
     */
    fun release() {
        try {
            analysisScope.cancel()
            val bitmap = _analysisState.value.latestBitmap
            if (bitmap != null && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            _analysisState.value = AnalysisState()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing ImageAnalysisManager", e)
        }
    }
}
