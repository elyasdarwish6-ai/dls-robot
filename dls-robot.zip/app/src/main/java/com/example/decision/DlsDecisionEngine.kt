package com.example.decision

import android.util.Log
import com.example.gamestate.DlsGameStateAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Stage 5: Real-time Rule-based Decision Engine for Dream League Soccer.
 * Consumes the local GameState from Stage 4 and generates tactical gameplay decisions
 * (MOVE, PASS, SHOOT, DEFEND, CHASE_BALL, WAIT) with targets, directions, confidence,
 * reasons, and hysteresis cooldowns.
 *
 * NOTE: This stage does NOT execute touch inputs to the screen or claim active play.
 * All calculations execute entirely locally and off the main UI thread.
 */
class DlsDecisionEngine private constructor(
    private val gameStateAnalyzer: DlsGameStateAnalyzer = DlsGameStateAnalyzer.instance
) {

    companion object {
        private const val TAG = "DlsDecisionEngine"
        val instance: DlsDecisionEngine by lazy { DlsDecisionEngine() }
    }

    enum class ActionType(val label: String, val badgeColorHex: Long) {
        WAIT("WAIT", 0xFF9E9E9E),             // Gray
        CHASE_BALL("CHASE BALL", 0xFFFF9100), // Amber/Orange
        MOVE("MOVE", 0xFF00E5FF),             // Cyan
        PASS("PASS", 0xFF76FF03),             // Light Green
        SHOOT("SHOOT", 0xFFFF1744),           // Red / Bright Coral
        DEFEND("DEFEND", 0xFFFFAB00)          // Deep Orange
    }

    data class Decision(
        val actionType: ActionType = ActionType.WAIT,
        val targetX: Float? = null,
        val targetY: Float? = null,
        val targetNormX: Float? = null,
        val targetNormY: Float? = null,
        val direction: String = "None",
        val directionAngleDeg: Float? = null,
        val durationMs: Long = 0L,
        val confidence: Float = 0f,
        val reason: String = "Awaiting game state stream",
        val timestampMs: Long = 0L,
        val decisionLatencyMs: Long = 0L
    )

    data class DecisionConfig(
        val minConfidenceThreshold: Float = 0.40f,
        val actionCooldownMs: Long = 300L,
        val chaseBallDistanceThresholdPx: Float = 280f,
        val shootDistanceThresholdNormX: Float = 0.65f, // Attacking threshold (right side)
        val isDebugOverlayEnabled: Boolean = true
    )

    private val engineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _decision = MutableStateFlow(Decision())
    val decision: StateFlow<Decision> = _decision.asStateFlow()

    private val _config = MutableStateFlow(DecisionConfig())
    val config: StateFlow<DecisionConfig> = _config.asStateFlow()

    // Hysteresis & Cooldown tracking
    private var lastCommittedAction: ActionType = ActionType.WAIT
    private var lastActionCommitTimestamp: Long = 0L

    init {
        // Collect GameState off the main thread
        engineScope.launch {
            gameStateAnalyzer.gameState.collectLatest { gameState ->
                evaluateGameState(gameState)
            }
        }
    }

    fun updateConfig(update: (DecisionConfig) -> DecisionConfig) {
        _config.update(update)
    }

    fun setActionCooldownMs(cooldownMs: Long) {
        _config.update { it.copy(actionCooldownMs = cooldownMs) }
    }

    fun setMinConfidenceThreshold(threshold: Float) {
        _config.update { it.copy(minConfidenceThreshold = threshold.coerceIn(0.1f, 0.9f)) }
    }

    fun toggleDebugOverlay() {
        _config.update { it.copy(isDebugOverlayEnabled = !it.isDebugOverlayEnabled) }
    }

    /**
     * Evaluates the current GameState and computes the appropriate decision based on strict rule logic.
     */
    private fun evaluateGameState(gameState: DlsGameStateAnalyzer.GameState) {
        val startTime = System.currentTimeMillis()
        val currentCfg = _config.value
        val now = gameState.timestampMs.takeIf { it > 0 } ?: System.currentTimeMillis()

        val candidateDecision: CandidateDecision

        // 1. Safety & Signal Integrity Check
        if (gameState.frameWidth == 0 || gameState.frameHeight == 0) {
            candidateDecision = CandidateDecision(
                actionType = ActionType.WAIT,
                reason = "No video frame signal received",
                confidence = 1.0f
            )
        } else if (gameState.phase != DlsGameStateAnalyzer.MatchPhase.MATCH_IN_PLAY) {
            candidateDecision = CandidateDecision(
                actionType = ActionType.WAIT,
                reason = "Game not in active play (${gameState.phase.label})",
                confidence = 0.95f
            )
        } else if (gameState.overallConfidence < currentCfg.minConfidenceThreshold) {
            candidateDecision = CandidateDecision(
                actionType = ActionType.WAIT,
                reason = "Visual confidence too low (${(gameState.overallConfidence * 100).toInt()}% < ${(currentCfg.minConfidenceThreshold * 100).toInt()}%)",
                confidence = 0.85f
            )
        } else {
            // Game is in active play with sufficient confidence
            val ball = gameState.ball
            val players = gameState.players
            val closestPlayerInfo = gameState.closestPlayer
            val frameW = gameState.frameWidth.toFloat()
            val frameH = gameState.frameHeight.toFloat()

            if (ball == null || !ball.isTracked) {
                // Ball is undetected or missing from view
                candidateDecision = CandidateDecision(
                    actionType = ActionType.WAIT,
                    reason = "Ball not detected in field of view",
                    confidence = 0.80f
                )
            } else if (players.isEmpty()) {
                // No players detected
                candidateDecision = CandidateDecision(
                    actionType = ActionType.WAIT,
                    reason = "No players detected on the pitch",
                    confidence = 0.80f
                )
            } else {
                // Tactical rule execution
                candidateDecision = computeTacticalAction(
                    ball = ball,
                    players = players,
                    closestPlayerInfo = closestPlayerInfo,
                    frameW = frameW,
                    frameH = frameH,
                    cfg = currentCfg
                )
            }
        }

        // Apply hysteresis / action cooldown to prevent flickering between frames
        val finalActionType: ActionType
        val finalReason: String
        val timeSinceLastCommit = now - lastActionCommitTimestamp

        if (candidateDecision.actionType == ActionType.WAIT) {
            // Safety: Immediate fallback to WAIT if signal/phase is lost
            finalActionType = ActionType.WAIT
            finalReason = candidateDecision.reason
            lastCommittedAction = ActionType.WAIT
            lastActionCommitTimestamp = now
        } else if (candidateDecision.actionType == lastCommittedAction) {
            // Same action continued
            finalActionType = candidateDecision.actionType
            finalReason = candidateDecision.reason
        } else if (timeSinceLastCommit < currentCfg.actionCooldownMs && lastCommittedAction != ActionType.WAIT) {
            // Hold previous active action during cooldown window for stability
            finalActionType = lastCommittedAction
            finalReason = "${candidateDecision.reason} (Hysteresis hold: ${currentCfg.actionCooldownMs - timeSinceLastCommit}ms)"
        } else {
            // Switch to new action
            finalActionType = candidateDecision.actionType
            finalReason = candidateDecision.reason
            lastCommittedAction = candidateDecision.actionType
            lastActionCommitTimestamp = now
        }

        val latency = System.currentTimeMillis() - startTime

        // Compute direction label and angle from target if present
        val (dirName, dirAngle) = computeDirection(
            targetX = candidateDecision.targetX,
            targetY = candidateDecision.targetY,
            referenceX = gameState.closestPlayer?.player?.x ?: (gameState.frameWidth / 2f),
            referenceY = gameState.closestPlayer?.player?.y ?: (gameState.frameHeight / 2f)
        )

        val finalDecision = Decision(
            actionType = finalActionType,
            targetX = candidateDecision.targetX,
            targetY = candidateDecision.targetY,
            targetNormX = if (candidateDecision.targetX != null && gameState.frameWidth > 0) candidateDecision.targetX / gameState.frameWidth else null,
            targetNormY = if (candidateDecision.targetY != null && gameState.frameHeight > 0) candidateDecision.targetY / gameState.frameHeight else null,
            direction = dirName,
            directionAngleDeg = dirAngle,
            durationMs = candidateDecision.durationMs,
            confidence = candidateDecision.confidence,
            reason = finalReason,
            timestampMs = now,
            decisionLatencyMs = latency
        )

        _decision.value = finalDecision
    }

    /**
     * Tactical decision logic based on ball, players, and possession rules.
     */
    private fun computeTacticalAction(
        ball: DlsGameStateAnalyzer.BallState,
        players: List<DlsGameStateAnalyzer.TrackedPlayer>,
        closestPlayerInfo: DlsGameStateAnalyzer.ClosestPlayerInfo?,
        frameW: Float,
        frameH: Float,
        cfg: DecisionConfig
    ): CandidateDecision {
        // Controlled team players (Team 1) vs Opponent players (Team 2)
        val team1Players = players.filter { it.teamId == 1 }
        val team2Players = players.filter { it.teamId == 2 }

        val closestTeam1 = team1Players.minByOrNull { p ->
            val dx = p.x - ball.x
            val dy = p.y - ball.y
            sqrt(dx * dx + dy * dy)
        }

        val distToBallTeam1 = closestTeam1?.let { p ->
            val dx = p.x - ball.x
            val dy = p.y - ball.y
            sqrt(dx * dx + dy * dy)
        } ?: Float.MAX_VALUE

        // Case 1: Friendly possession (Team 1 has the ball)
        if (closestPlayerInfo != null && closestPlayerInfo.hasPossession && closestPlayerInfo.player.teamId == 1) {
            val controlledPlayer = closestPlayerInfo.player

            // Attacking Opportunity Check: Is player in attacking third? (X > 65% of screen width)
            val attackingGoalX = frameW * 0.95f
            val attackingGoalY = frameH * 0.50f

            if (controlledPlayer.normX >= cfg.shootDistanceThresholdNormX) {
                // In shooting zone
                return CandidateDecision(
                    actionType = ActionType.SHOOT,
                    targetX = attackingGoalX,
                    targetY = attackingGoalY,
                    durationMs = 250L,
                    confidence = 0.88f,
                    reason = "Player #${controlledPlayer.id} in attacking third (${(controlledPlayer.normX * 100).toInt()}% X) with direct shooting lane to goal"
                )
            }

            // Look for an open teammate forward
            val forwardTeammates = team1Players.filter { it.id != controlledPlayer.id && it.x > controlledPlayer.x + 80f }
            if (forwardTeammates.isNotEmpty()) {
                val bestTeammate = forwardTeammates.maxByOrNull { it.x }!!
                return CandidateDecision(
                    actionType = ActionType.PASS,
                    targetX = bestTeammate.x,
                    targetY = bestTeammate.y,
                    durationMs = 220L,
                    confidence = 0.82f,
                    reason = "Passing forward to open teammate #${bestTeammate.id} (${bestTeammate.x.toInt()}, ${bestTeammate.y.toInt()})"
                )
            }

            // Otherwise, advance with ball into attacking space
            val forwardAdvanceX = (controlledPlayer.x + 180f).coerceAtMost(frameW * 0.92f)
            val forwardAdvanceY = controlledPlayer.y
            return CandidateDecision(
                actionType = ActionType.MOVE,
                targetX = forwardAdvanceX,
                targetY = forwardAdvanceY,
                durationMs = 350L,
                confidence = 0.85f,
                reason = "Advancing with ball towards attacking half (Target: ${forwardAdvanceX.toInt()}, ${forwardAdvanceY.toInt()})"
            )
        }

        // Case 2: Opponent possession (Team 2 has the ball)
        if (closestPlayerInfo != null && closestPlayerInfo.hasPossession && closestPlayerInfo.player.teamId == 2) {
            val opponentWithBall = closestPlayerInfo.player
            // Position our closest defender between opponent and our defending goal (Left side, X=5% width)
            val defendingGoalX = frameW * 0.05f
            val defendingGoalY = frameH * 0.50f

            val interceptX = opponentWithBall.x * 0.70f + defendingGoalX * 0.30f
            val interceptY = opponentWithBall.y * 0.70f + defendingGoalY * 0.30f

            return CandidateDecision(
                actionType = ActionType.DEFEND,
                targetX = interceptX,
                targetY = interceptY,
                durationMs = 300L,
                confidence = 0.86f,
                reason = "Opponent #${opponentWithBall.id} has possession. Setting defensive containment at (${interceptX.toInt()}, ${interceptY.toInt()})"
            )
        }

        // Case 3: Loose ball in play
        if (distToBallTeam1 <= cfg.chaseBallDistanceThresholdPx) {
            // Ball is nearby friendly player -> CHASE_BALL
            val targetX = if (ball.speedPxPerSec > 30f) ball.predictedX.coerceIn(0f, frameW) else ball.x
            val targetY = if (ball.speedPxPerSec > 30f) ball.predictedY.coerceIn(0f, frameH) else ball.y

            return CandidateDecision(
                actionType = ActionType.CHASE_BALL,
                targetX = targetX,
                targetY = targetY,
                durationMs = 300L,
                confidence = 0.90f,
                reason = "Loose ball ${distToBallTeam1.toInt()}px from player #${closestTeam1?.id ?: 1}. Intercepting ball at (${targetX.toInt()}, ${targetY.toInt()})"
            )
        }

        // Case 4: Ball is farther away -> MOVE towards ball sector
        return CandidateDecision(
            actionType = ActionType.MOVE,
            targetX = ball.x,
            targetY = ball.y,
            durationMs = 300L,
            confidence = 0.75f,
            reason = "Regrouping team formation towards ball at (${ball.x.toInt()}, ${ball.y.toInt()})"
        )
    }

    private data class CandidateDecision(
        val actionType: ActionType,
        val targetX: Float? = null,
        val targetY: Float? = null,
        val durationMs: Long = 0L,
        val confidence: Float = 0f,
        val reason: String = ""
    )

    private fun computeDirection(
        targetX: Float?,
        targetY: Float?,
        referenceX: Float,
        referenceY: Float
    ): Pair<String, Float?> {
        if (targetX == null || targetY == null) return "None" to null

        val dx = targetX - referenceX
        val dy = targetY - referenceY
        val dist = sqrt(dx * dx + dy * dy)
        if (dist < 10f) return "On Target (◉)" to 0f

        val angleRad = atan2(dy.toDouble(), dx.toDouble())
        var angleDeg = Math.toDegrees(angleRad).toFloat()
        if (angleDeg < 0) angleDeg += 360f

        val name = when {
            angleDeg in 337.5..360.0 || angleDeg in 0.0..22.5 -> "Right (→)"
            angleDeg in 22.5..67.5 -> "Down-Right (↘)"
            angleDeg in 67.5..112.5 -> "Down (↓)"
            angleDeg in 112.5..157.5 -> "Down-Left (↙)"
            angleDeg in 157.5..202.5 -> "Left (←)"
            angleDeg in 202.5..247.5 -> "Up-Left (↖)"
            angleDeg in 247.5..292.5 -> "Up (↑)"
            angleDeg in 292.5..337.5 -> "Up-Right (↗)"
            else -> "Towards Target"
        }

        return name to angleDeg
    }
}
