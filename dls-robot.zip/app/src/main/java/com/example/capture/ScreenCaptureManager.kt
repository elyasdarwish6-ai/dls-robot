package com.example.capture

import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages Android MediaProjection screen capture session, VirtualDisplay, and ImageReader.
 * Ensures clean lifecycle management and resource cleanup.
 */
class ScreenCaptureManager {

    companion object {
        private const val TAG = "ScreenCaptureManager"
        private const val VIRTUAL_DISPLAY_NAME = "DLS_Robot_Capture"

        // Singleton instance accessible by service and UI components
        val instance: ScreenCaptureManager by lazy { ScreenCaptureManager() }
    }

    sealed interface CaptureState {
        object Idle : CaptureState
        object Starting : CaptureState
        data class Capturing(
            val width: Int,
            val height: Int,
            val densityDpi: Int,
            val frameCount: Long = 0L
        ) : CaptureState
        data class Error(val message: String) : CaptureState
    }

    private val _captureState = MutableStateFlow<CaptureState>(CaptureState.Idle)
    val captureState: StateFlow<CaptureState> = _captureState.asStateFlow()

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private var frameCounter: Long = 0L

    val isCapturing: Boolean
        get() = _captureState.value is CaptureState.Capturing

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.d(TAG, "MediaProjection callback onStop received")
            stopCapture()
        }
    }

    /**
     * Starts screen capture with the provided MediaProjection instance.
     */
    @Synchronized
    fun startCapture(
        projection: MediaProjection,
        width: Int,
        height: Int,
        densityDpi: Int
    ) {
        try {
            // Stop any existing capture first
            stopCaptureInternal()

            _captureState.value = CaptureState.Starting
            mediaProjection = projection

            // Use safe dimensions (ensure positive and even)
            val captureWidth = if (width > 0) width else 720
            val captureHeight = if (height > 0) height else 1280
            val dpi = if (densityDpi > 0) densityDpi else 320

            // Start background thread for frame processing
            val thread = HandlerThread("DlsCaptureThread").apply { start() }
            handlerThread = thread
            val handler = Handler(thread.looper)
            backgroundHandler = handler

            // Set up ImageReader to receive frames
            val reader = ImageReader.newInstance(
                captureWidth,
                captureHeight,
                PixelFormat.RGBA_8888,
                3
            )
            imageReader = reader
            frameCounter = 0L

            reader.setOnImageAvailableListener({ ir ->
                try {
                    val image = ir.acquireLatestImage()
                    if (image != null) {
                        try {
                            frameCounter++
                            // In Stage 2, dispatch frame to ImageAnalysisManager
                            com.example.analysis.ImageAnalysisManager.instance.onImageAvailable(image)

                            val current = _captureState.value
                            if (current is CaptureState.Capturing) {
                                _captureState.value = current.copy(frameCount = frameCounter)
                            }
                        } finally {
                            image.close()
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error acquiring image frame", e)
                }
            }, handler)

            // Register projection stop callback
            projection.registerCallback(projectionCallback, handler)

            // Create the VirtualDisplay
            val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR
            virtualDisplay = projection.createVirtualDisplay(
                VIRTUAL_DISPLAY_NAME,
                captureWidth,
                captureHeight,
                dpi,
                flags,
                reader.surface,
                null,
                handler
            )

            _captureState.value = CaptureState.Capturing(
                width = captureWidth,
                height = captureHeight,
                densityDpi = dpi,
                frameCount = 0L
            )
            com.example.analysis.ImageAnalysisManager.instance.onCaptureStarted(captureWidth, captureHeight)
            Log.i(TAG, "Screen capture started: ${captureWidth}x${captureHeight} @ ${dpi}dpi")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start screen capture", e)
            stopCaptureInternal()
            _captureState.value = CaptureState.Error(e.localizedMessage ?: "Failed to start capture")
        }
    }

    /**
     * Safely stops screen capture and releases all allocated resources.
     */
    @Synchronized
    fun stopCapture() {
        stopCaptureInternal()
        _captureState.value = CaptureState.Idle
        com.example.analysis.ImageAnalysisManager.instance.onCaptureStopped()
        Log.i(TAG, "Screen capture stopped and resources released")
    }

    private fun stopCaptureInternal() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing virtual display", e)
        }

        try {
            imageReader?.close()
            imageReader = null
        } catch (e: Exception) {
            Log.w(TAG, "Error closing image reader", e)
        }

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
            mediaProjection = null
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping media projection", e)
        }

        try {
            handlerThread?.quitSafely()
            handlerThread = null
            backgroundHandler = null
        } catch (e: Exception) {
            Log.w(TAG, "Error quitting capture thread", e)
        }
    }
}
