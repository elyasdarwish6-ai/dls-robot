package com.example.gamestate

import android.util.Log
import com.example.vision.DlsVisionAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Stage 4: Real-time Game-State Understanding Layer.
 * Consumes local vision results from DlsVisionAnalyzer and estimates:
 * - Smoothed ball position, velocity (dx, dy), speed, and heading angle
 * - Trajectory prediction for future positions
 * - Smoothed player tracking with persistence
 * - Closest player to ball & possession proximity
 * - Team grouping and field distribution
 * - High-level game phase classification (In-Play, Menu, Loading, Replay)
 */
class DlsGameStateAnalyzer private constructor() {

    companion object {
        private const val TAG = "DlsGameStateAnalyzer"
        val instance: DlsGameStateAnalyzer by lazy { DlsGameStateAnalyzer() }
    }

    enum class MatchPhase(val label: String) {
        MATCH_IN_PLAY("In Gameplay"),
        MATCH_STOPPED_OR_REPLAY("Stopped / Replay"),
        MENU_OR_UI("Menu / UI Screen"),
        LOADING_OR_TRANSITION("Loading / Cutscene"),
        UNKNOWN("Unknown / No Signal")
    }

    data class BallState(
        val x: Float,
        val y: Float,
        val normX: Float,
        val normY: Float,
        val velocityX: Float = 0f, // px per second
        val velocityY: Float = 0f, // px per second
        val speedPxPerSec: Float = 0f,
        val directionAngleDeg: Float = 0f,
        val directionName: String = "Stationary",
        val predictedX: Float = 0f,
        val predictedY: Float = 0f,
        val confidence: Float = 0f,
        val isTracked: Boolean = false
    )

    data class TrackedPlayer(
        val id: Int,
        val x: Float,
        val y: Float,
        val normX: Float,
        val normY: Float,
        val width: Float,
        val height: Float,
        val teamId: Int, // 1 = Team 1 (Home/Blue), 2 = Team 2 (Away/Red), 0 = Neutral
        val confidence: Float,
        val distanceToBall: Float? = null
    )

    data class ClosestPlayerInfo(
        val player: TrackedPlayer,
        val distancePx: Float,
        val teamName: String,
        val hasPossession: Boolean
    )

    data class TeamGrouping(
        val team1Count: Int = 0,
        val team2Count: Int = 0,
        val neutralCount: Int = 0
    )

    data class GameState(
        val timestampMs: Long = 0L,
        val phase: MatchPhase = MatchPhase.UNKNOWN,
        val phaseDescription: String = "Awaiting vision stream",
        val ball: BallState? = null,
        val players: List<TrackedPlayer> = emptyList(),
        val closestPlayer: ClosestPlayerInfo? = null,
        val teamGrouping: TeamGrouping = TeamGrouping(),
        val fieldCoveragePercent: Float = 0f,
        val overallConfidence: Float = 0f,
        val stateProcessingDurationMs: Long = 0L,
        val totalLatencyMs: Long = 0L,
        val frameWidth: Int = 0,
        val frameHeight: Int = 0
    )

    private val analyzerScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    // Bounded temporal history for smoothing & tracking (prevents memory leaks)
    private val maxHistorySize = 6
    private val ballHistory = ArrayDeque<Pair<Long, DlsVisionAnalyzer.DetectedBall>>(maxHistorySize)
    private var prevSmoothedBall: BallState? = null
    private var prevTrackedPlayers: List<TrackedPlayer> = emptyList()

    // Smoothing coefficients (Exponential Moving Average)
    private val ballAlpha = 0.70f // 70% current detection, 30% historical smoothing
    private val playerAlpha = 0.65f
    private val ballPossessionThresholdPx = 65f

    init {
        // Collect vision stream off the main thread
        analyzerScope.launch {
            DlsVisionAnalyzer.instance.detectionResult.collectLatest { visionResult ->
                processVisionFrame(visionResult)
            }
        }
    }

    private fun processVisionFrame(visionResult: DlsVisionAnalyzer.DetectionResult) {
        val startTime = System.currentTimeMillis()
        val now = visionResult.timestampMs.takeIf { it > 0 } ?: System.currentTimeMillis()

        try {
            // 1. Classify Game Screen State
            val fieldRegion = visionResult.fieldRegion
            val grassCoverage = fieldRegion?.grassCoveragePercent ?: 0f
            val isField = visionResult.isFieldDetected
            val rawPlayerCount = visionResult.players.size
            val hasRawBall = visionResult.ball != null

            val phase: MatchPhase
            val phaseDesc: String

            when {
                visionResult.frameWidth == 0 || visionResult.frameHeight == 0 -> {
                    phase = MatchPhase.UNKNOWN
                    phaseDesc = "No captured frame available"
                }
                isField && grassCoverage >= 20f && rawPlayerCount >= 2 -> {
                    phase = MatchPhase.MATCH_IN_PLAY
                    phaseDesc = "Match Active (${grassCoverage.toInt()}% pitch, $rawPlayerCount players)"
                }
                isField && grassCoverage >= 15f -> {
                    phase = MatchPhase.MATCH_STOPPED_OR_REPLAY
                    phaseDesc = "Field View (${grassCoverage.toInt()}% pitch)"
                }
                grassCoverage < 10f && rawPlayerCount == 0 -> {
                    phase = MatchPhase.MENU_OR_UI
                    phaseDesc = "Menu / Non-match UI screen"
                }
                else -> {
                    phase = MatchPhase.LOADING_OR_TRANSITION
                    phaseDesc = "Transition / Cutscene screen"
                }
            }

            // 2. Temporal Ball Tracking & Velocity Estimation
            val rawBall = visionResult.ball
            val smoothedBall: BallState?

            if (rawBall != null && rawBall.confidence >= 0.40f) {
                // Add to history
                if (ballHistory.size >= maxHistorySize) {
                    ballHistory.removeFirst()
                }
                ballHistory.addLast(now to rawBall)

                // Temporal smoothing
                val prev = prevSmoothedBall
                val smoothX = if (prev != null && prev.isTracked) {
                    ballAlpha * rawBall.x + (1f - ballAlpha) * prev.x
                } else {
                    rawBall.x
                }

                val smoothY = if (prev != null && prev.isTracked) {
                    ballAlpha * rawBall.y + (1f - ballAlpha) * prev.y
                } else {
                    rawBall.y
                }

                // Velocity calculation over consecutive frames
                var vx = 0f
                var vy = 0f
                var speed = 0f
                var angleDeg = 0f
                var dirName = "Stationary"

                if (ballHistory.size >= 2) {
                    val prevHistory = ballHistory.elementAt(ballHistory.size - 2)
                    val dt = (now - prevHistory.first).coerceAtLeast(10L) / 1000f // in seconds

                    val dx = smoothX - prevHistory.second.x
                    val dy = smoothY - prevHistory.second.y

                    vx = dx / dt
                    vy = dy / dt
                    speed = sqrt(vx * vx + vy * vy)

                    if (speed > 30f) {
                        val rad = atan2(dy.toDouble(), dx.toDouble())
                        angleDeg = Math.toDegrees(rad).toFloat()
                        dirName = getDirectionLabel(angleDeg)
                    }
                }

                // Trajectory prediction (predict 300ms ahead)
                val predLeadSec = 0.30f
                val predX = (smoothX + vx * predLeadSec).coerceIn(0f, visionResult.frameWidth.toFloat().takeIf { it > 0 } ?: 1920f)
                val predY = (smoothY + vy * predLeadSec).coerceIn(0f, visionResult.frameHeight.toFloat().takeIf { it > 0 } ?: 1080f)

                val normX = if (visionResult.frameWidth > 0) smoothX / visionResult.frameWidth else 0.5f
                val normY = if (visionResult.frameHeight > 0) smoothY / visionResult.frameHeight else 0.5f

                smoothedBall = BallState(
                    x = smoothX,
                    y = smoothY,
                    normX = normX,
                    normY = normY,
                    velocityX = vx,
                    velocityY = vy,
                    speedPxPerSec = speed,
                    directionAngleDeg = angleDeg,
                    directionName = dirName,
                    predictedX = predX,
                    predictedY = predY,
                    confidence = rawBall.confidence,
                    isTracked = true
                )
                prevSmoothedBall = smoothedBall
            } else {
                // If ball missing in this frame, decay velocity or retain briefly if high confidence
                val prev = prevSmoothedBall
                if (prev != null && prev.isTracked && ballHistory.isNotEmpty()) {
                    // Check how old the last detection was
                    val lastSeen = ballHistory.last().first
                    if (now - lastSeen < 400L) {
                        smoothedBall = prev.copy(
                            confidence = prev.confidence * 0.7f,
                            speedPxPerSec = prev.speedPxPerSec * 0.5f
                        )
                    } else {
                        smoothedBall = null
                        prevSmoothedBall = null
                        ballHistory.clear()
                    }
                } else {
                    smoothedBall = null
                    prevSmoothedBall = null
                    ballHistory.clear()
                }
            }

            // 3. Player Tracking, Smoothing & Nearest Neighbor Matching
            val trackedPlayers = trackAndSmoothPlayers(
                rawPlayers = visionResult.players,
                prevPlayers = prevTrackedPlayers,
                ballPos = smoothedBall?.let { it.x to it.y },
                frameWidth = visionResult.frameWidth,
                frameHeight = visionResult.frameHeight
            )
            prevTrackedPlayers = trackedPlayers

            // 4. Closest Player to Ball & Possession Identification
            var closestPlayerInfo: ClosestPlayerInfo? = null
            if (smoothedBall != null && trackedPlayers.isNotEmpty()) {
                var minDistance = Float.MAX_VALUE
                var closestPlayer: TrackedPlayer? = null

                for (p in trackedPlayers) {
                    val dist = p.distanceToBall ?: continue
                    if (dist < minDistance) {
                        minDistance = dist
                        closestPlayer = p
                    }
                }

                if (closestPlayer != null) {
                    val teamName = when (closestPlayer.teamId) {
                        1 -> "Team 1 (Blue/Cyan)"
                        2 -> "Team 2 (Red/Orange)"
                        else -> "Neutral / Ref"
                    }
                    closestPlayerInfo = ClosestPlayerInfo(
                        player = closestPlayer,
                        distancePx = minDistance,
                        teamName = teamName,
                        hasPossession = minDistance <= ballPossessionThresholdPx
                    )
                }
            }

            // 5. Team Grouping Metrics
            var t1 = 0
            var t2 = 0
            var neutral = 0
            for (p in trackedPlayers) {
                when (p.teamId) {
                    1 -> t1++
                    2 -> t2++
                    else -> neutral++
                }
            }
            val teamGrouping = TeamGrouping(team1Count = t1, team2Count = t2, neutralCount = neutral)

            // 6. Overall Confidence Calculation
            var confidenceScore = 0f
            if (isField) confidenceScore += 0.35f
            if (smoothedBall != null) confidenceScore += 0.35f * smoothedBall.confidence
            if (trackedPlayers.isNotEmpty()) confidenceScore += min(0.30f, trackedPlayers.size * 0.03f)

            val durationMs = System.currentTimeMillis() - startTime
            val totalLatency = visionResult.processingDurationMs + durationMs

            _gameState.value = GameState(
                timestampMs = now,
                phase = phase,
                phaseDescription = phaseDesc,
                ball = smoothedBall,
                players = trackedPlayers,
                closestPlayer = closestPlayerInfo,
                teamGrouping = teamGrouping,
                fieldCoveragePercent = grassCoverage,
                overallConfidence = confidenceScore.coerceIn(0f, 1f),
                stateProcessingDurationMs = durationMs,
                totalLatencyMs = totalLatency,
                frameWidth = visionResult.frameWidth,
                frameHeight = visionResult.frameHeight
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error in game state analysis", e)
        }
    }

    private fun trackAndSmoothPlayers(
        rawPlayers: List<DlsVisionAnalyzer.DetectedPlayer>,
        prevPlayers: List<TrackedPlayer>,
        ballPos: Pair<Float, Float>?,
        frameWidth: Int,
        frameHeight: Int
    ): List<TrackedPlayer> {
        val result = mutableListOf<TrackedPlayer>()
        val matchedPrevIds = mutableSetOf<Int>()

        for (raw in rawPlayers) {
            // Find nearest previous player within proximity matching threshold (e.g. 50px)
            var matchedPrev: TrackedPlayer? = null
            var bestDist = 60f // Max matching distance threshold

            for (prev in prevPlayers) {
                if (prev.id in matchedPrevIds) continue
                val dx = raw.x - prev.x
                val dy = raw.y - prev.y
                val dist = sqrt(dx * dx + dy * dy)
                if (dist < bestDist) {
                    bestDist = dist
                    matchedPrev = prev
                }
            }

            val assignedId: Int
            val smoothX: Float
            val smoothY: Float

            if (matchedPrev != null) {
                matchedPrevIds.add(matchedPrev.id)
                assignedId = matchedPrev.id
                smoothX = playerAlpha * raw.x + (1f - playerAlpha) * matchedPrev.x
                smoothY = playerAlpha * raw.y + (1f - playerAlpha) * matchedPrev.y
            } else {
                assignedId = raw.id
                smoothX = raw.x
                smoothY = raw.y
            }

            val distToBall = ballPos?.let { (bx, by) ->
                val dx = smoothX - bx
                val dy = smoothY - by
                sqrt(dx * dx + dy * dy)
            }

            val normX = if (frameWidth > 0) smoothX / frameWidth else raw.normX
            val normY = if (frameHeight > 0) smoothY / frameHeight else raw.normY

            result.add(
                TrackedPlayer(
                    id = assignedId,
                    x = smoothX,
                    y = smoothY,
                    normX = normX,
                    normY = normY,
                    width = raw.width,
                    height = raw.height,
                    teamId = raw.teamId,
                    confidence = raw.confidence,
                    distanceToBall = distToBall
                )
            )
        }

        return result
    }

    private fun getDirectionLabel(angleDeg: Float): String {
        val normalized = (angleDeg + 360f) % 360f
        return when (normalized) {
            in 337.5f..360f, in 0f..22.5f -> "Right (→)"
            in 22.5f..67.5f -> "Down-Right (↘)"
            in 67.5f..112.5f -> "Down (↓)"
            in 112.5f..157.5f -> "Down-Left (↙)"
            in 157.5f..202.5f -> "Left (←)"
            in 202.5f..247.5f -> "Up-Left (↖)"
            in 247.5f..292.5f -> "Up (↑)"
            in 292.5f..337.5f -> "Up-Right (↗)"
            else -> "Stationary"
        }
    }
}
